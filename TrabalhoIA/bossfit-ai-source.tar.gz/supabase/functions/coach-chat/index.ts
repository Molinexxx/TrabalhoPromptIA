// Smart Coach with Lovable AI Gateway — streaming, contextual, intent-aware
// deno-lint-ignore-file no-explicit-any

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface ProfileCtx {
  username?: string | null;
  quiz?: {
    objetivo?: string;
    nivel?: string;
    frequencia?: number;
    focoMuscular?: string;
    peso?: number;
    altura?: number;
    injuries?: string[];
  };
  streak?: number;
  progression?: { level?: number; xp?: number; loadFactor?: number };
  dailyWorkout?: { title?: string; focus?: string; estimatedMinutes?: number } | null;
  lastWorkoutDate?: string | null;
}

interface RecentWorkout {
  focus?: string;
  completionRate?: number;
  difficulty?: number;
  recordedAt?: string;
}

type Intent = "treino" | "alimentacao" | "dor" | "motivacao" | "progresso" | "geral";

function detectIntent(text: string): Intent {
  const t = text.toLowerCase();
  if (/(dor|machuc|lesã|lesa|incomod|estral|inflam)/.test(t)) return "dor";
  if (/(prote[ií]na|comer|dieta|alimenta|caloria|carb|refeic|jejum|suplement|creatina|whey)/.test(t)) return "alimentacao";
  if (/(desanim|preguic|motiva|cansad|desisti|odeio|sem vontade)/.test(t)) return "motivacao";
  if (/(progress|evolu|melhor|piorou|estagna|plat[oô])/.test(t)) return "progresso";
  if (/(treino|exerc[ií]cio|s[eé]rie|repeti|carga|peso|hipertrofia|forca|força|cardio|aer[oó]b|descanso|sono|deload|warm|aquec)/.test(t)) return "treino";
  return "geral";
}

function timeContext(): string {
  const h = new Date().getUTCHours() - 3; // approx BR
  const hour = (h + 24) % 24;
  if (hour < 6) return "madrugada";
  if (hour < 12) return "manhã";
  if (hour < 18) return "tarde";
  return "noite";
}

function buildSystemPrompt(profile: ProfileCtx, recent: RecentWorkout[], intent: Intent): string {
  const q = profile.quiz ?? {};
  const p = profile.progression ?? {};
  const injuries = (q.injuries ?? []).filter(Boolean);
  const proteinTarget = q.peso ? Math.round(q.peso * 1.8) : null;
  const water = q.peso ? Math.round(q.peso * 35) : null;

  const ctxLines = [
    `Atleta: ${profile.username ?? "boss"}`,
    `Objetivo: ${q.objetivo ?? "hipertrofia"} | Nível: ${q.nivel ?? "intermediário"}`,
    `Frequência: ${q.frequencia ?? 4}x/sem | Foco: ${q.focoMuscular ?? "fullbody"}`,
    `Peso: ${q.peso ?? "?"}kg | Altura: ${q.altura ?? "?"}cm`,
    `Streak: ${profile.streak ?? 0} dias | Nível BOSSFIT: ${p.level ?? 1} (${p.xp ?? 0} XP)`,
    `Carga relativa: ${(p.loadFactor ?? 1).toFixed(2)}x`,
    proteinTarget ? `Meta proteína calculada: ${proteinTarget}g/dia` : "",
    water ? `Meta hidratação calculada: ${water}ml/dia` : "",
    injuries.length ? `⚠️ LESÕES ATIVAS: ${injuries.join(", ")} — adapte recomendações, evite sobrecarga nessas regiões.` : "",
    profile.dailyWorkout?.title ? `Treino de hoje: ${profile.dailyWorkout.title} (${profile.dailyWorkout.focus}, ~${profile.dailyWorkout.estimatedMinutes}min)` : "",
    profile.lastWorkoutDate ? `Último treino: ${profile.lastWorkoutDate}` : "",
    `Momento do dia: ${timeContext()}`,
  ].filter(Boolean);

  let recentBlock = "";
  if (recent.length > 0) {
    const avgComp = recent.reduce((s, r) => s + (r.completionRate ?? 0), 0) / recent.length;
    const avgDiff = recent.reduce((s, r) => s + (r.difficulty ?? 0), 0) / recent.length;
    recentBlock = `\nÚltimos ${recent.length} treinos: conclusão ${(avgComp * 100).toFixed(0)}%, dificuldade ${avgDiff.toFixed(1)}/5.`;
    if (avgComp < 0.7) recentBlock += " Conclusão baixa — talvez ajustar volume ou intensidade.";
    if (avgDiff >= 4) recentBlock += " Dificuldade alta — considerar deload.";
  }

  const intentGuide: Record<Intent, string> = {
    dor: "FOCO: dor/lesão. Pergunte localização e intensidade se não souber. NUNCA diagnostique. Sugira: pausar a região, mobilidade leve, gelo/calor básico, e procurar fisio se dor aguda/persistente. Se já há lesão registrada, referencie.",
    alimentacao: "FOCO: nutrição básica. Use os números calculados (proteína, água). Sem prescrição médica. Sugestões práticas (ovos, frango, arroz, frutas). Lembre que nutricionista é quem prescreve dieta.",
    motivacao: "FOCO: motivação curta e firme. Use o streak se >0. Cite ganhos reais já conquistados. Sem clichê. Tom: coach que cobra com carinho.",
    progresso: "FOCO: análise de progresso. Use nível, XP, conclusão média e dificuldade. Aponte tendência concreta.",
    treino: "FOCO: treino. Use carga relativa, nível e objetivo. Fale de execução, sobrecarga progressiva, séries até 1-2 reps da falha. Se houver lesão, adapte.",
    geral: "Responda contextual ao perfil do atleta.",
  };

  // Variação de abertura para evitar repetição
  const openers = ["Vai lá", "Bora", "Olha só", "Fala comigo", "Direto ao ponto"];
  const opener = openers[Math.floor(Math.random() * openers.length)];

  return `Você é o Smart Coach do BOSSFIT AI — personal trainer digital direto, técnico e motivacional. Português BR, tom de coach (firme, próximo, cobra com carinho). Use "boss" ou "atleta" às vezes (não em toda resposta — é chato). Respostas CURTAS: 2-4 frases, no máximo 5. Acionáveis. Cite números do contexto quando fizer sentido. Sem disclaimers médicos genéricos repetitivos. Sem listas longas. Varie o jeito de começar (não comece sempre igual). Use markdown só quando ajudar (negrito em número-chave). Se a pergunta for vaga, faça UMA pergunta de volta.

INTENÇÃO DETECTADA: ${intent.toUpperCase()}
${intentGuide[intent]}

CONTEXTO DO ATLETA:
${ctxLines.join("\n")}${recentBlock}

REGRAS DE SEGURANÇA:
- Lesões ativas: SEMPRE adaptar/evitar sobrecarga na região afetada.
- Dor aguda ou persistente: orientar buscar fisio/médico, não diagnosticar.
- Nunca prescrever dose de medicamento ou dieta exata em gramas além de proteína básica.

DICA DE ABERTURA (use ou ignore): "${opener}".`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { messages, profile, recent } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY not configured");

    const lastUser = [...(messages ?? [])].reverse().find((m: any) => m.role === "user");
    const intent = detectIntent(lastUser?.content ?? "");
    const systemPrompt = buildSystemPrompt(profile ?? {}, recent ?? [], intent);

    // Trim conversation memory to last 12 turns to keep context tight
    const trimmed = (messages ?? []).slice(-12);

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          ...trimmed,
        ],
        stream: true,
        temperature: 0.85,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Limite de mensagens atingido. Tente em alguns instantes." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "Créditos de IA esgotados. Adicione na sua workspace." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "AI gateway error" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("coach-chat error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
