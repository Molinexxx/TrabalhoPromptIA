ALTER TABLE public.performance_history
ADD COLUMN IF NOT EXISTS exercise_feedback jsonb DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS overall_rating integer,
ADD COLUMN IF NOT EXISTS overall_notes text;