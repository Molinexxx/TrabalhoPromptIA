ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS favorites jsonb NOT NULL DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS daily_missions jsonb NOT NULL DEFAULT '{"date": null, "items": []}'::jsonb;