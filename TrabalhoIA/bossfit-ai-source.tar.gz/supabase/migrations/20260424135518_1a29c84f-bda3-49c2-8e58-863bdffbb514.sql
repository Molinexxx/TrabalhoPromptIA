CREATE TABLE public.exercise_history (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  exercise_id TEXT NOT NULL,
  exercise_name TEXT NOT NULL,
  weight_kg NUMERIC NOT NULL DEFAULT 0,
  reps TEXT,
  sets INTEGER NOT NULL DEFAULT 0,
  feedback TEXT,
  recorded_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE INDEX idx_exercise_history_user_exercise ON public.exercise_history(user_id, exercise_id, recorded_at DESC);
CREATE INDEX idx_exercise_history_user_date ON public.exercise_history(user_id, recorded_at DESC);

ALTER TABLE public.exercise_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "eh_select_own" ON public.exercise_history
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "eh_insert_own" ON public.exercise_history
  FOR INSERT WITH CHECK (auth.uid() = user_id);