create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, username)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'username', split_part(coalesce(new.email,'user'), '@', 1)))
  on conflict (id) do nothing;
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create or replace function public.touch_updated_at()
returns trigger language plpgsql set search_path = public as $$
begin new.updated_at = now(); return new; end; $$;

drop trigger if exists profiles_touch_updated_at on public.profiles;
create trigger profiles_touch_updated_at before update on public.profiles for each row execute function public.touch_updated_at();

-- Backfill profiles for any auth users created before the trigger existed
insert into public.profiles (id, email, username)
select u.id, u.email, coalesce(u.raw_user_meta_data->>'username', split_part(coalesce(u.email,'user'), '@', 1))
from auth.users u
left join public.profiles p on p.id = u.id
where p.id is null;