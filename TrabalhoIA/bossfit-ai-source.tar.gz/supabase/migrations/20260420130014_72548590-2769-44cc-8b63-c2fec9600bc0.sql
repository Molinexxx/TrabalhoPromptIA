
-- Notifications table (in-app, realtime)
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  title text not null,
  body text,
  type text not null default 'info',
  url text,
  read boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.notifications enable row level security;

create policy "notifications_select_own" on public.notifications
for select using (auth.uid() = user_id);

create policy "notifications_update_own" on public.notifications
for update using (auth.uid() = user_id);

create policy "notifications_insert_own" on public.notifications
for insert with check (auth.uid() = user_id);

create index if not exists notifications_user_created_idx
  on public.notifications (user_id, created_at desc);

-- Realtime
alter publication supabase_realtime add table public.notifications;
alter table public.notifications replica identity full;

-- Push subscriptions table (Web Push VAPID)
create table if not exists public.push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  endpoint text not null unique,
  p256dh text not null,
  auth text not null,
  user_agent text,
  created_at timestamptz not null default now()
);
alter table public.push_subscriptions enable row level security;

create policy "push_select_own" on public.push_subscriptions
for select using (auth.uid() = user_id);

create policy "push_insert_own" on public.push_subscriptions
for insert with check (auth.uid() = user_id);

create policy "push_delete_own" on public.push_subscriptions
for delete using (auth.uid() = user_id);

create index if not exists push_subs_user_idx on public.push_subscriptions (user_id);
