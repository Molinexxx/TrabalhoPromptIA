export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      exercise_history: {
        Row: {
          exercise_id: string
          exercise_name: string
          feedback: string | null
          id: string
          recorded_at: string
          reps: string | null
          sets: number
          user_id: string
          weight_kg: number
        }
        Insert: {
          exercise_id: string
          exercise_name: string
          feedback?: string | null
          id?: string
          recorded_at?: string
          reps?: string | null
          sets?: number
          user_id: string
          weight_kg?: number
        }
        Update: {
          exercise_id?: string
          exercise_name?: string
          feedback?: string | null
          id?: string
          recorded_at?: string
          reps?: string | null
          sets?: number
          user_id?: string
          weight_kg?: number
        }
        Relationships: []
      }
      notifications: {
        Row: {
          body: string | null
          created_at: string
          id: string
          read: boolean
          title: string
          type: string
          url: string | null
          user_id: string
        }
        Insert: {
          body?: string | null
          created_at?: string
          id?: string
          read?: boolean
          title: string
          type?: string
          url?: string | null
          user_id: string
        }
        Update: {
          body?: string | null
          created_at?: string
          id?: string
          read?: boolean
          title?: string
          type?: string
          url?: string | null
          user_id?: string
        }
        Relationships: []
      }
      performance_history: {
        Row: {
          completion_rate: number | null
          difficulty: number | null
          exercise_feedback: Json | null
          id: string
          overall_notes: string | null
          overall_rating: number | null
          recorded_at: string | null
          sets_completed_total: number | null
          time_spent: number | null
          user_id: string
        }
        Insert: {
          completion_rate?: number | null
          difficulty?: number | null
          exercise_feedback?: Json | null
          id?: string
          overall_notes?: string | null
          overall_rating?: number | null
          recorded_at?: string | null
          sets_completed_total?: number | null
          time_spent?: number | null
          user_id: string
        }
        Update: {
          completion_rate?: number | null
          difficulty?: number | null
          exercise_feedback?: Json | null
          id?: string
          overall_notes?: string | null
          overall_rating?: number | null
          recorded_at?: string | null
          sets_completed_total?: number | null
          time_spent?: number | null
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          bio: string | null
          challenges: Json | null
          created_at: string | null
          daily_missions: Json
          daily_workout: Json | null
          email: string | null
          favorites: Json
          goals: Json | null
          id: string
          last_workout_date: string | null
          progression: Json | null
          quiz: Json | null
          quiz_completed: boolean | null
          ranking_score: number | null
          streak: number | null
          updated_at: string | null
          username: string | null
          weekly_plan: Json | null
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          challenges?: Json | null
          created_at?: string | null
          daily_missions?: Json
          daily_workout?: Json | null
          email?: string | null
          favorites?: Json
          goals?: Json | null
          id: string
          last_workout_date?: string | null
          progression?: Json | null
          quiz?: Json | null
          quiz_completed?: boolean | null
          ranking_score?: number | null
          streak?: number | null
          updated_at?: string | null
          username?: string | null
          weekly_plan?: Json | null
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          challenges?: Json | null
          created_at?: string | null
          daily_missions?: Json
          daily_workout?: Json | null
          email?: string | null
          favorites?: Json
          goals?: Json | null
          id?: string
          last_workout_date?: string | null
          progression?: Json | null
          quiz?: Json | null
          quiz_completed?: boolean | null
          ranking_score?: number | null
          streak?: number | null
          updated_at?: string | null
          username?: string | null
          weekly_plan?: Json | null
        }
        Relationships: []
      }
      push_subscriptions: {
        Row: {
          auth: string
          created_at: string
          endpoint: string
          id: string
          p256dh: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          auth: string
          created_at?: string
          endpoint: string
          id?: string
          p256dh: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          auth?: string
          created_at?: string
          endpoint?: string
          id?: string
          p256dh?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: []
      }
      workout_history: {
        Row: {
          completed_at: string | null
          id: string
          user_id: string
          workout: Json
        }
        Insert: {
          completed_at?: string | null
          id?: string
          user_id: string
          workout: Json
        }
        Update: {
          completed_at?: string | null
          id?: string
          user_id?: string
          workout?: Json
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
