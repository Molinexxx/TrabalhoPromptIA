import { createFileRoute, Outlet, Link, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { useAuth } from "@/lib/auth";
import { useProfile } from "@/lib/use-profile";
import { Dumbbell, Home, Brain, Trophy, LogOut, Activity, LineChart, HeartPulse, ListChecks } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";

export const Route = createFileRoute("/app")({
  component: AppLayout,
});

function AppLayout() {
  const { user, loading, signOut } = useAuth();
  const { data: profile, isLoading: profileLoading } = useProfile();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !user) {
      navigate({ to: "/auth" });
    }
  }, [loading, user, navigate]);

  useEffect(() => {
    // Redirect to quiz if not completed
    if (profile && !profile.quiz_completed && window.location.pathname !== "/app/quiz") {
      navigate({ to: "/app/quiz" });
    }
  }, [profile, navigate]);

  if (loading || !user || profileLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="h-10 w-10 rounded-full border-2 border-primary/30 border-t-primary animate-spin" />
      </div>
    );
  }

  const handleLogout = async () => {
    await signOut();
    navigate({ to: "/" });
  };

  const navItems = [
    { to: "/app" as const, icon: Home, label: "Hoje" },
    { to: "/app/meus-treinos" as const, icon: ListChecks, label: "Meus Treinos" },
    { to: "/app/evolucao" as const, icon: LineChart, label: "Evolução" },
    { to: "/app/bem-estar" as const, icon: HeartPulse, label: "Cuidados" },
    { to: "/app/coach" as const, icon: Brain, label: "Coach" },
    { to: "/app/ranking" as const, icon: Trophy, label: "Ranking" },
  ];

  return (
    <div className="min-h-screen pb-24 md:pb-0">
      {/* Top bar */}
      <header className="sticky top-0 z-30 border-b border-border/50 backdrop-blur-md bg-background/70 no-select">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/app" className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-gradient-primary flex items-center justify-center shadow-glow">
              <Dumbbell className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="font-bold tracking-tight hidden sm:inline">
              BOSSFIT <span className="text-gradient-primary">AI</span>
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className="px-3 py-2 rounded-md text-sm text-muted-foreground hover:text-foreground hover:bg-accent transition-colors flex items-center gap-2"
                activeOptions={{ exact: item.to === "/app" }}
                activeProps={{ className: "px-3 py-2 rounded-md text-sm text-foreground bg-accent flex items-center gap-2" }}
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full glass text-xs">
              <Activity className="h-3.5 w-3.5 text-primary" />
              <span className="font-medium">{profile?.streak ?? 0} dias</span>
            </div>
            <Link
              to="/app/perfil"
              title="Ver perfil"
              className="rounded-full ring-1 ring-border/60 hover:ring-primary/60 hover:shadow-glow transition-all"
            >
              <Avatar className="h-9 w-9">
                <AvatarImage src={profile?.avatar_url ?? undefined} alt={profile?.username ?? "Perfil"} />
                <AvatarFallback className="bg-gradient-primary text-primary-foreground text-xs font-bold">
                  {(profile?.username ?? "U").slice(0, 1).toUpperCase()}
                </AvatarFallback>
              </Avatar>
            </Link>
            <Button variant="ghost" size="sm" onClick={handleLogout} title="Sair">
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 md:py-8">
        <Outlet />
      </main>

      {/* Mobile bottom nav */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 z-30 border-t border-border/50 backdrop-blur-md bg-background/90 no-select">
        <div className="grid grid-cols-6">
          {navItems.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="flex flex-col items-center justify-center gap-1 py-3 text-xs text-muted-foreground"
              activeOptions={{ exact: item.to === "/app" }}
              activeProps={{ className: "flex flex-col items-center justify-center gap-1 py-3 text-xs text-primary" }}
            >
              <item.icon className="h-5 w-5" />
              {item.label}
            </Link>
          ))}
        </div>
      </nav>
    </div>
  );
}
