import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { CalendarDays, ChevronLeft, ChevronRight, Dumbbell, Flame, Pencil, PlayCircle, Plus, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";
import { useUpdateProfile } from "@/lib/use-profile";
import { supabase } from "@/integrations/supabase/client";
import { generateSpecialWorkout, SPECIAL_KINDS, type SpecialWorkoutKind } from "@/lib/special-workouts";
import type { Workout } from "@/lib/types";
import { toast } from "sonner";

export const Route = createFileRoute("/app/meus-treinos")({
  component: MyWorkoutsPage,
});

interface HistoryRow {
  id: string;
  completed_at: string;
  workout: Workout;
}

function MyWorkoutsPage() {
  const { user } = useAuth();
  const updateProfile = useUpdateProfile();
  const [cursor, setCursor] = useState(() => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), 1);
  });
  const [preview, setPreview] = useState<Workout | null>(null);
  const [generating, setGenerating] = useState<SpecialWorkoutKind | null>(null);

  const { data: history = [] } = useQuery<HistoryRow[]>({
    queryKey: ["workout_history_full", user?.id],
    enabled: !!user?.id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("workout_history")
        .select("id, completed_at, workout")
        .eq("user_id", user!.id)
        .order("completed_at", { ascending: false })
        .limit(200);
      if (error) throw error;
      return (data ?? []) as unknown as HistoryRow[];
    },
  });

  // Map by yyyy-mm-dd
  const byDay = useMemo(() => {
    const m = new Map<string, HistoryRow[]>();
    for (const row of history) {
      const key = row.completed_at?.slice(0, 10);
      if (!key) continue;
      if (!m.has(key)) m.set(key, []);
      m.get(key)!.push(row);
    }
    return m;
  }, [history]);

  // Build calendar grid
  const calendar = useMemo(() => {
    const year = cursor.getFullYear();
    const month = cursor.getMonth();
    const first = new Date(year, month, 1);
    const startWeekday = first.getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const cells: Array<{ date: Date | null }> = [];
    for (let i = 0; i < startWeekday; i++) cells.push({ date: null });
    for (let d = 1; d <= daysInMonth; d++) cells.push({ date: new Date(year, month, d) });
    while (cells.length % 7 !== 0) cells.push({ date: null });
    return cells;
  }, [cursor]);

  const monthLabel = cursor.toLocaleDateString("pt-BR", { month: "long", year: "numeric" });

  const handleGenerate = (kind: SpecialWorkoutKind) => {
    setGenerating(kind);
    const w = generateSpecialWorkout(kind);
    setPreview(w);
    setGenerating(null);
  };

  const handleUseAsToday = async () => {
    if (!preview) return;
    try {
      await updateProfile.mutateAsync({ daily_workout: preview });
      toast.success("Treino definido como o de hoje. Bora!");
      setPreview(null);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Erro ao salvar");
    }
  };

  const totalMinutesMonth = useMemo(() => {
    let mins = 0;
    for (const [day, rows] of byDay.entries()) {
      const d = new Date(day);
      if (d.getMonth() === cursor.getMonth() && d.getFullYear() === cursor.getFullYear()) {
        for (const r of rows) mins += r.workout?.estimatedMinutes ?? 0;
      }
    }
    return mins;
  }, [byDay, cursor]);

  const totalSessionsMonth = useMemo(() => {
    let n = 0;
    for (const [day, rows] of byDay.entries()) {
      const d = new Date(day);
      if (d.getMonth() === cursor.getMonth() && d.getFullYear() === cursor.getFullYear()) {
        n += rows.length;
      }
    }
    return n;
  }, [byDay, cursor]);

  return (
    <div className="max-w-4xl mx-auto animate-slide-up no-select">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="text-[11px] uppercase tracking-widest text-primary font-black">
            Meus treinos
          </div>
          <h1 className="text-2xl md:text-3xl font-black tracking-tight">Sua jornada</h1>
        </div>
        <Button asChild variant="outline" size="sm">
          <Link to="/app/treino">
            <PlayCircle className="h-4 w-4 mr-1" /> Treino de hoje
          </Link>
        </Button>
      </div>

      {/* Calendário */}
      <div className="rounded-3xl border border-border bg-gradient-surface p-4 md:p-6 shadow-card">
        <div className="flex items-center justify-between mb-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))}
            aria-label="Mês anterior"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="flex items-center gap-2">
            <CalendarDays className="h-4 w-4 text-primary" />
            <div className="font-bold capitalize">{monthLabel}</div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))}
            aria-label="Próximo mês"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>

        <div className="grid grid-cols-7 gap-1 text-center text-[10px] uppercase tracking-wider text-muted-foreground font-bold mb-2">
          {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"].map((d) => (
            <div key={d}>{d}</div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-1">
          {calendar.map((cell, i) => {
            if (!cell.date) {
              return <div key={i} className="aspect-square" />;
            }
            const key = cell.date.toISOString().slice(0, 10);
            const sessions = byDay.get(key) ?? [];
            const isToday = key === new Date().toISOString().slice(0, 10);
            const trained = sessions.length > 0;
            return (
              <button
                key={i}
                type="button"
                title={
                  trained
                    ? sessions
                        .map((s) => `${s.workout?.title ?? "Treino"} • ${s.workout?.estimatedMinutes ?? 0}min`)
                        .join("\n")
                    : "Sem treino"
                }
                className={`aspect-square rounded-lg border text-xs font-bold flex flex-col items-center justify-center transition relative ${
                  trained
                    ? "border-primary/50 bg-primary/15 text-primary shadow-glow"
                    : "border-border bg-surface text-muted-foreground hover:bg-accent/50"
                } ${isToday ? "ring-2 ring-primary" : ""}`}
              >
                <span>{cell.date.getDate()}</span>
                {trained && (
                  <span className="text-[9px] opacity-90 mt-0.5">
                    {sessions[0].workout?.estimatedMinutes ?? 0}m
                  </span>
                )}
                {sessions.length > 1 && (
                  <span className="absolute top-0.5 right-0.5 h-1.5 w-1.5 rounded-full bg-primary" />
                )}
              </button>
            );
          })}
        </div>

        <div className="grid grid-cols-2 gap-2 mt-4">
          <div className="rounded-xl border border-border bg-surface p-3 text-center">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">
              Treinos no mês
            </div>
            <div className="text-2xl font-black tabular-nums mt-1">{totalSessionsMonth}</div>
          </div>
          <div className="rounded-xl border border-border bg-surface p-3 text-center">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">
              Minutos totais
            </div>
            <div className="text-2xl font-black tabular-nums mt-1">{totalMinutesMonth}</div>
          </div>
        </div>
      </div>

      {/* Histórico recente */}
      <div className="mt-6">
        <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-3">
          Histórico recente
        </h2>
        {history.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-border bg-surface p-6 text-center text-sm text-muted-foreground">
            Nenhum treino registrado ainda. Bora começar?
          </div>
        ) : (
          <div className="space-y-2">
            {history.slice(0, 8).map((row) => {
              const d = new Date(row.completed_at);
              return (
                <div
                  key={row.id}
                  className="flex items-center gap-3 rounded-xl border border-border bg-surface p-3"
                >
                  <div className="h-10 w-10 rounded-lg bg-gradient-primary flex items-center justify-center shadow-glow">
                    <Dumbbell className="h-5 w-5 text-primary-foreground" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold truncate">{row.workout?.title ?? "Treino"}</div>
                    <div className="text-xs text-muted-foreground">
                      {d.toLocaleDateString("pt-BR")} ·{" "}
                      {row.workout?.estimatedMinutes ?? 0} min · {row.workout?.focus}
                    </div>
                  </div>
                  <Flame className="h-4 w-4 text-primary" />
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Gerador de treinos especiais */}
      <div className="mt-8">
        <div className="flex items-center gap-2 mb-3">
          <Sparkles className="h-4 w-4 text-primary" />
          <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">
            Gerador de treino
          </h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {SPECIAL_KINDS.map((k) => (
            <button
              key={k.kind}
              type="button"
              onClick={() => handleGenerate(k.kind)}
              disabled={generating !== null}
              className="text-left rounded-2xl border border-border bg-surface hover:border-primary/50 hover:bg-accent/40 transition p-4 group"
            >
              <div className="text-3xl mb-2">{k.emoji}</div>
              <div className="font-bold">{k.label}</div>
              <div className="text-xs text-muted-foreground mt-1">{k.desc}</div>
              <div className="mt-3 inline-flex items-center text-xs font-semibold text-primary opacity-80 group-hover:opacity-100">
                <Plus className="h-3.5 w-3.5 mr-1" /> Gerar treino
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Preview de treino gerado */}
      {preview && (
        <div className="mt-6 rounded-3xl border border-primary/40 bg-gradient-surface p-5 shadow-elevated animate-slide-up">
          <div className="flex items-center justify-between mb-3">
            <div>
              <div className="text-[11px] uppercase tracking-widest text-primary font-black">
                Treino gerado
              </div>
              <h3 className="text-xl font-black">{preview.title}</h3>
              <div className="text-xs text-muted-foreground">
                {preview.focus} · {preview.estimatedMinutes} min · {preview.main.length} exercícios
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setPreview(null)}>
              Fechar
            </Button>
          </div>

          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
            {preview.main.map((ex, idx) => (
              <div
                key={ex.id + idx}
                className="flex items-center gap-3 rounded-xl border border-border bg-surface p-3"
              >
                <div className="h-8 w-8 rounded-md bg-primary/15 text-primary text-xs font-black flex items-center justify-center">
                  {idx + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold truncate">{ex.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {ex.sets} x {ex.reps} · descanso {ex.rest}s
                  </div>
                </div>
                <input
                  type="number"
                  min={1}
                  value={ex.sets}
                  onChange={(e) => {
                    const v = Math.max(1, Math.min(10, parseInt(e.target.value) || 1));
                    setPreview((p) =>
                      p
                        ? {
                            ...p,
                            main: p.main.map((m, i) => (i === idx ? { ...m, sets: v } : m)),
                          }
                        : p,
                    );
                  }}
                  className="w-14 h-8 rounded-md border border-border bg-background text-center text-xs"
                  title="Séries"
                />
                <Pencil className="h-3.5 w-3.5 text-muted-foreground" />
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-4">
            <Button variant="outline" onClick={() => setPreview(null)}>
              Descartar
            </Button>
            <Button
              onClick={handleUseAsToday}
              className="bg-gradient-primary text-primary-foreground hover:opacity-90 font-black"
            >
              <PlayCircle className="h-4 w-4 mr-1" /> Usar como treino de hoje
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
