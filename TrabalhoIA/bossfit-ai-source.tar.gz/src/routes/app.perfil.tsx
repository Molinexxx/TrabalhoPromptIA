import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { ArrowLeft, Camera, Loader2, Settings2, User as UserIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useProfile, useUpdateProfile } from "@/lib/use-profile";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/app/perfil")({
  component: PerfilPage,
});

function PerfilPage() {
  const { user } = useAuth();
  const { data: profile } = useProfile();
  const updateProfile = useUpdateProfile();
  const fileRef = useRef<HTMLInputElement>(null);

  const [username, setUsername] = useState("");
  const [bio, setBio] = useState("");
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (profile) {
      setUsername(profile.username ?? "");
      setBio(profile.bio ?? "");
      setAvatarUrl(profile.avatar_url ?? null);
    }
  }, [profile]);

  const onPickFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (!f.type.startsWith("image/")) {
      toast.error("Selecione uma imagem");
      return;
    }
    if (f.size > 5 * 1024 * 1024) {
      toast.error("Máximo 5MB");
      return;
    }
    setPendingFile(f);
    const reader = new FileReader();
    reader.onload = () => setPreview(reader.result as string);
    reader.readAsDataURL(f);
  };

  const handleSave = async () => {
    if (!user || saving) return;
    if (username.trim().length < 2) {
      toast.error("Username deve ter no mínimo 2 caracteres");
      return;
    }
    setSaving(true);
    try {
      let newAvatarUrl = avatarUrl;
      if (pendingFile) {
        const ext = pendingFile.name.split(".").pop()?.toLowerCase() ?? "jpg";
        const path = `${user.id}/avatar-${Date.now()}.${ext}`;
        const { error: upErr } = await supabase.storage
          .from("avatars")
          .upload(path, pendingFile, { cacheControl: "3600", upsert: true });
        if (upErr) throw upErr;
        const { data: pub } = supabase.storage.from("avatars").getPublicUrl(path);
        newAvatarUrl = pub.publicUrl;
      }
      await updateProfile.mutateAsync({
        username: username.trim(),
        bio: bio.trim() || null,
        avatar_url: newAvatarUrl,
      });
      setAvatarUrl(newAvatarUrl);
      setPendingFile(null);
      setPreview(null);
      toast.success("Perfil atualizado!");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Erro ao salvar");
    } finally {
      setSaving(false);
    }
  };

  const displayAvatar = preview ?? avatarUrl;

  return (
    <div className="max-w-xl mx-auto animate-slide-up pb-8">
      <Link to="/app">
        <Button variant="ghost" size="sm" className="mb-4">
          <ArrowLeft className="h-4 w-4 mr-1" /> Voltar
        </Button>
      </Link>

      <div className="rounded-2xl bg-gradient-surface border border-border/50 p-6 shadow-elevated">
        <h1 className="text-2xl font-bold tracking-tight">Meu perfil</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Personalize sua identidade no BOSSFIT.
        </p>

        <div className="mt-6 flex flex-col items-center gap-3">
          <div className="relative">
            <div className="h-28 w-28 rounded-full overflow-hidden border-2 border-primary/40 shadow-glow bg-muted flex items-center justify-center">
              {displayAvatar ? (
                <img src={displayAvatar} alt="Avatar" className="h-full w-full object-cover" />
              ) : (
                <UserIcon className="h-12 w-12 text-muted-foreground" />
              )}
            </div>
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="absolute bottom-0 right-0 h-9 w-9 rounded-full bg-gradient-primary text-primary-foreground flex items-center justify-center shadow-glow hover:opacity-90"
              aria-label="Trocar foto"
            >
              <Camera className="h-4 w-4" />
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={onPickFile}
            />
          </div>
          {pendingFile && (
            <p className="text-xs text-primary">Pré-visualização — clique em Salvar para confirmar</p>
          )}
        </div>

        <div className="mt-6 space-y-4">
          <div>
            <Label htmlFor="username">Nome de usuário</Label>
            <Input
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              maxLength={40}
              placeholder="boss_atleta"
            />
          </div>
          <div>
            <Label htmlFor="bio">Biografia</Label>
            <Textarea
              id="bio"
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              maxLength={240}
              rows={3}
              placeholder="Conte um pouco sobre seus objetivos..."
            />
            <div className="text-[10px] text-muted-foreground text-right mt-1">
              {bio.length}/240
            </div>
          </div>
          <div className="text-xs text-muted-foreground">
            Email: <span className="text-foreground">{profile?.email ?? user?.email}</span>
          </div>
        </div>

        <Button
          onClick={handleSave}
          disabled={saving}
          className="w-full mt-6 bg-gradient-primary text-primary-foreground hover:opacity-90 shadow-glow h-11"
        >
          {saving ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" /> Salvando...
            </>
          ) : (
            "Salvar alterações"
          )}
        </Button>
      </div>

      {/* Editar dados do quiz */}
      <div className="mt-4 rounded-2xl bg-gradient-surface border border-border/50 p-5 shadow-elevated">
        <div className="flex items-start gap-3">
          <div className="h-10 w-10 rounded-xl bg-primary/15 text-primary flex items-center justify-center shrink-0">
            <Settings2 className="h-5 w-5" />
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="font-bold">Editar meus dados</h2>
            <p className="text-xs text-muted-foreground mt-1">
              Refaça o quiz para atualizar objetivo, foco muscular, frequência, peso, altura e
              cuidados. Seu histórico é mantido — apenas o plano e o treino de hoje são regerados.
            </p>
            <Link to="/app/quiz" search={{ edit: true }}>
              <Button
                variant="outline"
                className="mt-3 w-full sm:w-auto border-primary/40 text-primary hover:bg-primary/10"
              >
                <Settings2 className="h-4 w-4 mr-2" />
                Editar meus dados
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
