import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { z } from "zod";
import { ChevronLeft, ChevronRight, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useProfile, useUpdateProfile } from "@/lib/use-profile";
import { generateWeeklyPlan, generateIntelligentWorkout } from "@/lib/workout-generator";
import type { Quiz } from "@/lib/types";
import { toast } from "sonner";

type QuizSearch = { edit?: boolean };

export const Route = createFileRoute("/app/quiz")({
  component: QuizPage,
  validateSearch: (search: Record<string, unknown>): QuizSearch => ({
    edit: search.edit === true || search.edit === "1" || search.edit === "true",
  }),
});

const quizSchema = z.object({
  objetivo: z.enum(["hipertrofia", "emagrecimento", "forca", "condicionamento"]),
  objetivos: z
    .array(z.enum(["hipertrofia", "emagrecimento", "forca", "condicionamento"]))
    .min(1),
  nivel: z.enum(["iniciante", "intermediario", "avancado"]),
  frequencia: z.number().int().min(1).max(7),
  focoMuscular: z.enum(["peito", "costas", "pernas", "ombros", "bracos", "core", "fullbody"]),
  focosMusculares: z
    .array(z.enum(["peito", "costas", "pernas", "ombros", "bracos", "core", "fullbody"]))
    .min(1),
  biotipo: z.enum(["ectomorfo", "endomorfo", "mesomorfo"]),
  peso: z.number().min(30).max(300),
  altura: z.number().min(120).max(230),
  injuries: z
    .array(z.enum(["joelho", "ombro", "coluna", "punho", "tornozelo", "cotovelo", "quadril"]))
    .optional(),
});

const STEPS = [
  "Quais são os seus objetivos?",
  "Qual o seu nível atual?",
  "Quantos dias por semana?",
  "Quais focos musculares?",
  "Qual é o seu tipo de biotipo?",
  "Seu peso atual",
  "Sua altura",
  "Alguma área pra cuidar?",
] as const;

const INJURY_OPTIONS: Array<{ value: NonNullable<Quiz["injuries"]>[number]; label: string }> = [
  { value: "joelho", label: "Joelho" },
  { value: "ombro", label: "Ombro" },
  { value: "coluna", label: "Coluna" },
  { value: "punho", label: "Punho" },
  { value: "tornozelo", label: "Tornozelo" },
  { value: "cotovelo", label: "Cotovelo" },
  { value: "quadril", label: "Quadril" },
];

function QuizPage() {
  const { data: profile } = useProfile();
  const updateProfile = useUpdateProfile();
  const navigate = useNavigate();
  const search = Route.useSearch();
  const isEdit = !!search.edit && !!profile?.quiz_completed;
  const [step, setStep] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [answers, setAnswers] = useState<Partial<Quiz>>(() => {
    const q = (profile?.quiz ?? {}) as Partial<Quiz>;
    return {
      ...q,
      objetivos: q.objetivos ?? (q.objetivo ? [q.objetivo] : []),
      focosMusculares: q.focosMusculares ?? (q.focoMuscular ? [q.focoMuscular] : []),
    };
  });
  const [submitting, setSubmitting] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);

  const setField = <K extends keyof Quiz>(key: K, value: Quiz[K]) => {
    setAnswers((a) => ({ ...a, [key]: value }));
    setError(null);
  };

  const toggleInArray = <T extends string>(key: keyof Quiz, value: T) => {
    setAnswers((a) => {
      const arr = (a[key] as T[] | undefined) ?? [];
      const next = arr.includes(value) ? arr.filter((v) => v !== value) : [...arr, value];
      return { ...a, [key]: next } as Partial<Quiz>;
    });
    setError(null);
  };

  const validateStep = (): boolean => {
    const a = answers;
    setError(null);
    switch (step) {
      case 0:
        if (!a.objetivos || a.objetivos.length === 0) return setErr("Escolha pelo menos um objetivo");
        return true;
      case 1:
        if (!a.nivel) return setErr("Escolha um nível");
        return true;
      case 2:
        if (!a.frequencia || a.frequencia < 1 || a.frequencia > 7) return setErr("Escolha 1 a 7");
        return true;
      case 3:
        if (!a.focosMusculares || a.focosMusculares.length === 0) return setErr("Escolha pelo menos um foco");
        return true;
      case 4:
        if (!a.biotipo) return setErr("Escolha seu biotipo");
        return true;
      case 5:
        if (!a.peso || a.peso < 30 || a.peso > 300) return setErr("Peso entre 30 e 300 kg");
        return true;
      case 6:
        if (!a.altura || a.altura < 120 || a.altura > 230) return setErr("Altura entre 120 e 230 cm");
        return true;
      case 7:
        return true; // injuries é opcional
    }
    return false;
  };
  const setErr = (msg: string) => { setError(msg); return false; };

  const handleNext = (e?: FormEvent) => {
    e?.preventDefault();
    if (!validateStep()) return;
    if (step < STEPS.length - 1) {
      setStep(step + 1);
    } else if (isEdit) {
      setConfirmOpen(true);
    } else {
      handleFinish();
    }
  };

  const handleFinish = async () => {
    setSubmitting(true);
    try {
      // Preencher singulares com a primeira opção selecionada (compat. com gerador)
      const objetivos = answers.objetivos ?? [];
      const focos = answers.focosMusculares ?? [];
      const merged: Partial<Quiz> = {
        ...answers,
        objetivo: objetivos[0],
        focoMuscular: focos[0],
      };
      const parsedFinal = quizSchema.safeParse(merged);
      if (!parsedFinal.success) {
        setError(parsedFinal.error.issues[0]?.message ?? "Respostas inválidas");
        setSubmitting(false);
        return;
      }
      const quiz = parsedFinal.data;
      const weeklyPlan = generateWeeklyPlan(quiz);
      const todayIdx = new Date().getDay();
      const planDay = weeklyPlan.days[todayIdx % weeklyPlan.days.length];
      const dailyWorkout = generateIntelligentWorkout({ quiz }, [], planDay?.focus);
      await updateProfile.mutateAsync({
        quiz,
        quiz_completed: true,
        weekly_plan: weeklyPlan,
        daily_workout: dailyWorkout,
        goals: {
          workoutsPerWeek: quiz.frequencia,
          targetWeight: profile?.goals?.targetWeight ?? null,
        },
      });
      if (isEdit) {
        toast.success("Seus treinos foram atualizados com base nas novas informações 💪");
      } else {
        toast.success("Quiz concluído! Seu primeiro treino está pronto.");
      }
      navigate({ to: "/app" });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Erro ao salvar");
    } finally {
      setSubmitting(false);
      setConfirmOpen(false);
    }
  };

  const progressPct = ((step + 1) / STEPS.length) * 100;

  return (
    <div className="max-w-xl mx-auto py-4 animate-slide-up">
      <div className="mb-6">
        <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
          <span>Passo {step + 1} de {STEPS.length}</span>
          <span>{Math.round(progressPct)}%</span>
        </div>
        <div className="h-1.5 bg-muted rounded-full overflow-hidden">
          <div className="h-full bg-gradient-primary transition-all duration-300" style={{ width: `${progressPct}%` }} />
        </div>
      </div>

      <div className="rounded-2xl glass p-6 md:p-8 shadow-elevated">
        <div className="flex items-center gap-2 text-xs text-primary uppercase tracking-wider font-semibold mb-3">
          <Sparkles className="h-3.5 w-3.5" />
          {isEdit ? "Editar meus dados" : "Configuração inicial"}
        </div>
        <h1 className="text-2xl font-bold tracking-tight">{STEPS[step]}</h1>
        {isEdit && (
          <p className="text-xs text-muted-foreground mt-2">
            Alterar dados aqui regera seu plano semanal e o treino do dia. Seu histórico é preservado.
          </p>
        )}

        <form onSubmit={handleNext} className="mt-6 space-y-4">
          {step === 0 && (
            <OptionGrid
              multi
              values={answers.objetivos ?? []}
              onToggle={(v) => toggleInArray("objetivos", v as Quiz["objetivo"])}
              options={[
                { value: "hipertrofia", label: "Hipertrofia", desc: "Ganhar músculo" },
                { value: "emagrecimento", label: "Emagrecimento", desc: "Perder gordura" },
                { value: "forca", label: "Força", desc: "Ficar mais forte" },
                { value: "condicionamento", label: "Condicionamento", desc: "Resistência geral" },
              ]}
            />
          )}
          {step === 1 && (
            <OptionGrid
              value={answers.nivel}
              onChange={(v) => setField("nivel", v as Quiz["nivel"])}
              options={[
                { value: "iniciante", label: "Iniciante", desc: "< 6 meses" },
                { value: "intermediario", label: "Intermediário", desc: "6m – 2 anos" },
                { value: "avancado", label: "Avançado", desc: "+ 2 anos" },
              ]}
            />
          )}
          {step === 2 && (
            <div className="grid grid-cols-7 gap-2">
              {[1, 2, 3, 4, 5, 6, 7].map((n) => (
                <button
                  key={n}
                  type="button"
                  onClick={() => setField("frequencia", n)}
                  className={`aspect-square rounded-xl border text-lg font-bold transition ${
                    answers.frequencia === n
                      ? "border-primary bg-primary/15 text-primary shadow-glow"
                      : "border-border bg-surface hover:bg-accent"
                  }`}
                >
                  {n}
                </button>
              ))}
            </div>
          )}
          {step === 3 && (
            <OptionGrid
              multi
              values={answers.focosMusculares ?? []}
              onToggle={(v) => toggleInArray("focosMusculares", v as Quiz["focoMuscular"])}
              options={[
                { value: "peito", label: "Peito" },
                { value: "costas", label: "Costas" },
                { value: "pernas", label: "Pernas" },
                { value: "ombros", label: "Ombros" },
                { value: "bracos", label: "Braços" },
                { value: "core", label: "Core" },
                { value: "fullbody", label: "Fullbody", desc: "Corpo inteiro" },
              ]}
            />
          )}
          {step === 4 && (
            <div className="space-y-3">
              <OptionGrid
                value={answers.biotipo}
                onChange={(v) => setField("biotipo", v as NonNullable<Quiz["biotipo"]>)}
                options={[
                  { value: "ectomorfo", label: "Ectomorfo", desc: "Corpo mais magro, dificuldade para ganhar massa" },
                  { value: "endomorfo", label: "Endomorfo", desc: "Facilidade para ganhar gordura, metabolismo mais lento" },
                  { value: "mesomorfo", label: "Mesomorfo", desc: "Ganha massa muscular com mais facilidade" },
                ]}
              />
              <p className="text-[11px] text-muted-foreground italic leading-relaxed text-left">
                👉 Como descobrir seu biotipo? Observe seu corpo naturalmente: pessoas magras
                tendem a ser ectomorfas, corpos com facilidade para engordar são endomorfos,
                e corpos naturalmente mais musculosos são mesomorfos.
              </p>
            </div>
          )}
          {step === 5 && (
            <div>
              <Label htmlFor="peso">Peso (kg)</Label>
              <Input
                id="peso"
                type="number"
                inputMode="decimal"
                min={30}
                max={300}
                step="0.1"
                value={answers.peso ?? ""}
                onChange={(e) => setField("peso", parseFloat(e.target.value) || 0)}
                placeholder="Ex: 75"
                autoFocus
              />
            </div>
          )}
          {step === 6 && (
            <div>
              <Label htmlFor="altura">Altura (cm)</Label>
              <Input
                id="altura"
                type="number"
                inputMode="numeric"
                min={120}
                max={230}
                value={answers.altura ?? ""}
                onChange={(e) => setField("altura", parseInt(e.target.value) || 0)}
                placeholder="Ex: 178"
                autoFocus
              />
            </div>
          )}
          {step === 6 && (
            <div className="space-y-3">
              <p className="text-xs text-muted-foreground">
                Marque áreas com desconforto pra eu liberar mobilidade leve. Pode pular se não tiver nada.
              </p>
              <div className="flex flex-wrap gap-2">
                {INJURY_OPTIONS.map((o) => {
                  const selected = (answers.injuries ?? []).includes(o.value);
                  return (
                    <button
                      key={o.value}
                      type="button"
                      onClick={() => {
                        const current = new Set(answers.injuries ?? []);
                        if (current.has(o.value)) current.delete(o.value);
                        else current.add(o.value);
                        setField("injuries", Array.from(current) as Quiz["injuries"]);
                      }}
                      className={`px-3 py-2 rounded-full border text-sm font-semibold transition ${
                        selected
                          ? "border-primary bg-primary/15 text-primary shadow-glow"
                          : "border-border bg-surface hover:bg-accent"
                      }`}
                    >
                      {o.label}
                    </button>
                  );
                })}
              </div>
              <p className="text-[11px] text-muted-foreground italic">
                Sugestões gerais de recuperação. Em caso de dor intensa, procure um profissional.
              </p>
            </div>
          )}

          {error && (
            <div className="text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-md px-3 py-2">
              {error}
            </div>
          )}

          <div className="flex items-center justify-between pt-2">
            <Button
              type="button"
              variant="ghost"
              onClick={() => setStep(Math.max(0, step - 1))}
              disabled={step === 0}
            >
              <ChevronLeft className="h-4 w-4 mr-1" /> Voltar
            </Button>
            <Button
              type="submit"
              disabled={submitting}
              className="bg-gradient-primary text-primary-foreground hover:opacity-90 shadow-glow"
            >
              {submitting
                ? "Salvando..."
                : step === STEPS.length - 1
                ? isEdit ? "Salvar alterações" : "Finalizar"
                : "Continuar"}
              {!submitting && <ChevronRight className="h-4 w-4 ml-1" />}
            </Button>
          </div>
        </form>
      </div>

      <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar alterações</AlertDialogTitle>
            <AlertDialogDescription>
              Alterar seus dados pode modificar seus treinos. Vamos regerar seu plano semanal e o
              treino do dia. Seu histórico será preservado. Deseja continuar?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={submitting}>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              disabled={submitting}
              onClick={(e) => {
                e.preventDefault();
                handleFinish();
              }}
            >
              {submitting ? "Salvando..." : "Sim, atualizar"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

type OptionGridProps =
  | {
      multi?: false;
      value: string | undefined;
      onChange: (v: string) => void;
      values?: never;
      onToggle?: never;
      options: Array<{ value: string; label: string; desc?: string }>;
    }
  | {
      multi: true;
      values: string[];
      onToggle: (v: string) => void;
      value?: never;
      onChange?: never;
      options: Array<{ value: string; label: string; desc?: string }>;
    };

function OptionGrid(props: OptionGridProps) {
  const { options } = props;
  const isSelected = (val: string) =>
    props.multi ? props.values.includes(val) : props.value === val;
  const handleClick = (val: string) =>
    props.multi ? props.onToggle(val) : props.onChange(val);

  return (
    <div className="grid grid-cols-2 gap-2">
      {options.map((o) => {
        const selected = isSelected(o.value);
        return (
          <button
            key={o.value}
            type="button"
            onClick={() => handleClick(o.value)}
            aria-pressed={selected}
            className={`text-left p-4 rounded-xl border transition ${
              selected
                ? "border-primary bg-primary/10 shadow-glow ring-1 ring-primary/40"
                : "border-border bg-surface hover:bg-accent"
            }`}
          >
            <div className="flex items-start justify-between gap-2">
              <div className="font-semibold">{o.label}</div>
              {props.multi && (
                <span
                  className={`mt-0.5 h-4 w-4 shrink-0 rounded border flex items-center justify-center text-[10px] ${
                    selected
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-border"
                  }`}
                >
                  {selected ? "✓" : ""}
                </span>
              )}
            </div>
            {o.desc && <div className="text-xs text-muted-foreground mt-0.5">{o.desc}</div>}
          </button>
        );
      })}
    </div>
  );
}
