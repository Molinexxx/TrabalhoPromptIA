import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Trophy, Medal, Crown } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/app/ranking")({
  component: RankingPage,
});

interface RankingRow {
  id: string;
  username: string | null;
  ranking_score: number;
  streak: number;
}

function RankingPage() {
  const { user } = useAuth();
  const { data: ranking = [], isLoading } = useQuery({
    queryKey: ["ranking"],
    queryFn: async (): Promise<RankingRow[]> => {
      const { data, error } = await supabase
        .from("profiles")
        .select("id, username, ranking_score, streak")
        .order("ranking_score", { ascending: false })
        .limit(50);
      if (error) throw error;
      return (data ?? []) as RankingRow[];
    },
    refetchInterval: 30_000,
  });

  return (
    <div className="max-w-2xl mx-auto animate-slide-up">
      <div className="flex items-center gap-3 mb-6">
        <div className="h-12 w-12 rounded-xl bg-gradient-primary flex items-center justify-center shadow-glow">
          <Trophy className="h-6 w-6 text-primary-foreground" />
        </div>
        <div>
          <h1 className="text-xl font-bold">Ranking</h1>
          <p className="text-xs text-muted-foreground">Top 50 — atualiza a cada 30s</p>
        </div>
      </div>

      <div className="rounded-2xl glass overflow-hidden">
        {isLoading ? (
          <div className="p-12 text-center text-sm text-muted-foreground">Carregando...</div>
        ) : ranking.length === 0 ? (
          <div className="p-12 text-center text-sm text-muted-foreground">Nenhum atleta ainda.</div>
        ) : (
          <ul className="divide-y divide-border">
            {ranking.map((row, i) => {
              const isMe = row.id === user?.id;
              return (
                <li
                  key={row.id}
                  className={`flex items-center gap-3 px-4 py-3 transition ${
                    isMe ? "bg-primary/10" : ""
                  }`}
                >
                  <div className="w-8 flex items-center justify-center">
                    {i === 0 ? (
                      <Crown className="h-5 w-5 text-warning" />
                    ) : i === 1 ? (
                      <Medal className="h-5 w-5 text-muted-foreground" />
                    ) : i === 2 ? (
                      <Medal className="h-5 w-5 text-warning/70" />
                    ) : (
                      <span className="text-xs font-bold text-muted-foreground">#{i + 1}</span>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold truncate">
                      {row.username ?? "atleta"}
                      {isMe && <span className="text-xs text-primary ml-2">(você)</span>}
                    </div>
                    <div className="text-xs text-muted-foreground">{row.streak} dias de streak</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-primary">{row.ranking_score}</div>
                    <div className="text-[10px] text-muted-foreground uppercase">pts</div>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
