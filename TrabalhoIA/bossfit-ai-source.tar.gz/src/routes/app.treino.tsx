import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, Check, CheckCircle2, Clock, Dumbbell, PlayCircle, Target, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useProfile, useUpdateProfile } from "@/lib/use-profile";
import { useAuth } from "@/lib/auth";
import type { Exercise, Quiz, Workout } from "@/lib/types";
import { VideoModal } from "@/components/VideoModal";
import { ExerciseImage } from "@/components/ExerciseImage";
import { generateIntelligentWorkout } from "@/lib/workout-generator";

export const Route = createFileRoute("/app/treino")({
  component: WorkoutPage,
});

function WorkoutPage() {
  // Navegação via <Link>; sem navigate() programático.
  const { user } = useAuth();
  const { data: profile } = useProfile();
  const updateProfile = useUpdateProfile();
  const [workout, setWorkout] = useState<Workout | null>(null);
  const [video, setVideo] = useState<{ id: string | null; title: string } | null>(null);
  const todayKey = new Date().toISOString().slice(0, 10);
  const hasDailyWorkout = !!(profile?.daily_workout && "id" in profile.daily_workout);
  const workoutCompletedToday = !!user && !!profile && profile.last_workout_date === todayKey && !hasDailyWorkout;

  useEffect(() => {
    if (!profile) return;
    const completedToday = profile.last_workout_date === new Date().toISOString().slice(0, 10);
    const hasWorkoutToday = !!(profile.daily_workout && "id" in profile.daily_workout);
    if (completedToday && !hasWorkoutToday) {
      if (workout) setWorkout(null);
      return;
    }
    if (workout) return;
    if (profile.daily_workout && "id" in profile.daily_workout) {
      setWorkout(profile.daily_workout as Workout);
      return;
    }
    if (profile.quiz && profile.quiz_completed) {
      try {
        const quiz = profile.quiz as Quiz;
        const todayIdx = new Date().getDay();
        const days = profile.weekly_plan?.days;
        const planDay = days?.[todayIdx % (days?.length || 1)];
        const fresh = generateIntelligentWorkout({ quiz }, [], planDay?.focus);
        setWorkout(fresh);
        updateProfile.mutate({ daily_workout: fresh });
      } catch {
        // mantém loading; usuário ainda pode entrar no focus pelo botão
      }
    }
  }, [profile, workout, updateProfile]);

  const totalSets = useMemo(() => {
    if (!workout) return 0;
    return [...workout.warmup, ...workout.main, ...workout.finisher].reduce(
      (s, e) => s + e.sets,
      0,
    );
  }, [workout]);

  // Navegação direta via <Link> — mais confiável que navigate() programático.

  if (workoutCompletedToday) {
    return (
      <div className="max-w-2xl mx-auto p-6 animate-slide-up">
        <Link to="/app">
          <Button variant="ghost" size="sm" className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-1" /> Voltar
          </Button>
        </Link>
        <div className="min-h-[55vh] flex flex-col items-center justify-center text-center rounded-3xl border border-primary/30 bg-gradient-surface p-8 shadow-elevated">
          <div className="h-16 w-16 rounded-full bg-gradient-primary text-primary-foreground flex items-center justify-center shadow-glow mb-4">
            <CheckCircle2 className="h-9 w-9" />
          </div>
          <div className="text-[11px] uppercase tracking-widest text-primary font-black mb-2">
            Treino concluído
          </div>
          <h1 className="text-3xl font-black leading-tight">Treino concluído</h1>
          <p className="text-sm text-muted-foreground mt-2 max-w-sm">
            O treino de hoje já foi finalizado e registrado no seu histórico.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 w-full mt-6">
            <Button asChild variant="outline" className="h-12 font-bold">
              <Link to="/app/evolucao">Ver evolução</Link>
            </Button>
            <Button asChild className="h-12 bg-gradient-primary text-primary-foreground hover:opacity-90 font-black">
              <Link to="/app">Voltar ao painel</Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (!workout || !user) {
    return (
      <div className="max-w-2xl mx-auto p-6 flex flex-col items-center justify-center gap-4 min-h-[60vh]">
        <div className="h-10 w-10 rounded-full border-4 border-primary border-t-transparent animate-spin" />
        <p className="text-sm text-muted-foreground font-medium">Preparando seu treino…</p>
        <Button asChild className="mt-2">
          <Link to="/app/treino/focus">
            <PlayCircle className="h-5 w-5 mr-2" /> Iniciar treino mesmo assim
          </Link>
        </Button>
      </div>
    );
  }

  const sections: Array<{ label: string; items: Exercise[] }> = [
    { label: "Aquecimento", items: workout.warmup },
    { label: "Principal", items: workout.main },
    { label: "Finalizador", items: workout.finisher },
  ];

  return (
    <div className="max-w-2xl mx-auto animate-slide-up pb-8">
      <Link to="/app">
        <Button variant="ghost" size="sm" className="mb-4">
          <ArrowLeft className="h-4 w-4 mr-1" /> Voltar
        </Button>
      </Link>

      {/* Hero do treino */}
      <div className="relative overflow-hidden rounded-3xl border border-primary/30 shadow-elevated">
        {/* Background com gradiente animado */}
        <div className="absolute inset-0 bg-gradient-primary opacity-90" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.25),transparent_60%)]" />
        <div className="absolute -top-20 -right-20 h-56 w-56 rounded-full bg-white/10 blur-3xl animate-pulse" />
        <div className="absolute -bottom-16 -left-16 h-48 w-48 rounded-full bg-primary-glow/30 blur-3xl" />

        <div className="relative p-6 text-primary-foreground">
          <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.2em] font-black mb-3">
            <span className="h-2 w-2 rounded-full bg-primary-foreground animate-pulse" />
            Treino de hoje
          </div>
          <h1 className="text-2xl md:text-3xl font-black leading-tight drop-shadow-sm">
            {workout.title}
          </h1>
          <p className="text-sm text-primary-foreground/85 mt-1 font-medium">{workout.focus}</p>

          {/* Stat chips */}
          <div className="grid grid-cols-3 gap-2 mt-5">
            <div className="rounded-2xl bg-background/15 backdrop-blur-md border border-white/20 p-3 text-center">
              <Clock className="h-4 w-4 mx-auto mb-1 opacity-90" />
              <div className="text-xl font-black tabular-nums">{workout.estimatedMinutes}</div>
              <div className="text-[10px] uppercase tracking-wider opacity-80">min</div>
            </div>
            <div className="rounded-2xl bg-background/15 backdrop-blur-md border border-white/20 p-3 text-center">
              <Dumbbell className="h-4 w-4 mx-auto mb-1 opacity-90" />
              <div className="text-xl font-black tabular-nums">{workout.main.length}</div>
              <div className="text-[10px] uppercase tracking-wider opacity-80">exercícios</div>
            </div>
            <div className="rounded-2xl bg-background/15 backdrop-blur-md border border-white/20 p-3 text-center">
              <Target className="h-4 w-4 mx-auto mb-1 opacity-90" />
              <div className="text-xl font-black tabular-nums">{totalSets}</div>
              <div className="text-[10px] uppercase tracking-wider opacity-80">séries</div>
            </div>
          </div>

          <Button asChild className="w-full h-14 mt-5 bg-background text-foreground hover:bg-background/90 shadow-elevated text-base font-black group">
            <Link
              to="/app/treino/focus"
              onClick={() => {
                if (navigator.vibrate) navigator.vibrate(120);
              }}
            >
              <PlayCircle className="h-6 w-6 mr-2 text-primary group-hover:scale-110 transition" />
              Iniciar treino
              <Zap className="h-5 w-5 ml-2 text-primary" />
            </Link>
          </Button>
          <Button
            asChild
            variant="outline"
            className="w-full h-12 mt-2 bg-background/10 border-white/30 text-primary-foreground hover:bg-background/20 hover:text-primary-foreground font-bold"
          >
            <Link
              to="/app/treino/focus"
              search={{ finish: true }}
              onClick={() => {
                if (navigator.vibrate) navigator.vibrate([60, 40, 60]);
              }}
            >
              <CheckCircle2 className="h-5 w-5 mr-2" />
              Finalizar treino
            </Link>
          </Button>
          <p className="text-[11px] text-primary-foreground/80 text-center mt-2 font-medium">
            Modo Foco: cronômetro · descanso · feedback por exercício
          </p>
        </div>
      </div>

      {/* Mini-mapa do treino: progresso visual das seções */}
      <div className="mt-4 grid grid-cols-3 gap-2">
        {sections.map((sec) => (
          <div
            key={sec.label}
            className="rounded-xl border border-border/60 bg-surface px-3 py-2.5 text-center"
          >
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground font-bold">
              {sec.label}
            </div>
            <div className="text-base font-black mt-0.5">
              {sec.items.length}
              <span className="text-[10px] text-muted-foreground font-bold ml-1">ex</span>
            </div>
          </div>
        ))}
      </div>

      {/* Lista de exercícios com imagens */}
      <div className="mt-6 space-y-6">
        {sections.map((sec) => (
          <div key={sec.label}>
            <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-3">
              {sec.label}
            </h2>
            <div className="space-y-3">
              {sec.items.map((ex, idx) => (
                <div
                  key={ex.id + idx}
                  className="rounded-2xl border border-border bg-surface overflow-hidden hover:border-primary/40 transition"
                >
                  <div className="flex gap-3 p-3">
                    <div className="w-28 shrink-0">
                      <ExerciseImage exercise={ex} aspect="square" />
                    </div>
                    <div className="flex-1 min-w-0 flex flex-col justify-between py-1">
                      <div>
                        <div className="font-semibold leading-tight">{ex.name}</div>
                        <div className="flex items-center gap-1.5 text-xs text-muted-foreground mt-1">
                          <Dumbbell className="h-3 w-3" />
                          <span>
                            {ex.sets} x {ex.reps}
                            {sec.label === "Aquecimento" || sec.label === "Finalizador" ? "s" : " reps"}
                          </span>
                        </div>
                        {ex.rest > 0 && (
                          <div className="text-[11px] text-muted-foreground mt-0.5">
                            descanso {ex.rest}s
                          </div>
                        )}
                      </div>
                      {ex.videoId && (
                        <button
                          type="button"
                          onClick={() => setVideo({ id: ex.videoId ?? null, title: ex.name })}
                          className="self-start mt-2 inline-flex items-center gap-1 text-xs font-medium text-primary hover:underline"
                        >
                          <PlayCircle className="h-3.5 w-3.5" /> Ver técnica
                        </button>
                      )}
                    </div>
                    <div className="shrink-0 self-start h-8 w-8 rounded-full bg-muted text-muted-foreground flex items-center justify-center">
                      <Check className="h-4 w-4" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <VideoModal
        open={!!video}
        onOpenChange={(v) => !v && setVideo(null)}
        videoId={video?.id ?? null}
        title={video?.title ?? ""}
      />

    </div>
  );
}

