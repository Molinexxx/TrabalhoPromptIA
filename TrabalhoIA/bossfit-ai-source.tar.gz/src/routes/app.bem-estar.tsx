import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo } from "react";
import { ArrowLeft, Apple, HeartPulse, Info, PlayCircle, Droplets, Sparkles } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useProfile, useUpdateProfile } from "@/lib/use-profile";
import { VideoModal } from "@/components/VideoModal";
import {
  ALL_INJURIES,
  WELLNESS_DISCLAIMER,
  getNutritionPlan,
  getRecoveryProtocols,
} from "@/lib/wellness";
import type { InjuryArea, Quiz } from "@/lib/types";
import { toast } from "sonner";

export const Route = createFileRoute("/app/bem-estar")({
  component: WellnessPage,
});

const INJURY_LABELS: Record<InjuryArea, string> = {
  joelho: "Joelho",
  ombro: "Ombro",
  coluna: "Coluna",
  punho: "Punho",
  tornozelo: "Tornozelo",
  cotovelo: "Cotovelo",
  quadril: "Quadril",
};

function WellnessPage() {
  const { data: profile } = useProfile();
  const updateProfile = useUpdateProfile();
  const [video, setVideo] = useState<{ id: string; title: string } | null>(null);

  const quiz = (profile?.quiz ?? {}) as Partial<Quiz>;
  const injuries = quiz.injuries ?? [];
  const protocols = useMemo(() => getRecoveryProtocols(injuries), [injuries]);
  const nutrition = useMemo(() => getNutritionPlan(quiz.objetivo), [quiz.objetivo]);

  const toggleInjury = async (area: InjuryArea) => {
    if (!profile) return;
    const current = new Set(injuries);
    if (current.has(area)) current.delete(area);
    else current.add(area);
    const nextInjuries = Array.from(current);
    try {
      await updateProfile.mutateAsync({
        quiz: { ...(quiz as Quiz), injuries: nextInjuries },
      });
      toast.success("Áreas atualizadas");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Erro ao atualizar");
    }
  };

  return (
    <div className="space-y-6 animate-slide-up max-w-3xl mx-auto">
      <div className="flex items-center gap-3">
        <Link to="/app">
          <Button variant="ghost" size="sm" className="-ml-2">
            <ArrowLeft className="h-4 w-4 mr-1" /> Voltar
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight">
            Recuperação & <span className="text-gradient-primary">Cuidados</span>
          </h1>
          <p className="text-sm text-muted-foreground">
            Mobilidade leve, alimentação básica e hidratação. Sem firula, sem promessa médica.
          </p>
        </div>
      </div>

      {/* Disclaimer */}
      <div className="rounded-xl border border-warning/40 bg-warning/10 p-4 flex gap-3">
        <Info className="h-5 w-5 text-warning shrink-0 mt-0.5" />
        <p className="text-xs text-foreground/90 leading-relaxed">{WELLNESS_DISCLAIMER}</p>
      </div>

      {/* Injuries selector */}
      <section className="rounded-2xl bg-gradient-surface border border-border/50 p-5 shadow-card">
        <div className="flex items-center gap-2 mb-1">
          <HeartPulse className="h-4 w-4 text-primary" />
          <h2 className="font-bold">Áreas que estou cuidando</h2>
        </div>
        <p className="text-xs text-muted-foreground mb-4">
          Marque regiões com desconforto pra eu liberar protocolos leves de recuperação.
        </p>
        <div className="flex flex-wrap gap-2">
          {ALL_INJURIES.map((area) => {
            const active = injuries.includes(area);
            return (
              <button
                key={area}
                type="button"
                onClick={() => toggleInjury(area)}
                disabled={updateProfile.isPending}
                className={`px-3 py-1.5 rounded-full border text-xs font-bold transition ${
                  active
                    ? "border-primary bg-primary/15 text-primary shadow-glow"
                    : "border-border bg-surface hover:bg-accent"
                }`}
              >
                {INJURY_LABELS[area]}
              </button>
            );
          })}
        </div>
      </section>

      {/* Recovery protocols */}
      <section className="space-y-4">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          <h2 className="font-bold">Protocolos de recuperação leve</h2>
        </div>

        {protocols.length === 0 ? (
          <div className="rounded-xl glass p-6 text-center text-sm text-muted-foreground">
            Nenhuma área marcada. Selecione acima pra ver alongamentos e mobilidade.
          </div>
        ) : (
          protocols.map((p) => (
            <div
              key={p.area}
              className="rounded-2xl bg-surface border border-border/50 p-5 shadow-card"
            >
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xl">{p.emoji}</span>
                <h3 className="font-bold">{p.label}</h3>
              </div>
              <div className="text-xs text-warning bg-warning/10 border border-warning/30 rounded-lg px-3 py-2 my-2">
                ⚠ {p.warning}
              </div>
              <ul className="mt-3 space-y-3">
                {p.items.map((it, idx) => (
                  <li
                    key={idx}
                    className="rounded-xl bg-background/50 border border-border/40 p-3"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="font-semibold text-sm">{it.name}</div>
                        <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                          {it.description}
                        </p>
                        <div className="text-[11px] text-primary font-bold mt-1.5">
                          {it.duration}
                        </div>
                      </div>
                      {it.videoId && (
                        <button
                          type="button"
                          onClick={() => setVideo({ id: it.videoId!, title: it.name })}
                          className="shrink-0 inline-flex items-center gap-1 px-2.5 py-1.5 rounded-full bg-surface-elevated border border-border/60 hover:border-primary/50 text-[11px] font-medium transition"
                        >
                          <PlayCircle className="h-3.5 w-3.5 text-primary" /> Ver
                        </button>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          ))
        )}
      </section>

      {/* Nutrition */}
      <section className="rounded-2xl bg-gradient-surface border border-border/50 p-5 shadow-card">
        <div className="flex items-center gap-2 mb-1">
          <Apple className="h-4 w-4 text-primary" />
          <h2 className="font-bold">Alimentação sugerida</h2>
        </div>
        {nutrition ? (
          <>
            <div className="flex items-center gap-2 mt-2">
              <span className="text-xl">{nutrition.emoji}</span>
              <div className="font-semibold text-sm">{nutrition.title}</div>
            </div>
            <ul className="mt-3 space-y-1.5 text-sm">
              {nutrition.principles.map((p, i) => (
                <li key={i} className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span className="text-foreground/90">{p}</span>
                </li>
              ))}
            </ul>
            <div className="mt-4">
              <div className="text-xs uppercase tracking-widest text-muted-foreground font-bold mb-2">
                Exemplos do dia a dia
              </div>
              <div className="flex flex-wrap gap-2">
                {nutrition.examples.map((ex) => (
                  <span
                    key={ex}
                    className="px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-semibold border border-primary/20"
                  >
                    {ex}
                  </span>
                ))}
              </div>
            </div>
            <div className="mt-4 rounded-xl bg-background/60 border border-border/40 p-3 flex gap-2 items-start">
              <Droplets className="h-4 w-4 text-primary shrink-0 mt-0.5" />
              <p className="text-xs text-foreground/90">{nutrition.hydration}</p>
            </div>
            <p className="text-[11px] text-muted-foreground mt-3 italic">
              Sem cálculos exatos de dieta. Pra plano individualizado, fala com um nutricionista.
            </p>
          </>
        ) : (
          <p className="text-sm text-muted-foreground mt-2">
            Complete o quiz pra eu sugerir alimentação alinhada ao seu objetivo.
          </p>
        )}
      </section>

      <VideoModal
        open={!!video}
        onOpenChange={(v) => !v && setVideo(null)}
        videoId={video?.id ?? null}
        title={video?.title ?? ""}
      />
    </div>
  );
}
