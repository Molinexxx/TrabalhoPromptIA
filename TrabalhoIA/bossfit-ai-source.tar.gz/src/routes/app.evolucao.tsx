import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Activity,
  AlertTriangle,
  ArrowLeft,
  Calendar,
  Flame,
  TrendingUp,
  Trophy,
} from "lucide-react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { useProfile } from "@/lib/use-profile";
import {
  aggregateWeekly,
  evaluateFatigue,
  loadFactorTrend,
  type PerformanceRow,
} from "@/lib/progression";
import { generateAutoInsights } from "@/lib/intelligence";
import {
  detectLoadProgress,
  fetchExerciseHistory,
  groupHistoryByExercise,
  summarizeExerciseHistory,
} from "@/lib/exercise-history";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/app/evolucao")({
  component: EvolutionPage,
});

function EvolutionPage() {
  const { user } = useAuth();
  const { data: profile } = useProfile();

  const { data: history = [], isLoading } = useQuery({
    queryKey: ["performance-history", user?.id],
    enabled: !!user?.id,
    queryFn: async (): Promise<PerformanceRow[]> => {
      const { data, error } = await supabase
        .from("performance_history")
        .select(
          "recorded_at, difficulty, completion_rate, time_spent, sets_completed_total, overall_rating, exercise_feedback",
        )
        .eq("user_id", user!.id)
        .order("recorded_at", { ascending: false })
        .limit(30);
      if (error) throw error;
      return (data ?? []) as unknown as PerformanceRow[];
    },
  });

  const { data: exHistory = [] } = useQuery({
    queryKey: ["exercise-history-evo", user?.id],
    enabled: !!user?.id,
    queryFn: () => fetchExerciseHistory(user!.id, 500),
  });

  const exerciseGroups = useMemo(() => groupHistoryByExercise(exHistory), [exHistory]);
  const loadProgress = useMemo(() => detectLoadProgress(exHistory), [exHistory]);
  const exSummary = useMemo(() => summarizeExerciseHistory(exHistory), [exHistory]);
  const totalFalhas = useMemo(() => exSummary.reduce((s, e) => s + e.falha, 0), [exSummary]);

  const weekly = useMemo(() => aggregateWeekly(history, 8), [history]);
  const loadTrend = useMemo(() => loadFactorTrend(history), [history]);
  const fatigue = useMemo(() => evaluateFatigue(history), [history]);
  const insights = useMemo(() => generateAutoInsights(history), [history]);

  const totalSessions = history.length;
  const totalMinutes = useMemo(
    () => Math.round(history.reduce((s, r) => s + (r.time_spent ?? 0), 0) / 60),
    [history],
  );
  const avgComp = useMemo(
    () =>
      totalSessions
        ? Math.round(
            (history.reduce((s, r) => s + (r.completion_rate ?? 0), 0) / totalSessions) * 100,
          )
        : 0,
    [history, totalSessions],
  );
  const lastWeekSessions = weekly[weekly.length - 1]?.sessions ?? 0;
  const prevWeekSessions = weekly[weekly.length - 2]?.sessions ?? 0;
  const weeklyDelta = lastWeekSessions - prevWeekSessions;

  const fatigueColor =
    fatigue.level === "deload"
      ? "border-destructive/50 bg-destructive/10"
      : fatigue.level === "watch"
        ? "border-warning/50 bg-warning/10"
        : "border-primary/40 bg-primary/5";

  return (
    <div className="space-y-6 animate-slide-up">
      <div className="flex items-center gap-3">
        <Link to="/app">
          <Button variant="ghost" size="sm" className="-ml-2">
            <ArrowLeft className="h-4 w-4 mr-1" /> Voltar
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight">
            Sua <span className="text-gradient-primary">evolução</span>
          </h1>
          <p className="text-sm text-muted-foreground">
            Como você vem performando nas últimas semanas.
          </p>
        </div>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Kpi icon={Activity} label="Treinos (30d)" value={String(totalSessions)} />
        <Kpi icon={Calendar} label="Tempo total" value={`${totalMinutes} min`} />
        <Kpi icon={TrendingUp} label="Conclusão média" value={`${avgComp}%`} />
        <Kpi
          icon={Flame}
          label="Esta semana"
          value={`${lastWeekSessions}x`}
          sub={
            weeklyDelta === 0
              ? "estável"
              : weeklyDelta > 0
                ? `+${weeklyDelta} vs semana passada`
                : `${weeklyDelta} vs semana passada`
          }
          accent
        />
      </div>

      {/* Fatigue */}
      <div className={`rounded-2xl border p-5 ${fatigueColor}`}>
        <div className="flex items-start gap-3">
          <div
            className={`h-10 w-10 rounded-xl flex items-center justify-center ${
              fatigue.level === "deload"
                ? "bg-destructive/20 text-destructive"
                : fatigue.level === "watch"
                  ? "bg-warning/20 text-warning"
                  : "bg-primary/20 text-primary"
            }`}
          >
            {fatigue.level === "ok" ? (
              <Trophy className="h-5 w-5" />
            ) : (
              <AlertTriangle className="h-5 w-5" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs uppercase tracking-widest font-bold mb-1">
              {fatigue.level === "deload"
                ? "Atenção: deload recomendado"
                : fatigue.level === "watch"
                  ? "Sinal amarelo"
                  : "Tudo certo, boss"}
            </div>
            <p className="text-sm font-semibold">{fatigue.reason}</p>
            <p className="text-sm text-muted-foreground mt-1">{fatigue.recommendation}</p>
          </div>
        </div>
      </div>

      {/* Insights automáticos */}
      {insights.length > 0 && (
        <div className="rounded-2xl bg-gradient-surface border border-primary/30 p-5 shadow-card">
          <div className="text-xs uppercase tracking-widest text-primary font-bold mb-3">
            Insights da semana
          </div>
          <ul className="space-y-2">
            {insights.map((ins, i) => (
              <li
                key={i}
                className={`flex items-start gap-3 rounded-xl border px-3 py-2.5 ${
                  ins.positive
                    ? "border-primary/30 bg-primary/5"
                    : "border-warning/30 bg-warning/5"
                }`}
              >
                <span className="text-xl leading-none">{ins.emoji}</span>
                <span className="text-sm text-foreground/90">{ins.text}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <Card title="Evolução de carga (relativa)" subtitle="Quanto o seu peso de trabalho subiu ao longo do tempo">
        {loadTrend.length < 2 ? (
          <EmptyState text="Faça mais treinos pra eu plotar sua curva de carga." />
        ) : (
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={loadTrend}>
                <defs>
                  <linearGradient id="loadFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.4} />
                    <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                <XAxis dataKey="idx" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }} />
                <YAxis
                  domain={[0.7, 1.6]}
                  tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
                />
                <Tooltip
                  contentStyle={{
                    background: "hsl(var(--popover))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: 12,
                    fontSize: 12,
                  }}
                  labelFormatter={(v) => `Treino #${v}`}
                  formatter={(value: number) => [`${(value * 100).toFixed(0)}%`, "Carga relativa"]}
                />
                <Area
                  type="monotone"
                  dataKey="load"
                  stroke="hsl(var(--primary))"
                  strokeWidth={2}
                  fill="url(#loadFill)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}
      </Card>

      {/* Real load progression per exercise */}
      {loadProgress.length > 0 && (
        <div className="rounded-2xl bg-gradient-surface border border-primary/30 p-5 shadow-card">
          <div className="text-xs uppercase tracking-widest text-primary font-bold mb-3">
            Progresso de carga 🔥
          </div>
          <ul className="space-y-2">
            {loadProgress.map((p) => (
              <li
                key={p.exerciseName}
                className={`flex items-center justify-between gap-3 rounded-xl border px-3 py-2.5 ${
                  p.delta > 0
                    ? "border-primary/30 bg-primary/5"
                    : "border-warning/30 bg-warning/5"
                }`}
              >
                <span className="text-sm font-semibold truncate">{p.exerciseName}</span>
                <span className="text-xs text-muted-foreground tabular-nums shrink-0">
                  {p.from}kg →{" "}
                  <span
                    className={`font-black ${
                      p.delta > 0 ? "text-primary" : "text-warning"
                    }`}
                  >
                    {p.to}kg
                  </span>{" "}
                  <span
                    className={`font-bold ${
                      p.delta > 0 ? "text-primary" : "text-warning"
                    }`}
                  >
                    ({p.delta > 0 ? "+" : ""}
                    {p.delta}kg)
                  </span>
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <Card
        title="Evolução de carga real (kg)"
        subtitle={
          exerciseGroups.length === 0
            ? "Anote o peso usado no Modo Foco pra começar a tracking."
            : `${exerciseGroups.length} exercício(s) com histórico`
        }
      >
        {exerciseGroups.length === 0 ? (
          <EmptyState text="Sem registros de carga ainda. Anota o kg no próximo treino." />
        ) : (
          <div className="space-y-4 max-h-[420px] overflow-y-auto pr-1">
            {exerciseGroups.slice(0, 6).map((g) => {
              const data = g.points.map((p, i) => ({
                idx: i + 1,
                kg: Number(p.weight_kg),
                date: p.recorded_at.slice(0, 10),
              }));
              const first = data[0]?.kg ?? 0;
              const last = data[data.length - 1]?.kg ?? 0;
              const delta = Math.round((last - first) * 10) / 10;
              return (
                <div
                  key={g.exerciseId}
                  className="rounded-xl bg-background/40 border border-border/50 p-3"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-sm font-bold truncate">{g.exerciseName}</div>
                    <div className="text-xs tabular-nums">
                      <span className="text-foreground font-bold">{last}kg</span>
                      {data.length > 1 && delta !== 0 && (
                        <span
                          className={`ml-1 font-bold ${
                            delta > 0 ? "text-primary" : "text-warning"
                          }`}
                        >
                          ({delta > 0 ? "+" : ""}
                          {delta})
                        </span>
                      )}
                    </div>
                  </div>
                  {data.length >= 2 ? (
                    <div className="h-24">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={data}>
                          <XAxis dataKey="idx" hide />
                          <YAxis hide domain={["dataMin - 2", "dataMax + 2"]} />
                          <Tooltip
                            contentStyle={{
                              background: "hsl(var(--popover))",
                              border: "1px solid hsl(var(--border))",
                              borderRadius: 12,
                              fontSize: 12,
                            }}
                            formatter={(v: number) => [`${v}kg`, "Carga"]}
                            labelFormatter={(v) => `Sessão #${v}`}
                          />
                          <Line
                            type="monotone"
                            dataKey="kg"
                            stroke="hsl(var(--primary))"
                            strokeWidth={2.5}
                            dot={{ fill: "hsl(var(--primary))", r: 3 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  ) : (
                    <div className="text-[11px] text-muted-foreground">
                      Apenas 1 registro — faça mais treinos pra ver a curva.
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </Card>

      {/* Resumo por exercício: feedback + carga */}
      {exSummary.length > 0 && (
        <Card
          title="Histórico por exercício"
          subtitle={
            totalFalhas > 0
              ? `${exSummary.length} exercício(s) registrados · ${totalFalhas} falha(s) total`
              : `${exSummary.length} exercício(s) registrados`
          }
        >
          <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
            {exSummary.slice(0, 12).map((s) => {
              const total = s.leve + s.medio + s.pesado + s.falha;
              const pct = (n: number) => (total ? (n / total) * 100 : 0);
              return (
                <div
                  key={s.exerciseId}
                  className="rounded-xl border border-border/50 bg-background/40 p-3"
                >
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <div className="text-sm font-bold truncate">{s.exerciseName}</div>
                    <div className="text-[11px] tabular-nums text-muted-foreground shrink-0">
                      {s.sessions}x · atual{" "}
                      <span className="text-foreground font-bold">{s.lastKg}kg</span>
                      {s.maxKg > s.lastKg && (
                        <>
                          {" "}· máx <span className="text-primary font-bold">{s.maxKg}kg</span>
                        </>
                      )}
                    </div>
                  </div>
                  {total > 0 && (
                    <div className="h-2 rounded-full overflow-hidden bg-muted flex mb-2">
                      {s.leve > 0 && (
                        <div className="bg-primary" style={{ width: `${pct(s.leve)}%` }} />
                      )}
                      {s.medio > 0 && (
                        <div className="bg-primary-glow" style={{ width: `${pct(s.medio)}%` }} />
                      )}
                      {s.pesado > 0 && (
                        <div className="bg-warning" style={{ width: `${pct(s.pesado)}%` }} />
                      )}
                      {s.falha > 0 && (
                        <div className="bg-destructive" style={{ width: `${pct(s.falha)}%` }} />
                      )}
                    </div>
                  )}
                  <div className="flex flex-wrap gap-1.5 text-[11px]">
                    {s.leve > 0 && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-primary/15 text-primary px-2 py-0.5 font-bold">
                        😎 {s.leve}
                      </span>
                    )}
                    {s.medio > 0 && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-muted text-foreground/80 px-2 py-0.5 font-bold">
                        💪 {s.medio}
                      </span>
                    )}
                    {s.pesado > 0 && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-warning/20 text-warning px-2 py-0.5 font-bold">
                        🥵 {s.pesado}
                      </span>
                    )}
                    {s.falha > 0 && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-destructive/20 text-destructive px-2 py-0.5 font-bold">
                        ❌ {s.falha} falha{s.falha > 1 ? "s" : ""}
                      </span>
                    )}
                    {total === 0 && (
                      <span className="text-muted-foreground">Sem feedback registrado ainda.</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      )}

      {/* Weekly consistency */}
      <Card title="Consistência semanal" subtitle="Treinos por semana nas últimas 8 semanas">
        {weekly.every((w) => w.sessions === 0) ? (
          <EmptyState text="Sem dados ainda. Bora treinar?" />
        ) : (
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weekly}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                <XAxis
                  dataKey="weekLabel"
                  tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
                />
                <YAxis
                  allowDecimals={false}
                  tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
                />
                <Tooltip
                  contentStyle={{
                    background: "hsl(var(--popover))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: 12,
                    fontSize: 12,
                  }}
                  formatter={(value: number) => [`${value} treinos`, "Sessões"]}
                />
                <Bar dataKey="sessions" fill="hsl(var(--primary))" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </Card>

      {/* Difficulty trend */}
      <Card title="Esforço percebido" subtitle="Dificuldade média por semana (1 leve · 5 brutal)">
        {weekly.every((w) => w.avgDifficulty === 0) ? (
          <EmptyState text="Avalie seus treinos pra ver essa curva." />
        ) : (
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={weekly}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                <XAxis
                  dataKey="weekLabel"
                  tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
                />
                <YAxis
                  domain={[0, 5]}
                  tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
                />
                <Tooltip
                  contentStyle={{
                    background: "hsl(var(--popover))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: 12,
                    fontSize: 12,
                  }}
                  formatter={(value: number) => [value.toFixed(1), "Dificuldade"]}
                />
                <Line
                  type="monotone"
                  dataKey="avgDifficulty"
                  stroke="hsl(var(--primary-glow))"
                  strokeWidth={2}
                  dot={{ fill: "hsl(var(--primary))", r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
      </Card>

      {/* Profile signal */}
      <div className="rounded-2xl glass p-5">
        <div className="flex items-center justify-between gap-4">
          <div>
            <div className="text-xs uppercase tracking-widest text-muted-foreground font-bold">
              Carga relativa atual
            </div>
            <div className="text-3xl font-black mt-1">
              {((profile?.progression?.loadFactor ?? 1) * 100).toFixed(0)}%
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Aplicada automaticamente nas suas próximas sugestões.
            </p>
          </div>
          <Link to="/app/treino">
            <Button className="bg-gradient-primary text-primary-foreground hover:opacity-90 shadow-glow">
              Treinar agora
            </Button>
          </Link>
        </div>
      </div>

      {/* Wellness CTA */}
      <Link
        to="/app/bem-estar"
        className="block rounded-2xl border border-primary/30 bg-primary/5 p-5 hover:shadow-glow transition"
      >
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-primary/20 text-primary flex items-center justify-center shrink-0">
            ❤️
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs uppercase tracking-widest text-primary font-bold">
              Recuperação & Cuidados
            </div>
            <p className="text-sm text-muted-foreground">
              Mobilidade leve, alongamentos e alimentação alinhada ao seu objetivo.
            </p>
          </div>
          <div className="text-xs text-primary font-bold">Abrir →</div>
        </div>
      </Link>

      {isLoading && (
        <div className="text-center text-sm text-muted-foreground">Carregando histórico…</div>
      )}
    </div>
  );
}

function Kpi({
  icon: Icon,
  label,
  value,
  sub,
  accent,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
  sub?: string;
  accent?: boolean;
}) {
  return (
    <div className={`rounded-xl glass p-4 ${accent ? "shadow-glow" : "shadow-card"}`}>
      <div className="flex items-center gap-2 text-muted-foreground text-xs">
        <Icon className={`h-4 w-4 ${accent ? "text-primary" : ""}`} />
        {label}
      </div>
      <div className="text-xl font-bold mt-2">{value}</div>
      {sub && <div className="text-xs text-muted-foreground mt-0.5">{sub}</div>}
    </div>
  );
}

function Card({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl bg-gradient-surface border border-border/50 p-5 shadow-card">
      <div className="mb-4">
        <h3 className="font-bold">{title}</h3>
        {subtitle && <p className="text-xs text-muted-foreground mt-0.5">{subtitle}</p>}
      </div>
      {children}
    </div>
  );
}

function EmptyState({ text }: { text: string }) {
  return (
    <div className="h-32 flex items-center justify-center text-sm text-muted-foreground text-center px-6">
      {text}
    </div>
  );
}
