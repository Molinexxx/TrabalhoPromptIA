import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  Check,
  ChevronRight,
  Clock,
  Flame,
  Pause,
  Play,
  PlayCircle,
  RefreshCcw,
  RotateCcw,
  Star,
  Target,
  Timer,
  Trophy,
  TrendingUp,
  X,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useProfile, useUpdateProfile } from "@/lib/use-profile";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { toast } from "sonner";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { VideoModal } from "@/components/VideoModal";
import { ExerciseImage } from "@/components/ExerciseImage";
import type {
  Challenges,
  Exercise,
  ExerciseFeedback,
  Profile,
  Quiz,
  Workout,
} from "@/lib/types";
import { suggestedLoadForExercise, type PerformanceRow } from "@/lib/progression";
import {
  adaptiveMessage,
  adaptiveSignal,
  estimateExerciseKg,
  expectedSecondsPerSet,
} from "@/lib/intelligence";
import { EXERCISE_LIBRARY } from "@/lib/exercises";
import { generateIntelligentWorkout } from "@/lib/workout-generator";
import { getPostWorkoutTips } from "@/lib/wellness";
import {
  fetchExerciseHistory,
  saveExerciseHistory,
  suggestNextWeight,
  type ExerciseHistoryEntry,
} from "@/lib/exercise-history";
import type { ExerciseHistoryRow } from "@/lib/types";

type FocusSearch = { finish?: boolean };
export const Route = createFileRoute("/app/treino/focus")({
  component: FocusModePage,
  validateSearch: (search: Record<string, unknown>): FocusSearch => ({
    finish:
      search.finish === "1" || search.finish === 1 || search.finish === true ? true : undefined,
  }),
});

type FlatExercise = Exercise & {
  section: "warmup" | "main" | "finisher";
  sectionLabel: string;
  globalIdx: number;
};

function FocusModePage() {
  const navigate = useNavigate();
  const searchParams = Route.useSearch();
  const { user } = useAuth();
  const { data: profile } = useProfile();
  const updateProfile = useUpdateProfile();
  const queryClient = useQueryClient();

  const [workout, setWorkout] = useState<Workout | null>(null);
  const [startedAt] = useState(() => Date.now());
  const [currentIdx, setCurrentIdx] = useState(0);
  const [setsDone, setSetsDone] = useState(0);
  const [restSecs, setRestSecs] = useState(0);
  const [restRunning, setRestRunning] = useState(false);
  const [feedbacks, setFeedbacks] = useState<Record<string, ExerciseFeedback>>({});
  const [showFinishModal, setShowFinishModal] = useState(false);
  const autoFinishTriggered = useRef(false);
  const [overallRating, setOverallRating] = useState<number>(0);
  const [overallNotes, setOverallNotes] = useState("");
  const [finishing, setFinishing] = useState(false);
  const [workoutCompleted, setWorkoutCompleted] = useState(false);
  const [summary, setSummary] = useState<{
    completionRate: number;
    timeSpent: number;
    setsCompleted: number;
    totalSets: number;
    xpGained: number;
    newStreak: number;
    newLevel: number;
    leveledUp: boolean;
  } | null>(null);
  const [video, setVideo] = useState<{ id: string | null; title: string } | null>(null);
  // Timer por exercício e série (Wave 3)
  const [exerciseStartedAt, setExerciseStartedAt] = useState<number>(() => Date.now());
  const [setStartedAt, setSetStartedAt] = useState<number>(() => Date.now());
  const [exerciseElapsed, setExerciseElapsed] = useState(0); // segundos
  const [setElapsed, setSetElapsed] = useState(0);
  const [adaptiveHint, setAdaptiveHint] = useState<string | null>(null);
  // Carga real registrada pelo usuário (kg) por exercício (id+globalIdx)
  const [weights, setWeights] = useState<Record<string, number>>({});
  // Exercícios concluídos (chave = id+globalIdx). Salvo no banco imediatamente.
  const [completedEx, setCompletedEx] = useState<Record<string, boolean>>({});
  const [savingEx, setSavingEx] = useState<Record<string, boolean>>({});

  const { data: perfHistory = [] } = useQuery({
    queryKey: ["perf-history-focus", user?.id],
    enabled: !!user?.id,
    queryFn: async (): Promise<PerformanceRow[]> => {
      const { data, error } = await supabase
        .from("performance_history")
        .select("recorded_at, difficulty, completion_rate, time_spent, sets_completed_total, overall_rating, exercise_feedback")
        .eq("user_id", user!.id)
        .order("recorded_at", { ascending: false })
        .limit(10);
      if (error) throw error;
      return (data ?? []) as unknown as PerformanceRow[];
    },
  });

  const { data: exHistory = [] } = useQuery({
    queryKey: ["exercise-history-focus", user?.id],
    enabled: !!user?.id,
    queryFn: () => fetchExerciseHistory(user!.id, 200),
  });

  // Mapa: exerciseId → último registro (mais recente)
  const lastByExercise = useMemo(() => {
    const m = new Map<string, ExerciseHistoryRow>();
    for (const row of exHistory) {
      if (!m.has(row.exercise_id)) m.set(row.exercise_id, row);
    }
    return m;
  }, [exHistory]);

  const audioCtxRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    // Aguarda profile carregar — NUNCA redireciona enquanto Firestore recarrega
    if (!profile) return;
    const today = new Date().toISOString().slice(0, 10);
    const hasWorkoutToday = !!(profile.daily_workout && "id" in profile.daily_workout);
    if (profile.last_workout_date === today && !hasWorkoutToday) {
      setWorkoutCompleted(true);
      return;
    }
    if (workout) return; // já temos treino, não recarregar
    if (profile.daily_workout && "id" in profile.daily_workout) {
      setWorkout(profile.daily_workout as Workout);
      return;
    }
    // Sem treino do dia: tenta gerar a partir do quiz inline, sem voltar para /app
    if (profile.quiz && profile.quiz_completed) {
      try {
        const quiz = profile.quiz as Quiz;
        const todayIdx = new Date().getDay();
        const planDay = profile.weekly_plan?.days?.[todayIdx % (profile.weekly_plan?.days?.length || 1)];
        const fresh = generateIntelligentWorkout({ quiz }, [], planDay?.focus);
        setWorkout(fresh);
        updateProfile.mutate({ daily_workout: fresh });
      } catch {
        // Em caso de falha, permanece na tela exibindo loading em vez de redirecionar
      }
    }
    // Sem quiz: também não redireciona automaticamente — deixa o usuário ver o estado
  }, [profile, workout, updateProfile]);

  // Quando vindo de "Finalizar treino" no overview, abre o modal de finalização automaticamente.
  useEffect(() => {
    if (!workout) return;
    if (autoFinishTriggered.current) return;
    if (searchParams?.finish) {
      autoFinishTriggered.current = true;
      setShowFinishModal(true);
    }
  }, [workout, searchParams]);

  const flat: FlatExercise[] = useMemo(() => {
    if (!workout) return [];
    let g = 0;
    const map = (
      arr: Exercise[],
      section: FlatExercise["section"],
      label: string,
    ): FlatExercise[] =>
      arr.map((ex) => ({ ...ex, section, sectionLabel: label, globalIdx: g++ }));
    return [
      ...map(workout.warmup, "warmup", "Aquecimento"),
      ...map(workout.main, "main", "Principal"),
      ...map(workout.finisher, "finisher", "Finalizador"),
    ];
  }, [workout]);

  // Hidrata os ✔ a partir do banco: marca como concluído todo exercício do
  // treino atual que já tenha um registro em exercise_history hoje.
  useEffect(() => {
    if (!exHistory.length || !flat.length) return;
    const startOfToday = new Date();
    startOfToday.setHours(0, 0, 0, 0);
    const startMs = startOfToday.getTime();
    const doneToday = new Set<string>();
    for (const row of exHistory) {
      const t = row.recorded_at ? new Date(row.recorded_at).getTime() : 0;
      if (t >= startMs) doneToday.add(row.exercise_id);
    }
    if (!doneToday.size) return;
    setCompletedEx((prev) => {
      const next = { ...prev };
      let changed = false;
      flat.forEach((ex, idx) => {
        const key = ex.id + idx;
        if (!next[key] && doneToday.has(ex.id)) {
          next[key] = true;
          changed = true;
        }
      });
      return changed ? next : prev;
    });
  }, [exHistory, flat]);

  const current = flat[currentIdx];
  const total = flat.length;
  const totalSets = useMemo(() => flat.reduce((s, e) => s + e.sets, 0), [flat]);
  const completedExerciseCount = useMemo(
    () => flat.filter((ex) => completedEx[ex.id + ex.globalIdx]).length,
    [completedEx, flat],
  );
  const completedSetsFromChecks = useMemo(
    () => flat.reduce((sum, ex) => sum + (completedEx[ex.id + ex.globalIdx] ? ex.sets : 0), 0),
    [completedEx, flat],
  );
  const completedSetsAll = useMemo(() => {
    let acc = 0;
    flat.forEach((e, i) => {
      if (i < currentIdx) acc += e.sets;
      else if (i === currentIdx) acc += setsDone;
    });
    return Math.max(acc, completedSetsFromChecks);
  }, [flat, currentIdx, setsDone, completedSetsFromChecks]);
  const progressPct = totalSets ? Math.round((completedSetsAll / totalSets) * 100) : 0;

  // Rest timer
  useEffect(() => {
    if (!restRunning) return;
    if (restSecs <= 0) {
      setRestRunning(false);
      playBeep();
      return;
    }
    const t = setTimeout(() => setRestSecs((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [restRunning, restSecs]);

  // Wave 3: timer por exercício e por série (avança 1s sempre que NÃO está em descanso)
  useEffect(() => {
    if (restRunning) return;
    const t = setInterval(() => {
      setExerciseElapsed(Math.floor((Date.now() - exerciseStartedAt) / 1000));
      setSetElapsed(Math.floor((Date.now() - setStartedAt) / 1000));
    }, 1000);
    return () => clearInterval(t);
  }, [restRunning, exerciseStartedAt, setStartedAt]);

  function playBeep() {
    try {
      if (!audioCtxRef.current) {
        const Ctx =
          (window.AudioContext as typeof AudioContext) ||
          ((window as unknown as { webkitAudioContext: typeof AudioContext })
            .webkitAudioContext as typeof AudioContext);
        audioCtxRef.current = new Ctx();
      }
      const ctx = audioCtxRef.current!;
      const beep = (freq: number, when: number, dur = 0.18) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.frequency.value = freq;
        osc.type = "sine";
        gain.gain.setValueAtTime(0, ctx.currentTime + when);
        gain.gain.linearRampToValueAtTime(0.25, ctx.currentTime + when + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + when + dur);
        osc.connect(gain).connect(ctx.destination);
        osc.start(ctx.currentTime + when);
        osc.stop(ctx.currentTime + when + dur + 0.02);
      };
      beep(880, 0);
      beep(1175, 0.22, 0.28);
      if (navigator.vibrate) navigator.vibrate([120, 60, 180]);
    } catch {
      /* no audio */
    }
  }

  const completeSet = () => {
    if (!current) return;
    // Wave 3: avalia adaptive signal (lento/rápido)
    const expected = expectedSecondsPerSet(current);
    const sig = adaptiveSignal(setElapsed, expected);
    const msg = adaptiveMessage(sig);
    if (msg) {
      setAdaptiveHint(msg);
      setTimeout(() => setAdaptiveHint(null), 4500);
    }
    if (navigator.vibrate) navigator.vibrate(120);

    const next = setsDone + 1;
    if (next >= current.sets) {
      setSetsDone(current.sets);
      setRestRunning(false);
      setRestSecs(0);
    } else {
      setSetsDone(next);
      setSetStartedAt(Date.now());
      setSetElapsed(0);
      if (current.rest > 0) {
        setRestSecs(current.rest);
        setRestRunning(true);
      }
    }
  };

  const skipRest = () => {
    setRestRunning(false);
    setRestSecs(0);
    setSetStartedAt(Date.now());
    setSetElapsed(0);
  };

  const resetExerciseTimers = () => {
    setExerciseStartedAt(Date.now());
    setSetStartedAt(Date.now());
    setExerciseElapsed(0);
    setSetElapsed(0);
  };

  const goNext = () => {
    if (!current) return;
    if (currentIdx < total - 1) {
      setCurrentIdx((i) => i + 1);
      setSetsDone(0);
      setRestSecs(0);
      setRestRunning(false);
      resetExerciseTimers();
    } else {
      setShowFinishModal(true);
    }
  };

  const goPrev = () => {
    if (currentIdx === 0) return;
    setCurrentIdx((i) => i - 1);
    setSetsDone(0);
    setRestSecs(0);
    setRestRunning(false);
    resetExerciseTimers();
  };

  const setFeedback = (fb: ExerciseFeedback) => {
    if (!current) return;
    setFeedbacks((prev) => ({ ...prev, [current.id + currentIdx]: fb }));
  };

  // Wave 3: trocar exercício atual por outro do mesmo grupo muscular
  const swapCurrentExercise = () => {
    if (!current || !workout) return;
    if (current.section !== "main") {
      toast.info("Só dá pra trocar exercícios principais.");
      return;
    }
    const muscle = current.muscle as keyof typeof EXERCISE_LIBRARY;
    const pool = EXERCISE_LIBRARY[muscle] ?? [];
    const usedIds = new Set(workout.main.map((e) => e.id));
    const candidates = pool.filter((e) => !usedIds.has(e.id));
    const pick = candidates.length
      ? candidates[Math.floor(Math.random() * candidates.length)]
      : pool.find((e) => e.id !== current.id);
    if (!pick) {
      toast.info("Sem alternativas pra esse grupo.");
      return;
    }
    // Substitui no array main
    const mainIdx = workout.main.findIndex((e) => e.id === current.id);
    if (mainIdx < 0) return;
    const replaced: Exercise = {
      ...pick,
      sets: current.sets,
      reps: current.reps,
      rest: current.rest,
      type: "main",
      setsCompleted: 0,
      done: false,
    };
    const newMain = [...workout.main];
    newMain[mainIdx] = replaced;
    const newWorkout = { ...workout, main: newMain };
    setWorkout(newWorkout);
    setSetsDone(0);
    resetExerciseTimers();
    // Persiste de forma otimista (não bloqueia UI)
    updateProfile.mutate({ daily_workout: newWorkout });
    toast.success(`Trocado para ${pick.name}`);
  };

  const toggleFavorite = () => {
    if (!current || !profile) return;
    const favs = profile.favorites ?? [];
    const isFav = favs.includes(current.id);
    const newFavs = isFav ? favs.filter((id) => id !== current.id) : [...favs, current.id];
    updateProfile.mutate({ favorites: newFavs });
    if (navigator.vibrate) navigator.vibrate(60);
    toast.success(isFav ? "Removido dos favoritos" : "Adicionado aos favoritos ⭐");
  };

  // Marca exercício como concluído e persiste imediatamente no banco
  const markExerciseDone = async (ex: FlatExercise, idx: number) => {
    if (!user) {
      toast.error("Entre na conta para salvar o exercício.");
      return;
    }
    const key = ex.id + idx;
    if (completedEx[key] || savingEx[key]) return; // evita duplo clique
    setSavingEx((s) => ({ ...s, [key]: true }));
    // Marca otimisticamente
    setCompletedEx((c) => ({ ...c, [key]: true }));
    if (navigator.vibrate) navigator.vibrate(80);
    try {
      const weight = weights[key] ?? 0;
      const fb = feedbacks[key];
      const { error } = await supabase.from("exercise_history").insert({
        user_id: user.id,
        exercise_id: ex.id,
        exercise_name: ex.name,
        weight_kg: weight,
        reps: String(ex.reps),
        sets: ex.sets,
        feedback: fb ?? null,
      });
      if (error) throw error;
      toast.success(`✔ ${ex.name} concluído`);
      // Mantém cache em sincronia com o banco
      queryClient.invalidateQueries({ queryKey: ["exercise-history-focus", user.id] });
    } catch (err) {
      // Reverte em caso de erro
      setCompletedEx((c) => {
        const next = { ...c };
        delete next[key];
        return next;
      });
      toast.error(err instanceof Error ? err.message : "Falha ao salvar");
    } finally {
      setSavingEx((s) => {
        const next = { ...s };
        delete next[key];
        return next;
      });
    }
  };

  const finishWorkout = async () => {
    if (!workout || !user || finishing || workoutCompleted) return;
    setFinishing(true);
    try {
      const timeSpent = Math.round((Date.now() - startedAt) / 1000);
      const completionRate = totalSets ? completedSetsAll / totalSets : 0;

      // Streak
      const today = new Date().toISOString().slice(0, 10);
      const last = profile?.last_workout_date;
      let newStreak = profile?.streak ?? 0;
      if (last !== today) {
        const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
        newStreak = last === yesterday ? newStreak + 1 : 1;
      }

      // XP
      const xpGained = Math.round(50 + completionRate * 100 + (overallRating > 0 ? 10 : 0));
      const xp = (profile?.progression?.xp ?? 0) + xpGained;
      const level = profile?.progression?.level ?? 1;
      const xpToNext = level * 200;
      const newLevel = xp >= xpToNext ? level + 1 : level;
      const newXp = xp >= xpToNext ? xp - xpToNext : xp;

      // Adaptive load factor: weighted by exercise feedbacks
      const fbValues = Object.values(feedbacks);
      const oldLoad = profile?.progression?.loadFactor ?? 1.0;
      let loadDelta = 0;
      if (fbValues.length > 0) {
        const leves = fbValues.filter((f) => f === "leve").length;
        const pesados = fbValues.filter((f) => f === "pesado").length;
        const falhas = fbValues.filter((f) => f === "falha").length;
        const ratio = (leves - pesados - falhas * 2) / fbValues.length;
        loadDelta = Math.round(ratio * 100) / 100 * 0.06; // up to ±6%
        if (falhas > 0) loadDelta -= 0.02; // penalidade extra por falha
      } else {
        loadDelta = completionRate >= 0.9 ? 0.04 : completionRate < 0.6 ? -0.03 : 0;
      }
      // Apply overall rating penalty if very tired
      if (overallRating === 1) loadDelta -= 0.03;
      if (overallRating === 5) loadDelta += 0.02;
      const loadFactor = Math.max(0.7, Math.min(1.6, oldLoad + loadDelta));

      // Challenges
      const ch: Challenges =
        profile?.challenges ?? {
          d7: { progress: 0, completed: false },
          d30: { progress: 0, completed: false },
        };
      const newCh: Challenges = {
        d7: {
          progress: Math.min(7, (ch.d7?.progress ?? 0) + 1),
          completed: (ch.d7?.progress ?? 0) + 1 >= 7,
        },
        d30: {
          progress: Math.min(30, (ch.d30?.progress ?? 0) + 1),
          completed: (ch.d30?.progress ?? 0) + 1 >= 30,
        },
      };

      const rankingScore = (profile?.ranking_score ?? 0) + xpGained + newStreak * 5;

      // Persist exercise feedbacks with names
      const exerciseFeedbackArr = flat
        .filter((ex) => feedbacks[ex.id + ex.globalIdx])
        .map((ex) => ({
          name: ex.name,
          section: ex.section,
          feedback: feedbacks[ex.id + ex.globalIdx],
        }));

      const patch: Partial<Profile> = {
        streak: newStreak,
        last_workout_date: today,
        daily_workout: {} as never,
        progression: { xp: newXp, level: newLevel, loadFactor },
        challenges: newCh,
        ranking_score: rankingScore,
      };

      const [, hist, perf] = await Promise.all([
        updateProfile.mutateAsync(patch),
        supabase.from("workout_history").insert({
          user_id: user.id,
          workout: workout as unknown as never,
        }),
        supabase.from("performance_history").insert({
          user_id: user.id,
          difficulty: overallRating || Math.max(1, Math.min(5, Math.round(completionRate * 5))),
          completion_rate: completionRate,
          time_spent: timeSpent,
          sets_completed_total: completedSetsAll,
          exercise_feedback: exerciseFeedbackArr as never,
          overall_rating: overallRating || null,
          overall_notes: overallNotes || null,
        }),
      ]);

      if (hist.error) throw hist.error;
      if (perf.error) throw perf.error;

      // Persist real load history per exercise (kg used)
      const exHistoryEntries: ExerciseHistoryEntry[] = flat
        .filter((ex) => !completedEx[ex.id + ex.globalIdx])
        .map((ex) => ({
          exerciseId: ex.id,
          exerciseName: ex.name,
          weightKg: weights[ex.id + ex.globalIdx] ?? 0,
          reps: String(ex.reps),
          sets: ex.section === "main" ? Math.min(setsDone + (currentIdx > ex.globalIdx ? ex.sets : 0), ex.sets) : ex.sets,
          feedback: feedbacks[ex.id + ex.globalIdx],
        }))
        .filter((e) => e.weightKg > 0);
      try {
        await saveExerciseHistory(user.id, exHistoryEntries);
      } catch (err) {
        console.warn("Falha ao salvar histórico de carga", err);
      }

      const leveledUp = newLevel > level;
      setSummary({
        completionRate,
        timeSpent,
        setsCompleted: completedSetsAll,
        totalSets,
        xpGained,
        newStreak,
        newLevel,
        leveledUp,
      });
      setWorkoutCompleted(true);
      setShowFinishModal(false);
      if (leveledUp) {
        toast.success(`🎉 Subiu pro nível ${newLevel}!`, { duration: 4000 });
        if (navigator.vibrate) navigator.vibrate([200, 80, 200, 80, 300]);
      } else {
        if (navigator.vibrate) navigator.vibrate([150, 60, 250]);
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Erro ao finalizar");
    } finally {
      setFinishing(false);
    }
  };

  if (workoutCompleted && !summary) {
    return (
      <div className="fixed inset-0 z-50 bg-background flex flex-col items-center justify-center gap-5 p-6 text-center">
        <div className="h-16 w-16 rounded-full bg-gradient-primary text-primary-foreground flex items-center justify-center shadow-glow">
          <Trophy className="h-8 w-8" />
        </div>
        <div>
          <div className="text-[11px] uppercase tracking-widest text-primary font-black mb-2">
            Treino concluído
          </div>
          <h1 className="text-3xl font-black">Treino concluído</h1>
          <p className="text-sm text-muted-foreground mt-2 max-w-sm">
            O treino de hoje já foi finalizado e registrado no seu histórico.
          </p>
        </div>
        <div className="flex gap-2 w-full max-w-sm">
          <Button asChild variant="outline" className="flex-1">
            <Link to="/app/evolucao">Ver evolução</Link>
          </Button>
          <Button asChild className="flex-1 bg-gradient-primary text-primary-foreground hover:opacity-90">
            <Link to="/app">Painel</Link>
          </Button>
        </div>
      </div>
    );
  }

  if (!workout || !current) {
    return (
      <div className="fixed inset-0 z-50 bg-background flex flex-col items-center justify-center gap-4 p-6">
        <div className="h-10 w-10 rounded-full border-4 border-primary border-t-transparent animate-spin" />
        <p className="text-sm text-muted-foreground font-medium">Carregando seu treino…</p>
        <Button asChild variant="ghost" size="sm">
          <Link to="/app/treino">
            <ArrowLeft className="h-4 w-4 mr-1" /> Voltar
          </Link>
        </Button>
      </div>
    );
  }

  const restPct = current.rest > 0 ? Math.round(((current.rest - restSecs) / current.rest) * 100) : 0;
  const currentFb = feedbacks[current.id + currentIdx];
  const exerciseDone = setsDone >= current.sets;
  const isLast = currentIdx === total - 1;

  return (
    <div className="fixed inset-0 z-50 bg-background overflow-y-auto">
      {/* Top bar */}
      <div className="sticky top-0 z-10 backdrop-blur-md bg-background/80 border-b border-border/50">
        <div className="max-w-2xl mx-auto px-4 h-14 flex items-center justify-between gap-3">
          <Link to="/app/treino">
            <Button variant="ghost" size="sm" className="-ml-2">
              <ArrowLeft className="h-4 w-4 mr-1" /> Sair
            </Button>
          </Link>
          <div className="text-xs text-muted-foreground hidden sm:block">
            {currentIdx + 1} / {total} · {current.sectionLabel}
          </div>
          <div className="flex items-center gap-2">
            <div className="text-xs font-bold text-primary">{progressPct}%</div>
            <Button
              size="sm"
              disabled={workoutCompleted}
              onClick={() => setShowFinishModal(true)}
              className="h-8 bg-gradient-primary text-primary-foreground hover:opacity-90 text-xs font-bold"
            >
              <Check className="h-3.5 w-3.5 mr-1" /> {workoutCompleted ? "Concluído" : "Finalizar"}
            </Button>
          </div>
        </div>
        <div className="h-1 bg-muted">
          <div
            className="h-full bg-gradient-primary transition-all duration-500"
            style={{ width: `${progressPct}%` }}
          />
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-5 pt-8 pb-32 animate-slide-up">
        {/* Section label */}
        <div className="text-xs uppercase tracking-widest text-primary font-bold mb-2">
          {current.sectionLabel}
        </div>

        {/* Exercise name + favorite */}
        <div className="flex items-start justify-between gap-3 mb-1">
          <h1 className="text-3xl md:text-4xl font-extrabold leading-tight">{current.name}</h1>
          <button
            type="button"
            onClick={toggleFavorite}
            className="shrink-0 h-10 w-10 rounded-full border border-border/60 bg-surface-elevated flex items-center justify-center hover:border-primary/60 transition"
            aria-label="Favoritar exercício"
          >
            <Star
              className={`h-5 w-5 transition ${
                profile?.favorites?.includes(current.id)
                  ? "fill-primary text-primary"
                  : "text-muted-foreground"
              }`}
            />
          </button>
        </div>

        {/* Imagem do exercício atual */}
        <div className="mb-4">
          <ExerciseImage exercise={current} aspect="wide" eager />
        </div>

        {/* Meta */}
        <div className="flex items-center gap-3 text-sm text-muted-foreground mb-5">
          <span>
            <span className="text-foreground font-bold">{current.sets}</span> séries
          </span>
          <span>×</span>
          <span>
            <span className="text-foreground font-bold">{current.reps}</span>
            {current.section === "warmup" || current.section === "finisher" ? "s" : " reps"}
          </span>
          {current.rest > 0 && (
            <>
              <span>·</span>
              <span>descanso {current.rest}s</span>
            </>
          )}
        </div>

        {/* Wave 3: Painel de carga (kg) + carga relativa + timers */}
        {current.section === "main" && (() => {
          const kg = estimateExerciseKg(current.name, profile, perfHistory);
          const baseLoad = profile?.progression?.loadFactor ?? 1.0;
          const sug = suggestedLoadForExercise(current.name, baseLoad, perfHistory);
          const arrow = kg.trend === "up" ? "↑" : kg.trend === "down" ? "↓" : "→";
          return (
            <div className="grid grid-cols-2 gap-2 mb-5">
              <div className="rounded-xl bg-gradient-surface border border-primary/30 p-3">
                <div className="text-[10px] uppercase tracking-widest text-muted-foreground font-bold">
                  Carga estimada
                </div>
                <div className="flex items-baseline gap-1 mt-1">
                  {kg.isBodyweight ? (
                    <span className="text-2xl font-black text-primary">peso corporal</span>
                  ) : (
                    <>
                      <span className="text-3xl font-black text-primary">{kg.kg}</span>
                      <span className="text-xs text-muted-foreground font-bold">kg {arrow}</span>
                    </>
                  )}
                </div>
                <div className="text-[10px] text-muted-foreground mt-0.5">
                  {sug.samples > 0 ? `Ajustado por ${sug.samples} feedbacks` : "Estimativa inicial"}
                </div>
              </div>
              <div className="rounded-xl bg-surface-elevated border border-border/60 p-3">
                <div className="text-[10px] uppercase tracking-widest text-muted-foreground font-bold flex items-center gap-1">
                  <Timer className="h-3 w-3" /> Tempos
                </div>
                <div className="text-sm font-bold mt-1 tabular-nums">
                  Série: {String(Math.floor(setElapsed / 60)).padStart(2, "0")}:
                  {String(setElapsed % 60).padStart(2, "0")}
                </div>
                <div className="text-[11px] text-muted-foreground tabular-nums">
                  Total: {String(Math.floor(exerciseElapsed / 60)).padStart(2, "0")}:
                  {String(exerciseElapsed % 60).padStart(2, "0")}
                </div>
              </div>
            </div>
          );
        })()}

        {/* Histórico real de carga (kg) — input + sugestão */}
        {current.section === "main" && (() => {
          const last = lastByExercise.get(current.id) ?? null;
          const sug = suggestNextWeight(last);
          const key = current.id + currentIdx;
          const currentWeight = weights[key];
          // Auto-preencher uma vez com sugestão (ou última carga)
          const placeholder =
            sug.weight > 0 ? sug.weight : last?.weight_kg ? last.weight_kg : 0;

          return (
            <div className="rounded-2xl bg-surface-elevated border border-primary/30 p-4 mb-5">
              <div className="flex items-center justify-between mb-2">
                <div className="text-[10px] uppercase tracking-widest text-primary font-bold">
                  Carga real (kg)
                </div>
                {last && (
                  <div className="text-[10px] text-muted-foreground">
                    Última: <span className="font-bold text-foreground">{last.weight_kg}kg</span>
                  </div>
                )}
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  inputMode="decimal"
                  min={0}
                  max={500}
                  step={0.5}
                  value={currentWeight ?? ""}
                  onChange={(e) => {
                    const raw = e.target.value;
                    if (raw === "") {
                      setWeights((w) => {
                        const next = { ...w };
                        delete next[key];
                        return next;
                      });
                      return;
                    }
                    const n = Number(raw);
                    if (!Number.isFinite(n) || n < 0 || n > 500) return;
                    setWeights((w) => ({ ...w, [key]: n }));
                  }}
                  placeholder={placeholder > 0 ? String(placeholder) : "0"}
                  className="flex-1 h-12 rounded-xl bg-background border border-border px-4 text-2xl font-black tabular-nums text-center focus:outline-none focus:border-primary"
                />
                <span className="text-sm text-muted-foreground font-bold">kg</span>
                {placeholder > 0 && currentWeight === undefined && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setWeights((w) => ({ ...w, [key]: placeholder }))}
                    className="h-12 px-3 text-xs"
                  >
                    Usar {placeholder}kg
                  </Button>
                )}
              </div>
              {sug.weight > 0 && (
                <div className="flex items-center gap-1 mt-2 text-[11px]">
                  <span className="text-muted-foreground">Sugestão:</span>
                  <span className="font-bold text-primary">{sug.weight}kg</span>
                  {sug.delta !== 0 && (
                    <span
                      className={`font-bold ${
                        sug.delta > 0 ? "text-primary" : "text-warning"
                      }`}
                    >
                      ({sug.delta > 0 ? "+" : ""}
                      {sug.delta}kg)
                    </span>
                  )}
                  <span className="text-muted-foreground">· {sug.reason}</span>
                </div>
              )}
              {!last && (
                <p className="text-[11px] text-muted-foreground mt-2">
                  Primeira vez nesse exercício — anota o peso pra começar a evoluir.
                </p>
              )}
            </div>
          );
        })()}

        {/* Adaptive hint banner */}
        {adaptiveHint && (
          <div className="mb-4 rounded-xl border border-warning/40 bg-warning/10 px-3 py-2 text-xs text-warning font-semibold animate-slide-up">
            ⚡ {adaptiveHint}
          </div>
        )}

        <div className="flex flex-wrap gap-2 mb-6">
          {current.videoId && (
            <button
              type="button"
              onClick={() => setVideo({ id: current.videoId ?? null, title: current.name })}
              className="inline-flex items-center gap-2 px-3 py-2 rounded-full bg-surface-elevated border border-border/60 hover:border-primary/50 text-xs font-medium transition"
            >
              <PlayCircle className="h-4 w-4 text-primary" /> Ver como fazer
            </button>
          )}
          {current.section === "main" && (
            <button
              type="button"
              onClick={swapCurrentExercise}
              className="inline-flex items-center gap-2 px-3 py-2 rounded-full bg-surface-elevated border border-border/60 hover:border-primary/50 text-xs font-medium transition"
            >
              <RefreshCcw className="h-4 w-4 text-primary" /> Trocar exercício
            </button>
          )}
        </div>

        {/* Sets ring */}
        <div className="rounded-3xl bg-gradient-surface border border-border/60 shadow-elevated p-8 mb-6">
          <div className="text-center text-xs uppercase tracking-widest text-muted-foreground mb-3">
            Série atual
          </div>
          <div className="text-center mb-5">
            <span className="text-6xl font-black text-primary">{Math.min(setsDone + 1, current.sets)}</span>
            <span className="text-2xl text-muted-foreground"> / {current.sets}</span>
          </div>

          {/* Set chips */}
          <div className="flex justify-center flex-wrap gap-2 mb-6">
            {Array.from({ length: current.sets }).map((_, i) => (
              <div
                key={i}
                className={`h-10 w-10 rounded-xl flex items-center justify-center text-sm font-bold transition ${
                  i < setsDone
                    ? "bg-gradient-primary text-primary-foreground shadow-glow"
                    : i === setsDone
                      ? "bg-surface-elevated border-2 border-primary text-primary animate-pulse-glow"
                      : "bg-muted text-muted-foreground"
                }`}
              >
                {i + 1}
              </div>
            ))}
          </div>

          {/* Rest timer */}
          {restRunning && current.rest > 0 ? (
            <div className="rounded-2xl bg-background/60 border border-primary/40 p-5 text-center">
              <div className="text-xs uppercase tracking-widest text-primary font-bold mb-1">
                Descanso
              </div>
              <div className="text-5xl font-black tabular-nums my-2">
                {String(Math.floor(restSecs / 60)).padStart(2, "0")}:
                {String(restSecs % 60).padStart(2, "0")}
              </div>
              <div className="h-1.5 bg-muted rounded-full overflow-hidden mb-4">
                <div
                  className="h-full bg-gradient-primary transition-all duration-1000 linear"
                  style={{ width: `${restPct}%` }}
                />
              </div>
              <div className="flex gap-2 justify-center">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setRestRunning(false)}
                  className="gap-1"
                >
                  <Pause className="h-3.5 w-3.5" /> Pausar
                </Button>
                <Button size="sm" variant="outline" onClick={skipRest} className="gap-1">
                  Pular <ChevronRight className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          ) : restSecs > 0 && current.rest > 0 ? (
            <div className="rounded-2xl bg-background/60 border border-border p-5 text-center">
              <div className="text-4xl font-black tabular-nums mb-3">
                {String(Math.floor(restSecs / 60)).padStart(2, "0")}:
                {String(restSecs % 60).padStart(2, "0")}
              </div>
              <Button size="sm" onClick={() => setRestRunning(true)} className="gap-1">
                <Play className="h-3.5 w-3.5" /> Retomar
              </Button>
            </div>
          ) : (
            <Button
              onClick={completeSet}
              disabled={exerciseDone}
              className="w-full h-14 text-base bg-gradient-primary text-primary-foreground hover:opacity-90 shadow-glow"
            >
              {exerciseDone ? (
                <>
                  <Check className="h-5 w-5 mr-2" /> Exercício completo
                </>
              ) : (
                <>
                  <Zap className="h-5 w-5 mr-2" /> Concluir série {setsDone + 1}
                </>
              )}
            </Button>
          )}
        </div>

        {/* Feedback */}
        <div className="rounded-2xl bg-surface border border-border/60 p-5 mb-6">
          <div className="text-xs uppercase tracking-widest text-muted-foreground font-bold mb-3 text-center">
            Como foi esse exercício?
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {(["leve", "medio", "pesado", "falha"] as const).map((fb) => {
              const active = currentFb === fb;
              const labels = {
                leve: "😎 Leve",
                medio: "💪 Médio",
                pesado: "🥵 Pesado",
                falha: "❌ Falhei",
              };
              return (
                <button
                  key={fb}
                  type="button"
                  onClick={() => setFeedback(fb)}
                  className={`py-3 rounded-xl text-sm font-bold transition ${
                    active
                      ? fb === "falha"
                        ? "bg-destructive text-destructive-foreground shadow-glow"
                        : "bg-gradient-primary text-primary-foreground shadow-glow"
                      : "bg-muted text-muted-foreground hover:bg-accent hover:text-foreground"
                  }`}
                >
                  {labels[fb]}
                </button>
              );
            })}
          </div>
          {currentFb === "falha" && (
            <p className="text-xs text-muted-foreground mt-3 text-center">
              Registramos a falha — vamos reduzir a carga sugerida no próximo treino.
            </p>
          )}
        </div>

        {/* ✔ Concluir exercício — salva imediatamente no banco */}
        {(() => {
          const key = current.id + currentIdx;
          const done = !!completedEx[key];
          const saving = !!savingEx[key];
          return (
            <button
              type="button"
              onClick={() => {
                if (workoutCompleted) return;
                if (saving) return;
                if (!done) {
                  markExerciseDone(current, currentIdx);
                }
                // sempre auto-avança (mesmo se já estava concluído)
                if (currentIdx < total - 1) {
                  setTimeout(() => goNext(), 250);
                } else {
                  setTimeout(() => setShowFinishModal(true), 250);
                }
              }}
              disabled={saving || workoutCompleted}
              className={`w-full mb-3 h-14 rounded-2xl font-black text-base flex items-center justify-center gap-2 transition shadow-elevated ${
                done
                  ? "bg-success/20 text-success border-2 border-success"
                  : saving
                    ? "bg-muted text-muted-foreground cursor-wait"
                    : "bg-gradient-primary text-primary-foreground hover:opacity-90 active:scale-[0.98]"
              }`}
              aria-label="Marcar exercício como concluído"
            >
              {done ? (
                <><Check className="h-6 w-6" /> Concluído — próximo</>
              ) : saving ? (
                <>Salvando…</>
              ) : (
                <><Check className="h-6 w-6" /> ✔ Marcar como concluído</>
              )}
            </button>
          );
        })()}

        {/* Nav */}
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={goPrev}
            disabled={currentIdx === 0}
            className="flex-1"
          >
            <ArrowLeft className="h-4 w-4 mr-1" /> Anterior
          </Button>
          <Button
            onClick={() => {
              setSetsDone(0);
              setRestSecs(0);
              setRestRunning(false);
            }}
            variant="outline"
            size="icon"
            title="Reiniciar exercício"
          >
            <RotateCcw className="h-4 w-4" />
          </Button>
          <Button
            onClick={goNext}
            disabled={workoutCompleted}
            className="flex-1 bg-gradient-primary text-primary-foreground hover:opacity-90"
          >
            {isLast ? "Finalizar" : "Próximo"} <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>
      </div>

      {/* Barra fixa: Finalizar treino (sempre visível) */}
      <div className="fixed bottom-0 inset-x-0 z-20 backdrop-blur-md bg-background/90 border-t border-border/60">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center gap-3">
          <div className="flex-1 min-w-0">
            <div className="text-[11px] uppercase tracking-widest text-muted-foreground font-bold">
              Concluídos
            </div>
            <div className="text-sm font-black tabular-nums">
              {completedExerciseCount} / {total} exercícios
            </div>
          </div>
          <Button
            disabled={workoutCompleted}
            onClick={() => setShowFinishModal(true)}
            className="h-12 px-5 bg-gradient-primary text-primary-foreground hover:opacity-90 shadow-glow font-black"
          >
            <Check className="h-5 w-5 mr-1" /> {workoutCompleted ? "Treino concluído" : "Finalizar treino"}
          </Button>
        </div>
      </div>

      {/* Finish modal */}
      {showFinishModal && (
        <div className="fixed inset-0 z-[60] bg-background/85 backdrop-blur-md flex items-center justify-center p-5 animate-slide-up">
          <div className="w-full max-w-md rounded-3xl bg-gradient-surface border border-border/60 shadow-elevated p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h2 className="text-xl font-extrabold">Avalia teu treino, boss</h2>
                <p className="text-xs text-muted-foreground mt-1">
                  Isso ajuda o coach a ajustar o próximo.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowFinishModal(false)}
                className="text-muted-foreground hover:text-foreground"
                aria-label="Fechar"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mb-5">
              <div className="text-xs uppercase tracking-widest text-muted-foreground font-bold mb-2">
                Intensidade geral
              </div>
              <div className="flex justify-between gap-1">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button
                    key={n}
                    type="button"
                    onClick={() => setOverallRating(n)}
                    className={`flex-1 h-12 rounded-xl text-lg font-black transition ${
                      overallRating === n
                        ? "bg-gradient-primary text-primary-foreground shadow-glow"
                        : "bg-muted text-muted-foreground hover:bg-accent"
                    }`}
                  >
                    {n}
                  </button>
                ))}
              </div>
              <div className="flex justify-between text-[10px] text-muted-foreground mt-1 px-1">
                <span>Tranquilo</span>
                <span>Brutal</span>
              </div>
            </div>

            <div className="mb-5">
              <div className="text-xs uppercase tracking-widest text-muted-foreground font-bold mb-2">
                Notas (opcional)
              </div>
              <textarea
                value={overallNotes}
                onChange={(e) => setOverallNotes(e.target.value.slice(0, 280))}
                placeholder="Bombei no supino, costas mais fácil que esperava…"
                className="w-full h-20 rounded-xl bg-background border border-border p-3 text-sm resize-none focus:outline-none focus:border-primary"
              />
            </div>

            {(() => {
              const quiz = (profile?.quiz ?? {}) as Partial<Quiz>;
              const tips = getPostWorkoutTips(quiz.objetivo, quiz.injuries);
              return (
                <div className="mb-5 rounded-xl bg-primary/5 border border-primary/20 p-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-xs uppercase tracking-widest text-primary font-bold">
                      Recuperação & alimentação
                    </div>
                    <Link
                      to="/app/bem-estar"
                      className="text-[11px] text-primary font-bold hover:underline"
                    >
                      Ver tudo →
                    </Link>
                  </div>
                  <ul className="space-y-1">
                    {tips.map((t, i) => (
                      <li key={i} className="text-xs text-foreground/90 flex gap-2">
                        <span className="text-primary">•</span>
                        <span>{t}</span>
                      </li>
                    ))}
                  </ul>
                  <p className="text-[10px] text-muted-foreground mt-2 italic">
                    Sugestões gerais — não substitui orientação médica.
                  </p>
                </div>
              );
            })()}

            <Button
              onClick={finishWorkout}
              disabled={finishing}
              className="w-full h-12 bg-gradient-primary text-primary-foreground hover:opacity-90 shadow-glow"
            >
              {finishing ? "Salvando..." : "Concluir treino"}
            </Button>
          </div>
        </div>
      )}

      {/* Summary screen */}
      {summary && (
        <div className="fixed inset-0 z-[70] bg-background/95 backdrop-blur-md overflow-y-auto animate-slide-up">
          <div className="min-h-full flex items-center justify-center p-5">
            <div className="w-full max-w-md rounded-3xl bg-gradient-surface border border-primary/30 shadow-elevated p-6">
              <div className="text-center mb-6">
                <div className="mx-auto h-16 w-16 rounded-full bg-gradient-primary flex items-center justify-center shadow-glow mb-3">
                  <Trophy className="h-8 w-8 text-primary-foreground" />
                </div>
                <div className="text-[11px] uppercase tracking-widest text-primary font-bold">
                  Treino concluído
                </div>
                <h2 className="text-2xl font-extrabold mt-1">Mandou bem, boss! 🔥</h2>
                {summary.leveledUp && (
                  <div className="mt-2 inline-block rounded-full bg-primary/15 border border-primary/40 px-3 py-1 text-xs font-bold text-primary">
                    🎉 Subiu pro nível {summary.newLevel}
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3 mb-5">
                <div className="rounded-2xl bg-background/60 border border-border/60 p-4 text-center">
                  <Target className="h-4 w-4 text-primary mx-auto mb-1" />
                  <div className="text-2xl font-black tabular-nums">
                    {Math.round(summary.completionRate * 100)}%
                  </div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">
                    Conclusão
                  </div>
                </div>
                <div className="rounded-2xl bg-background/60 border border-border/60 p-4 text-center">
                  <Clock className="h-4 w-4 text-primary mx-auto mb-1" />
                  <div className="text-2xl font-black tabular-nums">
                    {Math.floor(summary.timeSpent / 60)}:
                    {String(summary.timeSpent % 60).padStart(2, "0")}
                  </div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">
                    Tempo total
                  </div>
                </div>
                <div className="rounded-2xl bg-background/60 border border-border/60 p-4 text-center">
                  <Check className="h-4 w-4 text-primary mx-auto mb-1" />
                  <div className="text-2xl font-black tabular-nums">
                    {summary.setsCompleted}
                    <span className="text-sm text-muted-foreground">
                      /{summary.totalSets}
                    </span>
                  </div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">
                    Séries
                  </div>
                </div>
                <div className="rounded-2xl bg-background/60 border border-border/60 p-4 text-center">
                  <TrendingUp className="h-4 w-4 text-primary mx-auto mb-1" />
                  <div className="text-2xl font-black tabular-nums text-primary">
                    +{summary.xpGained}
                  </div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">
                    XP ganhos
                  </div>
                </div>
              </div>

              <div className="rounded-2xl bg-primary/10 border border-primary/30 p-4 mb-5 flex items-center justify-center gap-2">
                <Flame className="h-5 w-5 text-primary" />
                <span className="text-sm font-bold">
                  Streak atual: <span className="text-primary">{summary.newStreak} dias</span>
                </span>
              </div>

              <p className="text-[11px] text-center text-muted-foreground mb-4">
                Registrado no teu histórico ✓
              </p>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => navigate({ to: "/app/evolucao" })}
                  className="flex-1"
                >
                  Ver evolução
                </Button>
                <Button
                  onClick={() => navigate({ to: "/app" })}
                  className="flex-1 bg-gradient-primary text-primary-foreground hover:opacity-90 shadow-glow font-bold"
                >
                  Voltar ao painel
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      <VideoModal
        open={!!video}
        onOpenChange={(v) => !v && setVideo(null)}
        videoId={video?.id ?? null}
        title={video?.title ?? ""}
      />
    </div>
  );
}
