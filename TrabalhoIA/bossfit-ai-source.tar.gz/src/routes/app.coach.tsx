import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import ReactMarkdown from "react-markdown";
import { Brain, Send, Loader2, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useProfile } from "@/lib/use-profile";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/app/coach")({
  component: CoachPage,
});

interface Msg {
  role: "user" | "assistant";
  content: string;
}

const CHAT_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/coach-chat`;
const MEMORY_KEY = "bossfit_coach_memory_v1";
const MAX_MEMORY = 24; // user+assistant pairs trimmed

function loadMemory(): Msg[] {
  try {
    const raw = localStorage.getItem(MEMORY_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) return parsed.slice(-MAX_MEMORY);
  } catch {
    /* ignore */
  }
  return [];
}

function saveMemory(msgs: Msg[]) {
  try {
    localStorage.setItem(MEMORY_KEY, JSON.stringify(msgs.slice(-MAX_MEMORY)));
  } catch {
    /* ignore */
  }
}

const GREETING: Msg = {
  role: "assistant",
  content:
    "E aí, boss! 💪 Sou seu coach pessoal. Pergunta o que quiser sobre treino, nutrição, recuperação ou motivação — uso teu perfil real, lesões e histórico pra responder.",
};

function CoachPage() {
  const { data: profile } = useProfile();
  const { user } = useAuth();
  const [messages, setMessages] = useState<Msg[]>(() => {
    const mem = loadMemory();
    return mem.length > 0 ? mem : [GREETING];
  });
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Persist memory whenever messages change (after a stream finishes)
  useEffect(() => {
    if (!streaming) saveMemory(messages);
  }, [messages, streaming]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  // Dynamic suggestions based on profile state
  const suggestions = useMemo(() => {
    const base: string[] = [];
    const injuries = profile?.quiz?.injuries ?? [];
    const obj = profile?.quiz?.objetivo;
    const streak = profile?.streak ?? 0;
    const hasWorkout = !!(profile?.daily_workout && (profile.daily_workout as { id?: string }).id);

    if (injuries.length > 0) base.push(`Como adaptar treino com ${injuries[0]}?`);
    if (obj === "hipertrofia") base.push("Quanta proteína por dia pra mim?");
    if (obj === "emagrecimento") base.push("Cardio antes ou depois do treino?");
    if (obj === "forca") base.push("Como progredir carga sem travar?");
    if (streak >= 3) base.push("Como estou progredindo?");
    if (streak === 0) base.push("Tô desmotivado, me ajuda");
    if (hasWorkout) base.push("Como executar bem o treino de hoje?");
    base.push("Quanto descanso entre séries?");
    base.push("Sinto dor leve no joelho — o que faço?");

    // dedupe and cap at 5
    return Array.from(new Set(base)).slice(0, 5);
  }, [profile]);

  const send = async (text: string) => {
    if (!profile || !user || !text.trim() || streaming) return;
    const userMsg: Msg = { role: "user", content: text };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setStreaming(true);

    // Fetch recent performance for context
    let recent: Array<{ completionRate?: number; difficulty?: number; recordedAt?: string }> = [];
    try {
      const { data } = await supabase
        .from("performance_history")
        .select("completion_rate, difficulty, recorded_at")
        .eq("user_id", user.id)
        .order("recorded_at", { ascending: false })
        .limit(5);
      recent =
        data?.map((r) => ({
          completionRate: r.completion_rate ?? undefined,
          difficulty: r.difficulty ?? undefined,
          recordedAt: r.recorded_at ?? undefined,
        })) ?? [];
    } catch {
      /* ignore */
    }

    const dw = profile.daily_workout as {
      id?: string;
      title?: string;
      focus?: string;
      estimatedMinutes?: number;
    };
    const profileCtx = {
      username: profile.username,
      quiz: profile.quiz,
      streak: profile.streak,
      progression: profile.progression,
      dailyWorkout: dw?.id
        ? { title: dw.title, focus: dw.focus, estimatedMinutes: dw.estimatedMinutes }
        : null,
      lastWorkoutDate: profile.last_workout_date,
    };

    let assistantSoFar = "";
    let assistantStarted = false;
    const upsert = (chunk: string) => {
      assistantSoFar += chunk;
      setMessages((prev) => {
        if (!assistantStarted) {
          assistantStarted = true;
          return [...prev, { role: "assistant", content: assistantSoFar }];
        }
        return prev.map((m, i) =>
          i === prev.length - 1 ? { ...m, content: assistantSoFar } : m,
        );
      });
    };

    try {
      const resp = await fetch(CHAT_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({
          messages: [...messages, userMsg]
            .filter((m) => m.content && m.content !== GREETING.content)
            .slice(-12)
            .map((m) => ({ role: m.role, content: m.content })),
          profile: profileCtx,
          recent,
        }),
      });

      if (!resp.ok || !resp.body) {
        if (resp.status === 429) toast.error("Limite atingido. Tenta de novo em alguns instantes.");
        else if (resp.status === 402) toast.error("Créditos de IA esgotados.");
        else toast.error("Erro ao falar com o coach.");
        setStreaming(false);
        return;
      }

      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let textBuffer = "";
      let streamDone = false;

      while (!streamDone) {
        const { done, value } = await reader.read();
        if (done) break;
        textBuffer += decoder.decode(value, { stream: true });

        let newlineIndex: number;
        while ((newlineIndex = textBuffer.indexOf("\n")) !== -1) {
          let line = textBuffer.slice(0, newlineIndex);
          textBuffer = textBuffer.slice(newlineIndex + 1);
          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (line.startsWith(":") || line.trim() === "") continue;
          if (!line.startsWith("data: ")) continue;
          const jsonStr = line.slice(6).trim();
          if (jsonStr === "[DONE]") {
            streamDone = true;
            break;
          }
          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content as string | undefined;
            if (content) upsert(content);
          } catch {
            textBuffer = line + "\n" + textBuffer;
            break;
          }
        }
      }

      if (textBuffer.trim()) {
        for (let raw of textBuffer.split("\n")) {
          if (!raw) continue;
          if (raw.endsWith("\r")) raw = raw.slice(0, -1);
          if (raw.startsWith(":") || raw.trim() === "") continue;
          if (!raw.startsWith("data: ")) continue;
          const jsonStr = raw.slice(6).trim();
          if (jsonStr === "[DONE]") continue;
          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content as string | undefined;
            if (content) upsert(content);
          } catch {
            /* ignore */
          }
        }
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Erro de conexão");
    } finally {
      setStreaming(false);
    }
  };

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    send(input);
  };

  const clearChat = () => {
    setMessages([GREETING]);
    try {
      localStorage.removeItem(MEMORY_KEY);
    } catch {
      /* ignore */
    }
    toast.success("Conversa limpa");
  };

  return (
    <div className="max-w-2xl mx-auto animate-slide-up">
      <div className="flex items-center gap-3 mb-6">
        <div className="h-12 w-12 rounded-xl bg-gradient-primary flex items-center justify-center shadow-glow">
          <Brain className="h-6 w-6 text-primary-foreground" />
        </div>
        <div className="flex-1">
          <h1 className="text-xl font-bold">Smart Coach</h1>
          <p className="text-xs text-muted-foreground">
            Contexto real: perfil, lesões, histórico e treino do dia
          </p>
        </div>
        {messages.length > 1 && (
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={clearChat}
            disabled={streaming}
            title="Limpar conversa"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        )}
      </div>

      <div className="rounded-2xl glass p-4 min-h-[480px] flex flex-col">
        <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto max-h-[60vh] pr-1">
          {messages.map((m, i) => (
            <div
              key={i}
              className={`max-w-[88%] px-4 py-2.5 rounded-2xl text-sm ${
                m.role === "user"
                  ? "ml-auto bg-gradient-primary text-primary-foreground"
                  : "bg-surface-elevated border border-border"
              }`}
            >
              {m.role === "assistant" ? (
                <div className="prose prose-sm prose-invert max-w-none [&>*]:my-1 [&>p]:leading-relaxed">
                  <ReactMarkdown>{m.content || "…"}</ReactMarkdown>
                </div>
              ) : (
                m.content
              )}
            </div>
          ))}
          {streaming && messages[messages.length - 1]?.role === "user" && (
            <div className="bg-surface-elevated border border-border max-w-[88%] px-4 py-2.5 rounded-2xl text-sm flex items-center gap-2">
              <Loader2 className="h-3.5 w-3.5 animate-spin text-primary" />
              <span className="text-muted-foreground">pensando...</span>
            </div>
          )}
        </div>

        <div className="mt-4 flex flex-wrap gap-1.5">
          {suggestions.map((s) => (
            <button
              key={s}
              type="button"
              disabled={streaming}
              onClick={() => send(s)}
              className="text-xs px-3 py-1.5 rounded-full bg-muted hover:bg-accent text-muted-foreground hover:text-foreground transition disabled:opacity-50"
            >
              {s}
            </button>
          ))}
        </div>

        <form onSubmit={onSubmit} className="mt-3 flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Pergunta algo..."
            maxLength={500}
            disabled={streaming}
          />
          <Button
            type="submit"
            disabled={!input.trim() || streaming}
            size="icon"
            className="bg-gradient-primary text-primary-foreground hover:opacity-90 shrink-0"
          >
            {streaming ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
          </Button>
        </form>
      </div>
    </div>
  );
}
