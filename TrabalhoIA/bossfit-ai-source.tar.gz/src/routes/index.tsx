import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Dumbbell, Flame, Trophy, Brain, Activity, Target } from "lucide-react";

export const Route = createFileRoute("/")({
  component: LandingPage,
});

function LandingPage() {
  const { user, loading } = useAuth();

  if (!loading && user) {
    return <Navigate to="/app" />;
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="border-b border-border/50 backdrop-blur-md bg-background/60 sticky top-0 z-40">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="h-9 w-9 rounded-lg bg-gradient-primary flex items-center justify-center shadow-glow">
              <Dumbbell className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="font-bold text-lg tracking-tight">
              BOSSFIT <span className="text-gradient-primary">AI</span>
            </span>
          </Link>
          <div className="flex items-center gap-2">
            <Link to="/auth">
              <Button variant="ghost" size="sm">Entrar</Button>
            </Link>
            <Link to="/auth" search={{ mode: "signup" }}>
              <Button size="sm" className="bg-gradient-primary text-primary-foreground hover:opacity-90">
                Começar
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="container mx-auto px-4 py-16 md:py-28">
        <div className="max-w-3xl mx-auto text-center animate-slide-up">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass text-xs text-muted-foreground mb-6">
            <span className="h-2 w-2 rounded-full bg-primary animate-pulse-glow" />
            Powered by IA — 100% personalizado
          </div>
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight leading-tight">
            Seu treino,{" "}
            <span className="text-gradient-primary">inteligente.</span>
            <br />
            Sua evolução, garantida.
          </h1>
          <p className="mt-6 text-base md:text-lg text-muted-foreground max-w-xl mx-auto">
            BOSSFIT AI cria treinos sob medida para o seu objetivo, ajusta cargas com
            base na sua performance e te mantém no ritmo com streaks e desafios.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link to="/auth" search={{ mode: "signup" }}>
              <Button size="lg" className="bg-gradient-primary text-primary-foreground hover:opacity-90 shadow-glow">
                Começar grátis
              </Button>
            </Link>
            <Link to="/auth">
              <Button size="lg" variant="outline">Já tenho conta</Button>
            </Link>
          </div>
        </div>

        {/* Features */}
        <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-4 max-w-5xl mx-auto">
          {[
            { icon: Brain, title: "IA Coach", desc: "Treinos gerados com 60% no foco e 40% complementar." },
            { icon: Activity, title: "Performance", desc: "Cargas ajustam ao seu desempenho real." },
            { icon: Flame, title: "Streak", desc: "Mantém o ritmo com a contagem de dias consecutivos." },
            { icon: Target, title: "Metas", desc: "Defina objetivo de treinos por semana e peso alvo." },
            { icon: Trophy, title: "Desafios", desc: "Desafios de 7 e 30 dias para te empurrar." },
            { icon: Dumbbell, title: "Plano semanal", desc: "Push/Pull/Legs ou Fullbody — automático." },
          ].map(({ icon: Icon, title, desc }) => (
            <div
              key={title}
              className="rounded-2xl glass p-5 shadow-card transition hover:translate-y-[-2px] hover:shadow-elevated"
            >
              <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center mb-3">
                <Icon className="h-5 w-5 text-primary" />
              </div>
              <h3 className="font-semibold">{title}</h3>
              <p className="text-sm text-muted-foreground mt-1">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-border/50 py-6 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} BOSSFIT AI — Treine como um boss.
      </footer>
    </div>
  );
}
