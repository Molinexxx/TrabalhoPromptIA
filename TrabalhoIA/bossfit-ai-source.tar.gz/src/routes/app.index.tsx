import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useMemo } from "react";
import {
  Activity,
  AlertTriangle,
  Calendar,
  CheckCircle2,
  Circle,
  Flame,
  Play,
  Sparkles,
  Target,
  TrendingUp,
  Trophy,
  Wand2,
} from "lucide-react";
import { useProfile, useUpdateProfile } from "@/lib/use-profile";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { generateIntelligentWorkout, generateWeeklyPlan } from "@/lib/workout-generator";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import type { DailyMissionsState, Quiz, WeeklyPlan, Workout } from "@/lib/types";
import { evaluateFatigue, type PerformanceRow } from "@/lib/progression";
import {
  buildHeatmap,
  ensureMissionsForToday,
  generateDailyCoachMessage,
  toggleMission,
} from "@/lib/intelligence";
import { WorkoutHeatmap } from "@/components/WorkoutHeatmap";
import { toast } from "sonner";

export const Route = createFileRoute("/app/")({
  component: DashboardPage,
});

function DashboardPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: profile } = useProfile();
  const updateProfile = useUpdateProfile();

  const { data: recentExerciseIds = [] } = useQuery({
    queryKey: ["recent-exercise-ids", user?.id],
    enabled: !!user?.id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("workout_history")
        .select("workout")
        .eq("user_id", user!.id)
        .order("completed_at", { ascending: false })
        .limit(3);
      if (error) throw error;
      const ids = new Set<string>();
      for (const row of data ?? []) {
        const w = (row as unknown as { workout: Workout }).workout;
        for (const e of [...(w.warmup ?? []), ...(w.main ?? []), ...(w.finisher ?? [])]) {
          if (e?.id) ids.add(e.id);
        }
      }
      return Array.from(ids);
    },
  });

  const { data: perfHistory = [] } = useQuery({
    queryKey: ["perf-history-dash", user?.id],
    enabled: !!user?.id,
    queryFn: async (): Promise<PerformanceRow[]> => {
      const { data, error } = await supabase
        .from("performance_history")
        .select("recorded_at, difficulty, completion_rate, time_spent, sets_completed_total, overall_rating, exercise_feedback")
        .eq("user_id", user!.id)
        .order("recorded_at", { ascending: false })
        .limit(30);
      if (error) throw error;
      return (data ?? []) as unknown as PerformanceRow[];
    },
  });

  const fatigue = useMemo(() => evaluateFatigue(perfHistory), [perfHistory]);
  const dailyCoach = useMemo(
    () => generateDailyCoachMessage(profile, perfHistory),
    [profile, perfHistory],
  );
  const heatmap = useMemo(() => buildHeatmap(perfHistory, 12), [perfHistory]);

  const missions: DailyMissionsState = useMemo(
    () => ensureMissionsForToday(profile?.daily_missions, profile?.quiz),
    [profile?.daily_missions, profile?.quiz],
  );

  // Auto-rotação semanal: define o foco de cada dia respeitando descanso muscular.
  // Se o foco do plano para hoje for igual ao último treino, sugere alternar.
  const dailyWorkout = useMemo<Workout | null>(() => {
    const dw = profile?.daily_workout;
    if (!dw || !("id" in (dw as object))) return null;
    return dw as Workout;
  }, [profile]);

  const weeklyPlan = useMemo<WeeklyPlan | null>(() => {
    const wp = profile?.weekly_plan;
    if (!wp || !("type" in (wp as object))) return null;
    return wp as WeeklyPlan;
  }, [profile]);

  // Persist atualizações de missões no DB (debounced via mutation rápida)
  useEffect(() => {
    if (!profile) return;
    const stored = profile.daily_missions;
    if (!stored || stored.date !== missions.date) {
      // datas batem ou stored ausente — gravar para hoje
      updateProfile.mutate({ daily_missions: missions });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [missions.date, profile?.id]);

  if (!profile) return null;

  const handleToggleMission = (id: string) => {
    const next = toggleMission(missions, id);
    if (navigator.vibrate) navigator.vibrate(40);
    updateProfile.mutate({ daily_missions: next });
  };

  const handleGenerateWorkout = async (auto = false) => {
    if (!profile.quiz_completed) return;
    try {
      const todayIdx = new Date().getDay();
      const planDay = weeklyPlan?.days[todayIdx % (weeklyPlan?.days.length || 1)];
      // Modo auto: rotação respeitando descanso muscular
      let focus = planDay?.focus;
      if (auto && dailyWorkout) {
        const lastFocus = (dailyWorkout.focus ?? "").toLowerCase();
        if (focus && lastFocus.includes(focus)) {
          // alterna para complementar
          const rotation = ["peito", "costas", "pernas"] as const;
          const idx = rotation.findIndex((f) => f === focus);
          if (idx >= 0) focus = rotation[(idx + 1) % rotation.length];
        }
      }
      const workout = generateIntelligentWorkout(
        { quiz: profile.quiz },
        recentExerciseIds,
        focus,
      );
      const wp = weeklyPlan ?? generateWeeklyPlan(profile.quiz as Quiz);
      await updateProfile.mutateAsync({
        daily_workout: workout,
        weekly_plan: wp,
      });
      toast.success(auto ? "Treino automático pronto 🤖" : "Treino gerado!");
      if (auto) navigate({ to: "/app/treino/focus" });
      else navigate({ to: "/app/treino" });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Erro ao gerar treino");
    }
  };

  const goalsPerWeek = profile.goals?.workoutsPerWeek ?? 4;
  const xp = profile.progression?.xp ?? 0;
  const level = profile.progression?.level ?? 1;
  const xpToNext = level * 200;
  const xpProgress = Math.min(100, Math.round((xp / xpToNext) * 100));
  const missionsDone = missions.items.filter((m) => m.done).length;
  const missionsTotal = missions.items.length;

  const coachTone =
    dailyCoach.tone === "warning"
      ? "border-warning/50 bg-warning/10"
      : dailyCoach.tone === "success"
        ? "border-primary/40 bg-primary/10"
        : "border-primary/30 bg-primary/5";

  return (
    <div className="space-y-6 animate-slide-up">
      {/* Welcome */}
      <div className="flex items-center gap-4">
        <Link
          to="/app/perfil"
          className="shrink-0 rounded-full ring-2 ring-primary/40 hover:ring-primary hover:shadow-glow transition-all"
          title="Editar perfil"
        >
          <Avatar className="h-14 w-14">
            <AvatarImage src={profile.avatar_url ?? undefined} alt={profile.username ?? "Perfil"} />
            <AvatarFallback className="bg-gradient-primary text-primary-foreground text-lg font-bold">
              {(profile.username ?? "U").slice(0, 1).toUpperCase()}
            </AvatarFallback>
          </Avatar>
        </Link>
        <div className="min-w-0">
          <p className="text-sm text-muted-foreground">
            Olá, <span className="text-foreground font-medium">{profile.username}</span> 👋
          </p>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight mt-1 truncate">
            Pronto para treinar como um <span className="text-gradient-primary">boss?</span>
          </h1>
        </div>
      </div>

      {/* Daily coach card */}
      <div className={`rounded-2xl border p-5 shadow-card ${coachTone}`}>
        <div className="flex items-start gap-3">
          <div className="text-3xl leading-none">{dailyCoach.emoji}</div>
          <div className="flex-1 min-w-0">
            <div className="text-xs uppercase tracking-widest text-primary font-bold">
              Mensagem do coach
            </div>
            <div className="font-bold mt-1">{dailyCoach.title}</div>
            <p className="text-sm text-muted-foreground mt-0.5">{dailyCoach.body}</p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={Flame} label="Streak" value={`${profile.streak} dias`} accent />
        <StatCard icon={Trophy} label="Nível" value={`${level}`} sub={`${xp}/${xpToNext} XP`} />
        <StatCard icon={Target} label="Meta semanal" value={`${goalsPerWeek}x`} />
        <StatCard icon={Activity} label="Score ranking" value={`${profile.ranking_score}`} />
      </div>

      {/* XP bar (animada) */}
      <div className="rounded-xl glass p-4">
        <div className="flex items-center justify-between text-xs mb-2">
          <span className="text-muted-foreground">
            Progresso para nível <span className="text-foreground font-bold">{level + 1}</span>
          </span>
          <span className="text-primary font-bold">{xpProgress}%</span>
        </div>
        <div className="h-3 bg-muted rounded-full overflow-hidden relative">
          <div
            className="h-full bg-gradient-primary transition-all duration-1000 ease-out relative"
            style={{ width: `${xpProgress}%` }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-pulse" />
          </div>
        </div>
        <div className="text-[11px] text-muted-foreground mt-1.5">
          Faltam {Math.max(0, xpToNext - xp)} XP — em média 1 treino vale ~80 XP.
        </div>
      </div>

      {/* Today checklist */}
      <div className="rounded-2xl glass p-5">
        <div className="flex items-center justify-between mb-3">
          <div>
            <div className="text-xs uppercase tracking-widest text-primary font-bold">
              Hoje você precisa
            </div>
            <div className="text-sm text-muted-foreground">
              {missionsDone}/{missionsTotal} concluídas
            </div>
          </div>
          <div className="text-2xl font-black text-primary tabular-nums">
            {Math.round((missionsDone / Math.max(1, missionsTotal)) * 100)}%
          </div>
        </div>
        <ul className="space-y-1.5">
          {missions.items.map((m) => (
            <li key={m.id}>
              <button
                type="button"
                onClick={() => handleToggleMission(m.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg border transition text-left ${
                  m.done
                    ? "border-primary/40 bg-primary/10 text-foreground"
                    : "border-border/50 hover:border-primary/40 hover:bg-accent/40"
                }`}
              >
                {m.done ? (
                  <CheckCircle2 className="h-5 w-5 text-primary shrink-0" />
                ) : (
                  <Circle className="h-5 w-5 text-muted-foreground shrink-0" />
                )}
                <span className={`text-sm font-medium ${m.done ? "line-through opacity-70" : ""}`}>
                  {m.label}
                </span>
              </button>
            </li>
          ))}
        </ul>
      </div>

      {/* Fatigue / evolution strip */}
      <Link
        to="/app/evolucao"
        className={`block rounded-xl border p-4 transition hover:shadow-glow ${
          fatigue.level === "deload"
            ? "border-destructive/50 bg-destructive/10"
            : fatigue.level === "watch"
              ? "border-warning/50 bg-warning/10"
              : "border-primary/30 bg-primary/5"
        }`}
      >
        <div className="flex items-center gap-3">
          <div
            className={`h-10 w-10 rounded-xl flex items-center justify-center shrink-0 ${
              fatigue.level === "deload"
                ? "bg-destructive/20 text-destructive"
                : fatigue.level === "watch"
                  ? "bg-warning/20 text-warning"
                  : "bg-primary/20 text-primary"
            }`}
          >
            {fatigue.level === "ok" ? (
              <TrendingUp className="h-5 w-5" />
            ) : (
              <AlertTriangle className="h-5 w-5" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs font-bold uppercase tracking-wider">
              {fatigue.level === "deload"
                ? "Deload sugerido"
                : fatigue.level === "watch"
                  ? "Atenção à carga"
                  : "Performance no eixo"}
            </div>
            <div className="text-sm text-muted-foreground truncate">{fatigue.recommendation}</div>
          </div>
          <div className="text-xs text-primary font-bold shrink-0">Ver →</div>
        </div>
      </Link>

      {/* Workout card */}
      <div className="rounded-2xl bg-gradient-surface border border-border/50 p-6 shadow-elevated">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 text-xs text-primary uppercase tracking-wider font-semibold">
              <Sparkles className="h-3.5 w-3.5" />
              Treino do dia
            </div>
            <h2 className="text-xl md:text-2xl font-bold mt-2 truncate">
              {dailyWorkout?.title ?? "Nenhum treino gerado"}
            </h2>
            {dailyWorkout && (
              <p className="text-sm text-muted-foreground mt-1">
                {dailyWorkout.main.length} exercícios principais · ~{dailyWorkout.estimatedMinutes} min
              </p>
            )}
          </div>
        </div>

        <div className="mt-5 flex flex-col sm:flex-row gap-2">
          {dailyWorkout ? (
            <>
              <Link to="/app/treino" className="flex-1">
                <Button className="w-full bg-gradient-primary text-primary-foreground hover:opacity-90 shadow-glow">
                  <Play className="h-4 w-4 mr-2" /> Iniciar treino
                </Button>
              </Link>
              <Button
                variant="outline"
                onClick={() => handleGenerateWorkout(false)}
                disabled={updateProfile.isPending}
              >
                <Sparkles className="h-4 w-4 mr-2" />
                Gerar novo
              </Button>
            </>
          ) : (
            <Button
              onClick={() => handleGenerateWorkout(false)}
              disabled={updateProfile.isPending}
              className="w-full bg-gradient-primary text-primary-foreground hover:opacity-90 shadow-glow"
            >
              <Sparkles className="h-4 w-4 mr-2" />
              {updateProfile.isPending ? "Gerando..." : "Gerar treino com IA"}
            </Button>
          )}
        </div>

        {/* Modo automático */}
        <button
          type="button"
          onClick={() => handleGenerateWorkout(true)}
          disabled={updateProfile.isPending}
          className="mt-3 w-full rounded-xl border border-primary/30 bg-primary/5 hover:bg-primary/10 px-4 py-3 text-left transition disabled:opacity-60"
        >
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-gradient-primary flex items-center justify-center shadow-glow shrink-0">
              <Wand2 className="h-4 w-4 text-primary-foreground" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-bold">Modo automático</div>
              <div className="text-xs text-muted-foreground">
                Eu escolho foco, carga e exercícios — você só treina.
              </div>
            </div>
            <span className="text-xs font-bold text-primary">Iniciar →</span>
          </div>
        </button>
      </div>

      {/* Weekly plan */}
      {weeklyPlan && (
        <div className="rounded-2xl glass p-5">
          <div className="flex items-center gap-2 mb-4">
            <Calendar className="h-4 w-4 text-primary" />
            <h3 className="font-semibold">Plano semanal — {weeklyPlan.type}</h3>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-2">
            {weeklyPlan.days.map((d, i) => (
              <div
                key={i}
                className="rounded-lg bg-surface-elevated/60 border border-border/50 px-3 py-2 text-center"
              >
                <div className="text-xs text-muted-foreground">Dia {i + 1}</div>
                <div className="text-sm font-semibold mt-0.5">{d.label}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Heatmap */}
      <div className="rounded-2xl glass p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-primary" />
            <h3 className="font-semibold">Calendário de treinos</h3>
          </div>
          <Link to="/app/evolucao" className="text-xs text-primary font-bold hover:underline">
            Ver evolução →
          </Link>
        </div>
        <WorkoutHeatmap data={heatmap} />
      </div>

      {/* Challenges */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <ChallengeCard
          title="Desafio 7 dias"
          progress={profile.challenges?.d7?.progress ?? 0}
          total={7}
          completed={profile.challenges?.d7?.completed ?? false}
        />
        <ChallengeCard
          title="Desafio 30 dias"
          progress={profile.challenges?.d30?.progress ?? 0}
          total={30}
          completed={profile.challenges?.d30?.completed ?? false}
        />
      </div>
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  sub,
  accent,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
  sub?: string;
  accent?: boolean;
}) {
  return (
    <div className={`rounded-xl glass p-4 ${accent ? "shadow-glow" : "shadow-card"}`}>
      <div className="flex items-center gap-2 text-muted-foreground text-xs">
        <Icon className={`h-4 w-4 ${accent ? "text-primary" : ""}`} />
        {label}
      </div>
      <div className="text-xl font-bold mt-2">{value}</div>
      {sub && <div className="text-xs text-muted-foreground mt-0.5">{sub}</div>}
    </div>
  );
}

function ChallengeCard({
  title,
  progress,
  total,
  completed,
}: {
  title: string;
  progress: number;
  total: number;
  completed: boolean;
}) {
  const pct = Math.min(100, Math.round((progress / total) * 100));
  return (
    <div className="rounded-xl glass p-4">
      <div className="flex items-center justify-between mb-2">
        <h4 className="font-semibold text-sm">{title}</h4>
        {completed ? (
          <span className="text-xs text-primary font-bold">✓ Concluído</span>
        ) : (
          <span className="text-xs text-muted-foreground">{progress}/{total}</span>
        )}
      </div>
      <div className="h-2 bg-muted rounded-full overflow-hidden">
        <div
          className="h-full bg-gradient-primary transition-all duration-500"
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}
