import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { z } from "zod";
import { Dumbbell } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/lib/auth";
import { toast } from "sonner";

const authSearchSchema = z.object({
  mode: z.enum(["signin", "signup"]).optional(),
});

export const Route = createFileRoute("/auth")({
  validateSearch: authSearchSchema,
  component: AuthPage,
});

const signupSchema = z.object({
  username: z.string().trim().min(2, "Mín. 2 caracteres").max(40, "Máx. 40 caracteres"),
  email: z.string().trim().email("Email inválido").max(255),
  password: z.string().min(6, "Mín. 6 caracteres").max(72, "Máx. 72 caracteres"),
});
const signinSchema = z.object({
  email: z.string().trim().email("Email inválido"),
  password: z.string().min(6),
});

function AuthPage() {
  const { mode = "signin" } = Route.useSearch();
  const navigate = useNavigate();
  const { signIn, signUp, signInWithGoogle, user } = useAuth();
  const [isSignup, setIsSignup] = useState(mode === "signup");
  const [submitting, setSubmitting] = useState(false);
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  if (user) {
    navigate({ to: "/app" });
    return null;
  }

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (submitting) return;
    setError(null);
    try {
      if (isSignup) {
        const parsed = signupSchema.safeParse({ username, email, password });
        if (!parsed.success) {
          setError(parsed.error.issues[0]?.message ?? "Dados inválidos");
          return;
        }
        setSubmitting(true);
        const { error } = await signUp(parsed.data.email, parsed.data.password, parsed.data.username);
        if (error) {
          setError(error);
        } else {
          toast.success("Conta criada! Redirecionando...");
          navigate({ to: "/app" });
        }
      } else {
        const parsed = signinSchema.safeParse({ email, password });
        if (!parsed.success) {
          setError(parsed.error.issues[0]?.message ?? "Dados inválidos");
          return;
        }
        setSubmitting(true);
        const { error } = await signIn(parsed.data.email, parsed.data.password);
        if (error) {
          setError(error);
        } else {
          navigate({ to: "/app" });
        }
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleGoogle = async () => {
    setError(null);
    const { error } = await signInWithGoogle();
    if (error) setError(error);
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-10">
      <div className="w-full max-w-md animate-slide-up">
        <Link to="/" className="flex items-center justify-center gap-2 mb-8">
          <div className="h-10 w-10 rounded-lg bg-gradient-primary flex items-center justify-center shadow-glow">
            <Dumbbell className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="font-bold text-xl">
            BOSSFIT <span className="text-gradient-primary">AI</span>
          </span>
        </Link>

        <div className="rounded-2xl glass p-6 md:p-8 shadow-elevated">
          <h1 className="text-2xl font-bold tracking-tight">
            {isSignup ? "Crie sua conta" : "Bem-vindo de volta"}
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            {isSignup ? "Comece a treinar como um boss." : "Entre para continuar treinando."}
          </p>

          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            {isSignup && (
              <div>
                <Label htmlFor="username">Nome de usuário</Label>
                <Input
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="boss_atleta"
                  maxLength={40}
                  required
                />
              </div>
            )}
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="voce@email.com"
                maxLength={255}
                required
              />
            </div>
            <div>
              <Label htmlFor="password">Senha</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                minLength={6}
                maxLength={72}
                required
              />
            </div>

            {error && (
              <div className="text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-md px-3 py-2">
                {error}
              </div>
            )}

            <Button
              type="submit"
              disabled={submitting}
              className="w-full bg-gradient-primary text-primary-foreground hover:opacity-90 shadow-glow"
            >
              {submitting ? "Aguarde..." : isSignup ? "Criar conta" : "Entrar"}
            </Button>
          </form>

          <div className="my-5 flex items-center gap-3">
            <div className="h-px flex-1 bg-border" />
            <span className="text-xs text-muted-foreground uppercase">ou</span>
            <div className="h-px flex-1 bg-border" />
          </div>

          <Button type="button" variant="outline" className="w-full" onClick={handleGoogle}>
            <svg className="h-4 w-4 mr-2" viewBox="0 0 24 24">
              <path fill="#EA4335" d="M12 5.04c1.85 0 3.5.64 4.81 1.88l3.6-3.6C18.16 1.13 15.36 0 12 0 7.32 0 3.27 2.69 1.28 6.6l4.19 3.25C6.45 6.97 8.99 5.04 12 5.04Z"/>
              <path fill="#4285F4" d="M23.49 12.27c0-.79-.07-1.54-.2-2.27H12v4.51h6.47c-.28 1.45-1.13 2.68-2.41 3.51l3.94 3.05c2.31-2.13 3.49-5.27 3.49-8.8Z"/>
              <path fill="#FBBC05" d="M5.47 14.35a7.27 7.27 0 0 1 0-4.7L1.28 6.4A11.99 11.99 0 0 0 0 12c0 1.94.46 3.78 1.28 5.4l4.19-3.05Z"/>
              <path fill="#34A853" d="M12 24c3.24 0 5.96-1.07 7.95-2.91l-3.94-3.05c-1.09.73-2.49 1.16-4.01 1.16-3.01 0-5.55-1.93-6.53-4.81L1.28 17.4C3.27 21.31 7.32 24 12 24Z"/>
            </svg>
            Continuar com Google
          </Button>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            {isSignup ? "Já tem conta?" : "Não tem conta?"}{" "}
            <button
              type="button"
              onClick={() => { setIsSignup(!isSignup); setError(null); }}
              className="text-primary font-medium hover:underline"
            >
              {isSignup ? "Entrar" : "Criar conta"}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
