import type { Exercise, FocoMuscular, Profile, Quiz, WeeklyPlan, Workout } from "./types";
import { EXERCISE_LIBRARY, FINISHER_POOL, WARMUP_POOL } from "./exercises";

const ALL_MUSCLES: FocoMuscular[] = ["peito", "costas", "pernas", "ombros", "bracos", "core"];

function pickRandom<T>(arr: T[], n: number, exclude: Set<string> = new Set()): T[] {
  const filtered = arr.filter((x) => !exclude.has((x as { id: string }).id));
  const pool = filtered.length >= n ? filtered : arr;
  const shuffled = [...pool].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, n);
}

function repsForObjective(objetivo: Quiz["objetivo"]): { sets: number; reps: number; rest: number } {
  switch (objetivo) {
    case "forca":
      return { sets: 5, reps: 6, rest: 120 };
    case "hipertrofia":
      return { sets: 4, reps: 10, rest: 75 };
    case "emagrecimento":
      return { sets: 3, reps: 15, rest: 45 };
    case "condicionamento":
      return { sets: 3, reps: 12, rest: 30 };
  }
}

function jitter(base: number, range: number, min: number, max: number) {
  const v = base + Math.round((Math.random() * 2 - 1) * range);
  return Math.max(min, Math.min(max, v));
}

export function generateIntelligentWorkout(
  profile: Pick<Profile, "quiz">,
  recentExerciseIds: string[] = [],
  todayFocus?: FocoMuscular | "fullbody",
): Workout {
  const quiz = profile.quiz as Quiz;
  const focus = todayFocus ?? quiz.focoMuscular ?? "fullbody";
  const recent = new Set(recentExerciseIds);
  const base = repsForObjective(quiz.objetivo ?? "hipertrofia");

  // Warmup: 2 exercises
  const warmup: Exercise[] = pickRandom(WARMUP_POOL, 2).map((d) => ({
    ...d,
    sets: 1,
    reps: 30, // seconds for warmup
    rest: 20,
    type: "warmup",
    setsCompleted: 0,
    done: false,
  }));

  // Main: 60% focus, 40% complementary
  const mainCount = quiz.nivel === "iniciante" ? 5 : quiz.nivel === "avancado" ? 7 : 6;
  const focusCount = Math.round(mainCount * 0.6);
  const complementaryCount = mainCount - focusCount;

  let focusPool: typeof EXERCISE_LIBRARY[FocoMuscular];
  if (focus === "fullbody") {
    focusPool = ALL_MUSCLES.flatMap((m) => EXERCISE_LIBRARY[m]);
  } else {
    focusPool = EXERCISE_LIBRARY[focus] ?? EXERCISE_LIBRARY.fullbody;
  }

  const complementaryMuscles = ALL_MUSCLES.filter((m) => m !== focus);
  const complementaryPool = complementaryMuscles.flatMap((m) => EXERCISE_LIBRARY[m]);

  const focusPicks = pickRandom(focusPool, focusCount, recent);
  const complementaryPicks = pickRandom(complementaryPool, complementaryCount, recent);

  const main: Exercise[] = [...focusPicks, ...complementaryPicks].map((d) => ({
    ...d,
    sets: jitter(base.sets, 1, 3, 5),
    reps: jitter(base.reps, 2, 6, 15),
    rest: base.rest,
    type: "main",
    setsCompleted: 0,
    done: false,
  }));

  // Finisher: 1 exercise
  const finisher: Exercise[] = pickRandom(FINISHER_POOL, 1).map((d) => ({
    ...d,
    sets: 1,
    reps: 60,
    rest: 0,
    type: "finisher",
    setsCompleted: 0,
    done: false,
  }));

  const totalSets = main.reduce((s, e) => s + e.sets, 0) + warmup.length + finisher.length;
  const estimatedMinutes = Math.max(20, Math.round(totalSets * 1.6));

  const focusLabel =
    focus === "fullbody" ? "Fullbody" : focus.charAt(0).toUpperCase() + focus.slice(1);

  return {
    id: crypto.randomUUID(),
    title: `Treino do dia — ${focusLabel}`,
    focus: focusLabel,
    estimatedMinutes,
    warmup,
    main,
    finisher,
    createdAt: new Date().toISOString(),
  };
}

export function generateWeeklyPlan(quiz: Quiz): WeeklyPlan {
  if (quiz.frequencia >= 4) {
    const days: WeeklyPlan["days"] = [];
    const cycle: Array<{ label: string; focus: FocoMuscular }> = [
      { label: "Push", focus: "peito" },
      { label: "Pull", focus: "costas" },
      { label: "Legs", focus: "pernas" },
    ];
    for (let i = 0; i < quiz.frequencia; i++) {
      const item = cycle[i % 3];
      days.push({ label: `${item.label} ${Math.floor(i / 3) + 1}`, focus: item.focus });
    }
    return { type: "PPL", days };
  }
  return {
    type: "FULLBODY",
    days: Array.from({ length: quiz.frequencia }, (_, i) => ({
      label: `Fullbody ${i + 1}`,
      focus: "fullbody",
    })),
  };
}
