// Wave 3: estimativa de carga em kg, coach diário, missões diárias, insights
import type {
  DailyMission,
  DailyMissionsState,
  Exercise,
  Nivel,
  Profile,
  Quiz,
} from "./types";
import type { PerformanceRow } from "./progression";

// ─────────────────────────────────────────────────────────────────────────────
// 1. CARGA EM KG (estimativa híbrida)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Pesos base referenciais (kg) para um intermediário de 75kg fazendo ~10 reps.
 * Inclui matches por substring/keyword para nomes em PT-BR.
 */
const BASE_KG: Array<{ match: RegExp; kg: number; bw?: boolean }> = [
  { match: /supino reto/i, kg: 50 },
  { match: /supino inclinado/i, kg: 22 }, // halter por mão
  { match: /supino/i, kg: 45 },
  { match: /merg(u|û)lho|dips/i, kg: 0, bw: true },
  { match: /crossover|cross\s*over|cabo/i, kg: 12 },
  { match: /flex(ã|a)o de bra(ç|c)o|push\s*up/i, kg: 0, bw: true },
  { match: /barra fixa|pull\s*up/i, kg: 0, bw: true },
  { match: /remada curvada/i, kg: 40 },
  { match: /remada/i, kg: 35 },
  { match: /puxada/i, kg: 45 },
  { match: /levantamento terra|deadlift/i, kg: 80 },
  { match: /agachamento|squat/i, kg: 60 },
  { match: /leg press/i, kg: 120 },
  { match: /stiff/i, kg: 50 },
  { match: /avan(ç|c)o|lunge/i, kg: 14 },
  { match: /mesa flexora|leg curl/i, kg: 35 },
  { match: /panturrilha|calf/i, kg: 60 },
  { match: /desenvolvimento|ohp|press/i, kg: 30 },
  { match: /eleva(ç|c)(ã|a)o lateral/i, kg: 8 },
  { match: /crucifixo/i, kg: 10 },
  { match: /arnold/i, kg: 14 },
  { match: /rosca direta|barbell curl/i, kg: 18 },
  { match: /rosca martelo|hammer/i, kg: 12 },
  { match: /tr(í|i)ceps.*polia|pushdown/i, kg: 25 },
  { match: /tr(í|i)ceps.*testa|skull/i, kg: 18 },
  { match: /prancha|plank/i, kg: 0, bw: true },
  { match: /eleva(ç|c)(ã|a)o de pernas/i, kg: 0, bw: true },
  { match: /russian twist/i, kg: 6 },
  { match: /roda abdominal|ab\s*wheel/i, kg: 0, bw: true },
  { match: /burpee/i, kg: 0, bw: true },
  { match: /kettlebell|kb\s*swing/i, kg: 16 },
  { match: /thruster/i, kg: 25 },
  { match: /clean/i, kg: 35 },
];

const NIVEL_MULT: Record<Nivel, number> = {
  iniciante: 0.7,
  intermediario: 1.0,
  avancado: 1.25,
};

/**
 * Estima a carga (kg) de um exercício para o usuário.
 * Combina: tabela base × multiplicador de nível × loadFactor × ajuste por peso corporal × feedback recente.
 * Retorna null para exercícios de peso corporal (push-ups, prancha, burpee).
 */
export function estimateExerciseKg(
  exerciseName: string,
  profile: Pick<Profile, "quiz" | "progression"> | null | undefined,
  history: PerformanceRow[] = [],
): { kg: number | null; isBodyweight: boolean; trend: "up" | "down" | "flat" } {
  const entry = BASE_KG.find((b) => b.match.test(exerciseName));
  const isBw = entry?.bw ?? false;
  if (isBw) return { kg: null, isBodyweight: true, trend: "flat" };

  const baseKg = entry?.kg ?? 20; // fallback genérico
  const nivel: Nivel = (profile?.quiz?.nivel as Nivel) ?? "intermediario";
  const peso = profile?.quiz?.peso ?? 75;
  const loadFactor = profile?.progression?.loadFactor ?? 1.0;

  // Ajuste por peso corporal (referência 75kg, peso = 0.4 do efeito)
  const bodyAdjust = 1 + ((peso - 75) / 75) * 0.4;
  // Ajuste por feedback recente do exercício
  let feedbackDelta = 0;
  let trend: "up" | "down" | "flat" = "flat";
  const fbs: string[] = [];
  for (const row of history.slice(0, 5)) {
    for (const ef of row.exercise_feedback ?? []) {
      if (ef?.name === exerciseName && ef.feedback) fbs.push(ef.feedback);
    }
  }
  if (fbs.length > 0) {
    const leves = fbs.filter((f) => f === "leve").length;
    const pesados = fbs.filter((f) => f === "pesado").length;
    const score = (leves - pesados) / fbs.length;
    feedbackDelta = score * 0.07;
    if (feedbackDelta > 0.02) trend = "up";
    else if (feedbackDelta < -0.02) trend = "down";
  }

  const raw = baseKg * NIVEL_MULT[nivel] * loadFactor * bodyAdjust * (1 + feedbackDelta);
  // Arredonda para múltiplos de 2.5kg (incrementos típicos de academia)
  const kg = Math.max(2.5, Math.round(raw / 2.5) * 2.5);
  return { kg, isBodyweight: false, trend };
}

// ─────────────────────────────────────────────────────────────────────────────
// 2. TEMPO ESPERADO POR SÉRIE (para adaptação em tempo real)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Tempo esperado em segundos para concluir uma série de um exercício.
 * Reps × ~3s (tempo médio) + 4s de setup. Usado para detectar lentidão/rapidez.
 */
export function expectedSecondsPerSet(ex: Exercise): number {
  if (ex.type === "warmup" || ex.type === "finisher") return ex.reps; // reps = segundos
  return ex.reps * 3 + 4;
}

export type AdaptiveSignal = "slow" | "fast" | "ok";

/**
 * Compara o tempo gasto vs esperado e retorna o sinal adaptativo.
 * slow: usuário demora >1.4× → reduzir intensidade
 * fast: usuário conclui <0.7× → aumentar dificuldade
 */
export function adaptiveSignal(actualSec: number, expectedSec: number): AdaptiveSignal {
  if (expectedSec <= 0) return "ok";
  const ratio = actualSec / expectedSec;
  if (ratio > 1.4) return "slow";
  if (ratio < 0.7 && actualSec > 4) return "fast";
  return "ok";
}

export function adaptiveMessage(signal: AdaptiveSignal): string | null {
  if (signal === "slow") return "Tá pesado — considera reduzir um pouco a carga na próxima série.";
  if (signal === "fast") return "Mandou rápido demais. Sobe a carga ou capricha na execução.";
  return null;
}

// ─────────────────────────────────────────────────────────────────────────────
// 3. COACH DIÁRIO (mensagem automática ao abrir o app)
// ─────────────────────────────────────────────────────────────────────────────

export interface DailyCoachMessage {
  emoji: string;
  title: string;
  body: string;
  tone: "primary" | "warning" | "success";
}

export function generateDailyCoachMessage(
  profile: Profile | null | undefined,
  history: PerformanceRow[] = [],
): DailyCoachMessage {
  const streak = profile?.streak ?? 0;
  const last3 = history.slice(0, 3);
  const avgComp = last3.length
    ? last3.reduce((s, r) => s + (r.completion_rate ?? 0), 0) / last3.length
    : 0;
  const avgDiff = last3.length
    ? last3.reduce((s, r) => s + (r.difficulty ?? 0), 0) / last3.length
    : 0;

  // Sem treinos hoje + streak alto
  if (streak >= 7) {
    return {
      emoji: "🔥",
      title: `${streak} dias seguidos`,
      body: "Mantém o ritmo. Hoje, foque em execução controlada.",
      tone: "success",
    };
  }
  // Performance caindo
  if (last3.length >= 2 && avgComp < 0.65) {
    return {
      emoji: "🛑",
      title: "Seu rendimento caiu",
      body: "Reduza intensidade hoje. Foque em técnica e respiração.",
      tone: "warning",
    };
  }
  // Performance forte
  if (last3.length >= 2 && avgComp >= 0.9 && avgDiff <= 3) {
    return {
      emoji: "📈",
      title: "Você pode aumentar carga hoje",
      body: "Últimos treinos foram leves. Sobe 5–10% no principal.",
      tone: "success",
    };
  }
  // Voltando após pausa
  const last = profile?.last_workout_date;
  if (last) {
    const daysSince = Math.floor((Date.now() - new Date(last).getTime()) / 86400000);
    if (daysSince >= 3) {
      return {
        emoji: "💪",
        title: "Bom te ver de volta",
        body: "Comece leve hoje, reativa o corpo. Amanhã sobe.",
        tone: "primary",
      };
    }
  }
  // Default motivacional rotativo
  const variants: DailyCoachMessage[] = [
    {
      emoji: "⚡",
      title: "Hoje é dia de execução",
      body: "Não precisa ser perfeito. Precisa ser feito.",
      tone: "primary",
    },
    {
      emoji: "🎯",
      title: "Foco no controle",
      body: "Cadência lenta na descida. Sente o músculo trabalhar.",
      tone: "primary",
    },
    {
      emoji: "🚀",
      title: "Aquece bem hoje",
      body: "5 minutos extras de aquecimento = 0 lesões na semana.",
      tone: "primary",
    },
  ];
  // Determinístico por dia (não muda a cada refresh)
  const dayIdx = new Date().getDate() % variants.length;
  return variants[dayIdx];
}

// ─────────────────────────────────────────────────────────────────────────────
// 4. MISSÕES DIÁRIAS
// ─────────────────────────────────────────────────────────────────────────────

const TODAY = () => new Date().toISOString().slice(0, 10);

export function defaultDailyMissions(quiz: Partial<Quiz> | undefined): DailyMission[] {
  const base: DailyMission[] = [
    { id: "workout", label: "Concluir o treino do dia", done: false },
    { id: "water", label: "Beber 2L de água", done: false },
    { id: "stretch", label: "Fazer 5 min de alongamento", done: false },
  ];
  if (quiz?.objetivo === "hipertrofia") {
    base.push({ id: "protein", label: "Atingir meta de proteína", done: false });
  } else if (quiz?.objetivo === "emagrecimento") {
    base.push({ id: "steps", label: "Caminhar 8.000+ passos", done: false });
  }
  return base;
}

/**
 * Garante que o estado de missões está atualizado para hoje.
 * Se a data não bate, regenera.
 */
export function ensureMissionsForToday(
  state: DailyMissionsState | null | undefined,
  quiz: Partial<Quiz> | undefined,
): DailyMissionsState {
  const today = TODAY();
  if (!state || state.date !== today || !state.items?.length) {
    return { date: today, items: defaultDailyMissions(quiz) };
  }
  return state;
}

export function toggleMission(state: DailyMissionsState, id: string): DailyMissionsState {
  return {
    ...state,
    items: state.items.map((m) => (m.id === id ? { ...m, done: !m.done } : m)),
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// 5. INSIGHTS AUTOMÁTICOS (aba evolução)
// ─────────────────────────────────────────────────────────────────────────────

export interface AutoInsight {
  emoji: string;
  text: string;
  positive: boolean;
}

export function generateAutoInsights(history: PerformanceRow[]): AutoInsight[] {
  const out: AutoInsight[] = [];
  if (history.length < 2) return out;

  const now = Date.now();
  const week = 7 * 86400000;
  const thisWeek = history.filter(
    (r) => r.recorded_at && now - new Date(r.recorded_at).getTime() < week,
  );
  const lastWeek = history.filter((r) => {
    if (!r.recorded_at) return false;
    const t = now - new Date(r.recorded_at).getTime();
    return t >= week && t < 2 * week;
  });

  // Volume semanal
  if (lastWeek.length > 0) {
    const delta = thisWeek.length - lastWeek.length;
    const pct = Math.round(((thisWeek.length - lastWeek.length) / lastWeek.length) * 100);
    if (delta > 0) {
      out.push({
        emoji: "📈",
        text: `Você treinou ${pct}% mais essa semana (${thisWeek.length} vs ${lastWeek.length}).`,
        positive: true,
      });
    } else if (delta < 0) {
      out.push({
        emoji: "📉",
        text: `Caiu ${Math.abs(pct)}% no volume essa semana. Bora retomar.`,
        positive: false,
      });
    }
  }

  // Tempo médio
  if (thisWeek.length >= 2 && lastWeek.length >= 2) {
    const avgT = (rs: PerformanceRow[]) =>
      rs.reduce((s, r) => s + (r.time_spent ?? 0), 0) / rs.length;
    const a = avgT(thisWeek);
    const b = avgT(lastWeek);
    if (b > 0) {
      const dPct = Math.round(((a - b) / b) * 100);
      if (Math.abs(dPct) >= 8) {
        out.push({
          emoji: dPct < 0 ? "⏱️" : "🐢",
          text:
            dPct < 0
              ? `Seu tempo médio diminuiu ${Math.abs(dPct)}% — mais eficiência.`
              : `Tempo médio ${dPct}% maior. Diminua o descanso entre séries.`,
          positive: dPct < 0,
        });
      }
    }
  }

  // Conclusão
  const recent5 = history.slice(0, 5);
  if (recent5.length >= 3) {
    const avgComp = recent5.reduce((s, r) => s + (r.completion_rate ?? 0), 0) / recent5.length;
    if (avgComp >= 0.9) {
      out.push({
        emoji: "✅",
        text: `Conclusão ${Math.round(avgComp * 100)}% nos últimos ${recent5.length} treinos. Consistência total.`,
        positive: true,
      });
    } else if (avgComp < 0.6) {
      out.push({
        emoji: "⚠️",
        text: `Você está fechando só ${Math.round(avgComp * 100)}% dos treinos. Reduza volume.`,
        positive: false,
      });
    }
  }

  // Dificuldade
  if (recent5.length >= 3) {
    const avgD = recent5.reduce((s, r) => s + (r.difficulty ?? 0), 0) / recent5.length;
    const olderAvgD =
      history.slice(5, 10).reduce((s, r) => s + (r.difficulty ?? 0), 0) /
      Math.max(1, history.slice(5, 10).length);
    if (olderAvgD > 0 && avgD < olderAvgD - 0.5) {
      out.push({
        emoji: "💪",
        text: "Os treinos estão parecendo mais leves. Sinal de adaptação — hora de subir carga.",
        positive: true,
      });
    }
  }

  return out;
}

// ─────────────────────────────────────────────────────────────────────────────
// 6. CALENDÁRIO HEATMAP (últimos 12 semanas)
// ─────────────────────────────────────────────────────────────────────────────

export function buildHeatmap(history: PerformanceRow[], weeks = 12): Array<{
  date: string;
  count: number;
}> {
  const days = weeks * 7;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const map = new Map<string, number>();
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    map.set(d.toISOString().slice(0, 10), 0);
  }
  for (const r of history) {
    if (!r.recorded_at) continue;
    const key = new Date(r.recorded_at).toISOString().slice(0, 10);
    if (map.has(key)) map.set(key, (map.get(key) ?? 0) + 1);
  }
  return Array.from(map.entries()).map(([date, count]) => ({ date, count }));
}
