// Mapeamento de imagens por exercício (Unsplash) + fallback por grupo muscular.
// Usar URLs com largura limitada para performance (lazy loading + auto format).
import type { Exercise, FocoMuscular } from "./types";

const U = (id: string, w = 480) =>
  `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&q=70`;

// Por id de exercício (mais específico)
const BY_ID: Record<string, string> = {
  // peito
  "bench-press": U("photo-1517836357463-d25dfeac3438"),
  "incline-db": U("photo-1581009146145-b5ef050c2e1e"),
  dips: U("photo-1534438327276-14e5300c3a48"),
  "cable-fly": U("photo-1540497077202-7c8a3999166f"),
  pushup: U("photo-1571019613454-1cb2f99b2d8b"),
  // costas
  pullup: U("photo-1605296867304-46d5465a13f1"),
  "barbell-row": U("photo-1574680096145-d05b474e2155"),
  "lat-pulldown": U("photo-1583454110551-21f2fa2afe61"),
  "seated-row": U("photo-1517438476312-10d79c077509"),
  deadlift: U("photo-1652363722833-509b3aac287b"),
  // pernas
  squat: U("photo-1574680178050-55c6a6a96e0a"),
  "leg-press": U("photo-1434608519344-49d77a699e1d"),
  rdl: U("photo-1517344884509-a0c97ec11bcc"),
  lunge: U("photo-1434596922112-19c563067271"),
  "leg-curl": U("photo-1517836357463-d25dfeac3438"),
  "calf-raise": U("photo-1434596922112-19c563067271"),
  // ombros
  ohp: U("photo-1532029837206-abbe2b7620e3"),
  "lateral-raise": U("photo-1581009137042-c552e485697a"),
  "rear-delt": U("photo-1581009146145-b5ef050c2e1e"),
  "arnold-press": U("photo-1532029837206-abbe2b7620e3"),
  // braços
  "barbell-curl": U("photo-1581009146145-b5ef050c2e1e"),
  "hammer-curl": U("photo-1581009137042-c552e485697a"),
  "tricep-pushdown": U("photo-1518611012118-696072aa579a"),
  skullcrusher: U("photo-1583454110551-21f2fa2afe61"),
  // core
  plank: U("photo-1599058917212-d750089bc07e"),
  "hanging-leg": U("photo-1605296867304-46d5465a13f1"),
  "russian-twist": U("photo-1599058917212-d750089bc07e"),
  "ab-wheel": U("photo-1571019613454-1cb2f99b2d8b"),
  // fullbody / aquecimento / finisher
  burpee: U("photo-1599058917765-a780eda07a3e"),
  "kb-swing": U("photo-1517344884509-a0c97ec11bcc"),
  thruster: U("photo-1534438327276-14e5300c3a48"),
  "clean-press": U("photo-1652363722833-509b3aac287b"),
  "wu-jump-rope": U("photo-1599058917212-d750089bc07e"),
  "wu-jog": U("photo-1571008887538-b36bb32f4571"),
  "wu-arm-circles": U("photo-1518611012118-696072aa579a"),
  "wu-dynamic-stretch": U("photo-1518310383802-640c2de311b2"),
  "fin-mountain": U("photo-1599058917765-a780eda07a3e"),
  "fin-burpee": U("photo-1599058917765-a780eda07a3e"),
  "fin-jumping-jack": U("photo-1571008887538-b36bb32f4571"),
  "fin-plank": U("photo-1599058917212-d750089bc07e"),
};

// Fallback por grupo muscular
const BY_MUSCLE: Record<FocoMuscular | "warmup" | "finisher", string> = {
  peito: U("photo-1571019613454-1cb2f99b2d8b"),
  costas: U("photo-1605296867304-46d5465a13f1"),
  pernas: U("photo-1574680178050-55c6a6a96e0a"),
  ombros: U("photo-1532029837206-abbe2b7620e3"),
  bracos: U("photo-1581009146145-b5ef050c2e1e"),
  core: U("photo-1599058917212-d750089bc07e"),
  fullbody: U("photo-1517836357463-d25dfeac3438"),
  warmup: U("photo-1518310383802-640c2de311b2"),
  finisher: U("photo-1599058917765-a780eda07a3e"),
};

// Placeholder genérico (gradient SVG inline) — última camada de fallback
export const EXERCISE_PLACEHOLDER =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 240'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='%23222'/><stop offset='1' stop-color='%23444'/></linearGradient></defs><rect width='400' height='240' fill='url(%23g)'/><text x='50%' y='52%' font-family='sans-serif' font-size='18' fill='%23999' text-anchor='middle' font-weight='700'>BOSSFIT</text></svg>`,
  );

export function getExerciseImage(ex: Pick<Exercise, "id" | "muscle">): string {
  return BY_ID[ex.id] ?? BY_MUSCLE[ex.muscle] ?? EXERCISE_PLACEHOLDER;
}
