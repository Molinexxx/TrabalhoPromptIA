// Domain types for BOSSFIT AI

export type Objetivo = "hipertrofia" | "emagrecimento" | "forca" | "condicionamento";
export type Nivel = "iniciante" | "intermediario" | "avancado";
export type FocoMuscular =
  | "peito"
  | "costas"
  | "pernas"
  | "ombros"
  | "bracos"
  | "core"
  | "fullbody";

export type InjuryArea = "joelho" | "ombro" | "coluna" | "punho" | "tornozelo" | "cotovelo" | "quadril";

export type Biotipo = "ectomorfo" | "endomorfo" | "mesomorfo";

export interface Quiz {
  objetivo: Objetivo;
  objetivos?: Objetivo[]; // multi-seleção
  nivel: Nivel;
  frequencia: number; // 1..7
  focoMuscular: FocoMuscular;
  focosMusculares?: FocoMuscular[]; // multi-seleção
  biotipo?: Biotipo;
  peso: number; // kg
  altura: number; // cm
  injuries?: InjuryArea[];
}

export interface Progression {
  loadFactor: number;
  xp: number;
  level: number;
}

export interface Goals {
  workoutsPerWeek: number;
  targetWeight: number | null;
}

export interface Challenges {
  d7: { progress: number; completed: boolean };
  d30: { progress: number; completed: boolean };
}

export type ExerciseFeedback = "leve" | "medio" | "pesado" | "falha";

export interface Exercise {
  id: string;
  name: string;
  muscle: FocoMuscular | "warmup" | "finisher";
  sets: number;
  reps: number;
  rest: number; // seconds
  type?: "warmup" | "main" | "finisher";
  videoId?: string; // YouTube video ID for "Como fazer"
  setsCompleted?: number;
  done?: boolean;
  feedback?: ExerciseFeedback;
  estimatedKg?: number; // kg sugerido para a série
  weightUsed?: number; // kg realmente usado pelo usuário (input no focus)
  expectedSecondsPerSet?: number; // tempo esperado por série (para detecção adaptativa)
}

export interface ExerciseHistoryRow {
  id: string;
  user_id: string;
  exercise_id: string;
  exercise_name: string;
  weight_kg: number;
  reps: string | null;
  sets: number;
  feedback: ExerciseFeedback | null;
  recorded_at: string;
}

export interface DailyMission {
  id: string;
  label: string;
  done: boolean;
}

export interface DailyMissionsState {
  date: string | null; // YYYY-MM-DD
  items: DailyMission[];
}

export interface Workout {
  id: string;
  title: string;
  focus: string;
  estimatedMinutes: number;
  warmup: Exercise[];
  main: Exercise[];
  finisher: Exercise[];
  createdAt: string;
}

export type WeeklyPlanDay = {
  label: string;
  focus: FocoMuscular | "fullbody";
};

export interface WeeklyPlan {
  type: "PPL" | "FULLBODY";
  days: WeeklyPlanDay[];
}

export interface Profile {
  id: string;
  email: string | null;
  username: string | null;
  bio: string | null;
  avatar_url: string | null;
  quiz: Partial<Quiz>;
  quiz_completed: boolean;
  progression: Progression;
  daily_workout: Workout | Record<string, never>;
  weekly_plan: WeeklyPlan | Record<string, never>;
  goals: Goals;
  streak: number;
  last_workout_date: string | null;
  challenges: Challenges;
  ranking_score: number;
  favorites: string[]; // exercise ids
  daily_missions: DailyMissionsState;
  created_at: string;
  updated_at: string;
}
