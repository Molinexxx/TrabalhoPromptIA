import type { Profile } from "./types";

const RULES: Array<{ match: RegExp; respond: (p: Profile) => string }> = [
  {
    match: /(prote[ií]na|prot)/i,
    respond: (p) =>
      `Mire em ~1.6–2.0 g/kg de proteína. Para você: ${Math.round((p.quiz.peso ?? 70) * 1.8)}g/dia.`,
  },
  {
    match: /(\bagua\b|hidrat)/i,
    respond: () => `Beba 35 ml/kg de peso ao dia. Antes do treino, 500ml; durante, goles regulares.`,
  },
  {
    match: /(descanso|sono|dormir)/i,
    respond: () => `Sono é ganho. Mire 7–9h. Sem isso, hipertrofia e força travam.`,
  },
  {
    match: /(quanto|qual).*(peso|carga)/i,
    respond: () => `Use carga que falhe entre as últimas 2 reps. Subiu 2 reps acima da meta? Aumente.`,
  },
  {
    match: /(cardio|aer[oó]bic)/i,
    respond: (p) =>
      p.quiz.objetivo === "emagrecimento"
        ? `Some 3x/semana de cardio LISS 30min após a musculação.`
        : `1–2x cardio leve/semana basta para condicionamento sem prejudicar ganho.`,
  },
  {
    match: /(dor|machuc)/i,
    respond: () => `Dor aguda = pare. Desconforto muscular tardio (DOMS) é normal até 48h.`,
  },
  {
    match: /(motiva|desanim|preguic)/i,
    respond: (p) => `${p.streak > 0 ? `${p.streak} dias de streak` : "Hoje é o dia 1"}. Só comece — 5 min e segue.`,
  },
  {
    match: /(progress|evolu)/i,
    respond: (p) =>
      `Você está no nível ${p.progression?.level ?? 1} com ${p.progression?.xp ?? 0} XP. Mantém a regularidade.`,
  },
];

export function getSmartCoachResponse(question: string, profile: Profile): string {
  const trimmed = question.trim();
  if (!trimmed) return "Faz uma pergunta sobre treino, dieta ou recuperação.";
  for (const rule of RULES) {
    if (rule.match.test(trimmed)) return rule.respond(profile);
  }
  // Fallback contextual
  const obj = profile.quiz.objetivo ?? "hipertrofia";
  return `Foco em ${obj}: prioriza execução técnica e sobrecarga progressiva. Treino de hoje > treino perfeito.`;
}
