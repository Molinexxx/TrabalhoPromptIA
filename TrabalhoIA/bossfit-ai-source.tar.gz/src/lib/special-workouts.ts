import type { Exercise, Workout } from "./types";

export type SpecialWorkoutKind =
  | "cardio"
  | "alongamento"
  | "musculacao"
  | "casa"
  | "calistenia";

type Pre = Omit<Exercise, "setsCompleted" | "done">;

const CARDIO: Pre[] = [
  { id: "card-jog", name: "Corrida estacionária", muscle: "warmup", sets: 3, reps: 60, rest: 30, type: "main", videoId: "8opcQdC-V-U" },
  { id: "card-jumping-jack", name: "Polichinelos", muscle: "warmup", sets: 4, reps: 45, rest: 20, type: "main", videoId: "iSSAk4XCsRA" },
  { id: "card-jump-rope", name: "Pular corda", muscle: "warmup", sets: 5, reps: 60, rest: 30, type: "main", videoId: "1BZM2Vre5oc" },
  { id: "card-mountain", name: "Mountain climbers", muscle: "core", sets: 4, reps: 40, rest: 25, type: "main", videoId: "nmwgirgXLYM" },
  { id: "card-burpee", name: "Burpees", muscle: "fullbody", sets: 3, reps: 12, rest: 45, type: "main", videoId: "TU8QYVW0gDU" },
];

const ALONGAMENTO: Pre[] = [
  { id: "al-cat-cow", name: "Gato/camelo (coluna)", muscle: "core", sets: 2, reps: 45, rest: 15, type: "main", videoId: "kqnua4rHVVA" },
  { id: "al-childs", name: "Postura da criança", muscle: "core", sets: 2, reps: 45, rest: 15, type: "main", videoId: "2MJGg-dUKh0" },
  { id: "al-cobra", name: "Cobra (peito/coluna)", muscle: "peito", sets: 2, reps: 45, rest: 15, type: "main", videoId: "JDcdhTuycOI" },
  { id: "al-hamstring", name: "Alongamento posterior de coxa", muscle: "pernas", sets: 2, reps: 45, rest: 15, type: "main", videoId: "FDwpEdxZ_iw" },
  { id: "al-hip-flexor", name: "Alongamento de quadril", muscle: "pernas", sets: 2, reps: 45, rest: 15, type: "main", videoId: "YQmpO9VT2X4" },
  { id: "al-shoulder", name: "Alongamento de ombro", muscle: "ombros", sets: 2, reps: 30, rest: 10, type: "main", videoId: "5T3vKBJ4w8U" },
];

const CASA: Pre[] = [
  { id: "h-pushup", name: "Flexão de braço", muscle: "peito", sets: 4, reps: 12, rest: 60, type: "main", videoId: "IODxDxX7oi4" },
  { id: "h-squat", name: "Agachamento livre", muscle: "pernas", sets: 4, reps: 15, rest: 60, type: "main", videoId: "aclHkVaku9U" },
  { id: "h-lunge", name: "Avanço (afundo)", muscle: "pernas", sets: 3, reps: 12, rest: 45, type: "main", videoId: "QOVaHwm-Q6U" },
  { id: "h-plank", name: "Prancha isométrica", muscle: "core", sets: 3, reps: 40, rest: 30, type: "main", videoId: "ASdvN_XEl_c" },
  { id: "h-glute-bridge", name: "Ponte de glúteo", muscle: "pernas", sets: 3, reps: 15, rest: 45, type: "main", videoId: "wPM8icPu6H8" },
  { id: "h-superman", name: "Superman (lombar)", muscle: "costas", sets: 3, reps: 15, rest: 30, type: "main", videoId: "z6PJMT2y8GQ" },
];

const CALISTENIA: Pre[] = [
  { id: "ca-pullup", name: "Barra fixa", muscle: "costas", sets: 5, reps: 6, rest: 90, type: "main", videoId: "eGo4IYlbE5g" },
  { id: "ca-dips", name: "Mergulho em paralelas", muscle: "peito", sets: 4, reps: 8, rest: 75, type: "main", videoId: "wjUmnZH528Y" },
  { id: "ca-pushup", name: "Flexão", muscle: "peito", sets: 4, reps: 15, rest: 60, type: "main", videoId: "IODxDxX7oi4" },
  { id: "ca-pistol", name: "Agachamento pistol (assistido)", muscle: "pernas", sets: 3, reps: 8, rest: 75, type: "main", videoId: "vq5-vdgJc0I" },
  { id: "ca-l-sit", name: "L-sit", muscle: "core", sets: 4, reps: 15, rest: 60, type: "main", videoId: "IucpRyEnxgQ" },
  { id: "ca-australian-row", name: "Remada australiana", muscle: "costas", sets: 4, reps: 12, rest: 60, type: "main", videoId: "BUk8XnfL_HE" },
];

const MUSC: Pre[] = [
  { id: "m-bench", name: "Supino reto com barra", muscle: "peito", sets: 4, reps: 10, rest: 75, type: "main", videoId: "rT7DgCr-3pg" },
  { id: "m-row", name: "Remada curvada", muscle: "costas", sets: 4, reps: 10, rest: 75, type: "main", videoId: "kBWAon7ItDw" },
  { id: "m-squat", name: "Agachamento livre", muscle: "pernas", sets: 4, reps: 10, rest: 90, type: "main", videoId: "ultWZbUMPL8" },
  { id: "m-ohp", name: "Desenvolvimento militar", muscle: "ombros", sets: 4, reps: 10, rest: 75, type: "main", videoId: "2yjwXTZQDDI" },
  { id: "m-curl", name: "Rosca direta", muscle: "bracos", sets: 3, reps: 12, rest: 60, type: "main", videoId: "kwG2ipFRgfo" },
  { id: "m-tri", name: "Tríceps na polia", muscle: "bracos", sets: 3, reps: 12, rest: 60, type: "main", videoId: "2-LAMcpzODU" },
];

const KIND_LABEL: Record<SpecialWorkoutKind, string> = {
  cardio: "Cardio livre",
  alongamento: "Alongamento total",
  musculacao: "Musculação",
  casa: "Treino em casa",
  calistenia: "Calistenia",
};

const POOLS: Record<SpecialWorkoutKind, Pre[]> = {
  cardio: CARDIO,
  alongamento: ALONGAMENTO,
  musculacao: MUSC,
  casa: CASA,
  calistenia: CALISTENIA,
};

export function generateSpecialWorkout(kind: SpecialWorkoutKind): Workout {
  const pool = POOLS[kind];
  const main: Exercise[] = pool.map((p) => ({ ...p, setsCompleted: 0, done: false }));
  const totalSets = main.reduce((s, e) => s + e.sets, 0);
  const estimatedMinutes = Math.max(15, Math.round(totalSets * 1.4));
  return {
    id: crypto.randomUUID(),
    title: `Treino de ${KIND_LABEL[kind]}`,
    focus: KIND_LABEL[kind],
    estimatedMinutes,
    warmup: [],
    main,
    finisher: [],
    createdAt: new Date().toISOString(),
  };
}

export const SPECIAL_KINDS: Array<{ kind: SpecialWorkoutKind; label: string; desc: string; emoji: string }> = [
  { kind: "cardio", label: "Cardio livre", desc: "Queima calorias, eleva o cardio", emoji: "🏃" },
  { kind: "alongamento", label: "Alongamento total", desc: "Mobilidade e recuperação", emoji: "🧘" },
  { kind: "musculacao", label: "Musculação", desc: "Treino tradicional na academia", emoji: "🏋️" },
  { kind: "casa", label: "Treino em casa", desc: "Sem equipamentos, em qualquer lugar", emoji: "🏠" },
  { kind: "calistenia", label: "Calistenia", desc: "Peso corporal, controle e força", emoji: "🤸" },
];
