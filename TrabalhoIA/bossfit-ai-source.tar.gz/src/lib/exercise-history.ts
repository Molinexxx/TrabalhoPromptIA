// Histórico de carga real por exercício (kg utilizado, evolução, sugestão).
import { supabase } from "@/integrations/supabase/client";
import type { ExerciseFeedback, ExerciseHistoryRow } from "./types";

export interface ExerciseHistoryEntry {
  exerciseId: string;
  exerciseName: string;
  weightKg: number;
  reps: string;
  sets: number;
  feedback?: ExerciseFeedback;
}

/**
 * Persiste um lote de registros de carga ao finalizar o treino.
 * Filtra exercícios sem peso informado (>0) ou sem séries.
 */
export async function saveExerciseHistory(
  userId: string,
  entries: ExerciseHistoryEntry[],
): Promise<void> {
  const rows = entries
    .filter((e) => e.weightKg > 0 && e.sets > 0)
    .map((e) => ({
      user_id: userId,
      exercise_id: e.exerciseId,
      exercise_name: e.exerciseName,
      weight_kg: e.weightKg,
      reps: e.reps,
      sets: e.sets,
      feedback: e.feedback ?? null,
    }));
  if (rows.length === 0) return;
  const { error } = await supabase.from("exercise_history").insert(rows as never);
  if (error) throw error;
}

/**
 * Busca a última carga registrada para um exercício do usuário.
 */
export async function getLastWeight(
  userId: string,
  exerciseId: string,
): Promise<ExerciseHistoryRow | null> {
  const { data, error } = await supabase
    .from("exercise_history")
    .select("*")
    .eq("user_id", userId)
    .eq("exercise_id", exerciseId)
    .order("recorded_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (error) return null;
  return (data as unknown as ExerciseHistoryRow) ?? null;
}

/**
 * Busca todos os registros recentes do usuário (limite alto, para mapas locais).
 */
export async function fetchExerciseHistory(
  userId: string,
  limit = 500,
): Promise<ExerciseHistoryRow[]> {
  const { data, error } = await supabase
    .from("exercise_history")
    .select("*")
    .eq("user_id", userId)
    .order("recorded_at", { ascending: false })
    .limit(limit);
  if (error) throw error;
  return (data ?? []) as unknown as ExerciseHistoryRow[];
}

/**
 * Sugere a próxima carga com base no último peso + feedback:
 *   leve   → +5%
 *   medio  → manter
 *   pesado → -5%
 * Arredonda para múltiplos de 0.5kg para halteres / 2.5kg para barra.
 */
export function suggestNextWeight(last: ExerciseHistoryRow | null): {
  weight: number;
  delta: number;
  reason: string;
} {
  if (!last || last.weight_kg <= 0) {
    return { weight: 0, delta: 0, reason: "Sem histórico — defina sua carga inicial." };
  }
  const fb = last.feedback;
  let factor = 1;
  let reason = "Mantenha a carga: o ritmo está bom.";
  if (fb === "leve") {
    factor = 1.05;
    reason = "Treino estava fácil — bora subir 5%.";
  } else if (fb === "pesado") {
    factor = 0.95;
    reason = "Pesado demais — reduz 5% pra técnica.";
  } else if (fb === "falha") {
    factor = 0.9;
    reason = "Você falhou nas séries — reduz 10% pra recuperar a execução.";
  }
  let next = last.weight_kg * factor;
  // arredondamento esperto
  if (next >= 20) next = Math.round(next / 2.5) * 2.5;
  else next = Math.round(next * 2) / 2;
  const delta = Math.round((next - last.weight_kg) * 10) / 10;
  return { weight: next, delta, reason };
}

/**
 * Agrupa histórico por exercício e ordena por data (asc) — pronto para gráfico.
 */
export function groupHistoryByExercise(
  rows: ExerciseHistoryRow[],
): Array<{ exerciseId: string; exerciseName: string; points: ExerciseHistoryRow[] }> {
  const map = new Map<string, ExerciseHistoryRow[]>();
  for (const r of rows) {
    const key = r.exercise_id;
    if (!map.has(key)) map.set(key, []);
    map.get(key)!.push(r);
  }
  return Array.from(map.entries())
    .map(([exerciseId, points]) => ({
      exerciseId,
      exerciseName: points[0]?.exercise_name ?? exerciseId,
      points: [...points].sort((a, b) => a.recorded_at.localeCompare(b.recorded_at)),
    }))
    .filter((g) => g.points.length >= 1)
    .sort((a, b) => b.points.length - a.points.length);
}

/**
 * Insights de progressão de carga (ex.: "+5kg no supino").
 */
export function detectLoadProgress(
  rows: ExerciseHistoryRow[],
): Array<{ exerciseName: string; delta: number; from: number; to: number }> {
  const groups = groupHistoryByExercise(rows);
  const out: Array<{ exerciseName: string; delta: number; from: number; to: number }> = [];
  for (const g of groups) {
    if (g.points.length < 2) continue;
    const first = g.points[0].weight_kg;
    const last = g.points[g.points.length - 1].weight_kg;
    const delta = Math.round((last - first) * 10) / 10;
    if (Math.abs(delta) >= 1) {
      out.push({ exerciseName: g.exerciseName, delta, from: first, to: last });
    }
  }
  return out.sort((a, b) => Math.abs(b.delta) - Math.abs(a.delta)).slice(0, 5);
}

/**
 * Resumo por exercício: contagem de feedback (leve/médio/pesado/falha),
 * carga atual (último), máxima e total de sessões.
 */
export interface ExerciseSummary {
  exerciseId: string;
  exerciseName: string;
  sessions: number;
  lastKg: number;
  maxKg: number;
  leve: number;
  medio: number;
  pesado: number;
  falha: number;
}

export function summarizeExerciseHistory(rows: ExerciseHistoryRow[]): ExerciseSummary[] {
  const groups = groupHistoryByExercise(rows);
  return groups.map((g) => {
    const last = g.points[g.points.length - 1];
    const maxKg = g.points.reduce((m, p) => Math.max(m, Number(p.weight_kg)), 0);
    let leve = 0,
      medio = 0,
      pesado = 0,
      falha = 0;
    for (const p of g.points) {
      if (p.feedback === "leve") leve++;
      else if (p.feedback === "medio") medio++;
      else if (p.feedback === "pesado") pesado++;
      else if (p.feedback === "falha") falha++;
    }
    return {
      exerciseId: g.exerciseId,
      exerciseName: g.exerciseName,
      sessions: g.points.length,
      lastKg: Number(last?.weight_kg ?? 0),
      maxKg,
      leve,
      medio,
      pesado,
      falha,
    };
  });
}
