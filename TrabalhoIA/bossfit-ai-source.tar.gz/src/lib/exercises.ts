import type { Exercise, FocoMuscular } from "./types";

type ExerciseDef = Omit<Exercise, "sets" | "reps" | "rest" | "setsCompleted" | "done">;

// videoId = YouTube video ID. Curated demos in Portuguese/English (technique-focused).
export const EXERCISE_LIBRARY: Record<FocoMuscular, ExerciseDef[]> = {
  peito: [
    { id: "bench-press", name: "Supino reto com barra", muscle: "peito", videoId: "rT7DgCr-3pg" },
    { id: "incline-db", name: "Supino inclinado com halteres", muscle: "peito", videoId: "8iPEnn-ltC8" },
    { id: "dips", name: "Mergulho em paralelas", muscle: "peito", videoId: "wjUmnZH528Y" },
    { id: "cable-fly", name: "Crossover no cabo", muscle: "peito", videoId: "taI4XduLpTk" },
    { id: "pushup", name: "Flexão de braço", muscle: "peito", videoId: "IODxDxX7oi4" },
  ],
  costas: [
    { id: "pullup", name: "Barra fixa", muscle: "costas", videoId: "eGo4IYlbE5g" },
    { id: "barbell-row", name: "Remada curvada", muscle: "costas", videoId: "kBWAon7ItDw" },
    { id: "lat-pulldown", name: "Puxada na polia alta", muscle: "costas", videoId: "CAwf7n6Luuc" },
    { id: "seated-row", name: "Remada sentada", muscle: "costas", videoId: "GZbfZ033f74" },
    { id: "deadlift", name: "Levantamento terra", muscle: "costas", videoId: "op9kVnSso6Q" },
  ],
  pernas: [
    { id: "squat", name: "Agachamento livre", muscle: "pernas", videoId: "ultWZbUMPL8" },
    { id: "leg-press", name: "Leg press 45°", muscle: "pernas", videoId: "IZxyjW7MPJQ" },
    { id: "rdl", name: "Stiff", muscle: "pernas", videoId: "jEy_czb3RKA" },
    { id: "lunge", name: "Avanço com halteres", muscle: "pernas", videoId: "QOVaHwm-Q6U" },
    { id: "leg-curl", name: "Mesa flexora", muscle: "pernas", videoId: "1Tq3QdYUuHs" },
    { id: "calf-raise", name: "Panturrilha em pé", muscle: "pernas", videoId: "gwLzBJYoWlI" },
  ],
  ombros: [
    { id: "ohp", name: "Desenvolvimento militar", muscle: "ombros", videoId: "2yjwXTZQDDI" },
    { id: "lateral-raise", name: "Elevação lateral", muscle: "ombros", videoId: "3VcKaXpzqRo" },
    { id: "rear-delt", name: "Crucifixo invertido", muscle: "ombros", videoId: "EA7u4Q_8HQ0" },
    { id: "arnold-press", name: "Arnold press", muscle: "ombros", videoId: "3ml7BH7mNwQ" },
  ],
  bracos: [
    { id: "barbell-curl", name: "Rosca direta", muscle: "bracos", videoId: "kwG2ipFRgfo" },
    { id: "hammer-curl", name: "Rosca martelo", muscle: "bracos", videoId: "zC3nLlEvin4" },
    { id: "tricep-pushdown", name: "Tríceps na polia", muscle: "bracos", videoId: "2-LAMcpzODU" },
    { id: "skullcrusher", name: "Tríceps testa", muscle: "bracos", videoId: "d_KZxkY_0cM" },
  ],
  core: [
    { id: "plank", name: "Prancha isométrica", muscle: "core", videoId: "ASdvN_XEl_c" },
    { id: "hanging-leg", name: "Elevação de pernas", muscle: "core", videoId: "Pr1ieGZ5atk" },
    { id: "russian-twist", name: "Russian twist", muscle: "core", videoId: "wkD8rjkodUI" },
    { id: "ab-wheel", name: "Roda abdominal", muscle: "core", videoId: "rqiTPdK1c_I" },
  ],
  fullbody: [
    { id: "burpee", name: "Burpee", muscle: "fullbody", videoId: "TU8QYVW0gDU" },
    { id: "kb-swing", name: "Kettlebell swing", muscle: "fullbody", videoId: "YSxHifyI6s8" },
    { id: "thruster", name: "Thruster", muscle: "fullbody", videoId: "L219ltL15zk" },
    { id: "clean-press", name: "Clean and press", muscle: "fullbody", videoId: "Sl2ulr-fbbI" },
  ],
};

export const WARMUP_POOL: ExerciseDef[] = [
  { id: "wu-jump-rope", name: "Pular corda", muscle: "warmup", type: "warmup", videoId: "1BZM2Vre5oc" },
  { id: "wu-jog", name: "Corrida estacionária", muscle: "warmup", type: "warmup", videoId: "8opcQdC-V-U" },
  { id: "wu-arm-circles", name: "Circundução de braços", muscle: "warmup", type: "warmup", videoId: "140RTNMciH8" },
  { id: "wu-dynamic-stretch", name: "Alongamento dinâmico", muscle: "warmup", type: "warmup", videoId: "nPHfEnZD1Wk" },
];

export const FINISHER_POOL: ExerciseDef[] = [
  { id: "fin-mountain", name: "Mountain climbers", muscle: "finisher", type: "finisher", videoId: "nmwgirgXLYM" },
  { id: "fin-burpee", name: "Burpees AMRAP", muscle: "finisher", type: "finisher", videoId: "TU8QYVW0gDU" },
  { id: "fin-jumping-jack", name: "Polichinelos", muscle: "finisher", type: "finisher", videoId: "iSSAk4XCsRA" },
  { id: "fin-plank", name: "Prancha máxima", muscle: "finisher", type: "finisher", videoId: "ASdvN_XEl_c" },
];
