// Light recovery (mobility/stretching) and basic nutrition suggestions.
// IMPORTANT: General wellness guidance only — not medical advice.
import type { InjuryArea, Objetivo } from "@/lib/types";

export const WELLNESS_DISCLAIMER =
  "Essas são sugestões gerais de bem-estar, não orientação médica. Em caso de dor intensa, persistente ou inchaço, procure um profissional de saúde.";

export interface RecoveryItem {
  name: string;
  description: string;
  duration: string;
  videoId?: string; // YouTube ID
}

export interface RecoveryProtocol {
  area: InjuryArea;
  label: string;
  emoji: string;
  warning: string;
  items: RecoveryItem[];
}

const PROTOCOLS: Record<InjuryArea, RecoveryProtocol> = {
  joelho: {
    area: "joelho",
    label: "Joelho",
    emoji: "🦵",
    warning: "Evite agachamentos profundos com carga e impacto se sentir dor.",
    items: [
      {
        name: "Alongamento de quadríceps em pé",
        description: "Em pé, segure o tornozelo levando o calcanhar ao glúteo. Mantenha sem dor.",
        duration: "2× 30s cada lado",
        videoId: "MO6XBZ9d2gE",
      },
      {
        name: "Mobilidade leve de joelho (sentado)",
        description: "Sentado, estenda e flexione o joelho lentamente em amplitude confortável.",
        duration: "2× 12 reps cada lado",
      },
      {
        name: "Caminhada leve",
        description: "Ritmo confortável, terreno plano. Ajuda na circulação e recuperação ativa.",
        duration: "10–20 min",
      },
      {
        name: "Ativação de glúteo (ponte)",
        description: "Deitado, eleve o quadril contraindo o glúteo. Reduz sobrecarga no joelho.",
        duration: "2× 12 reps",
      },
    ],
  },
  ombro: {
    area: "ombro",
    label: "Ombro",
    emoji: "💪",
    warning: "Evite cargas acima da cabeça e impacto direto até a região estabilizar.",
    items: [
      {
        name: "Rotação externa leve com elástico",
        description: "Cotovelo colado ao corpo, gire o antebraço pra fora com mini-band leve.",
        duration: "2× 15 reps cada lado",
        videoId: "Aaq2v9HTmW8",
      },
      {
        name: "Mobilidade de ombro (círculos)",
        description: "Braços estendidos, faça círculos pequenos, depois maiores, sem dor.",
        duration: "2× 10 cada direção",
      },
      {
        name: "Alongamento de peitoral na parede",
        description: "Apoie o antebraço na parede e gire o tronco devagar pro lado oposto.",
        duration: "2× 30s cada lado",
      },
    ],
  },
  coluna: {
    area: "coluna",
    label: "Coluna",
    emoji: "🧘",
    warning: "Evite cargas axiais pesadas e flexão lombar com peso até melhorar.",
    items: [
      {
        name: "Alongamento lombar (joelhos ao peito)",
        description: "Deitado, abrace os joelhos relaxando a lombar contra o solo.",
        duration: "3× 30s",
      },
      {
        name: "Mobilidade de coluna (cat-cow)",
        description: "Em quatro apoios, alterne arquear e arredondar a coluna lentamente.",
        duration: "2× 10 reps",
        videoId: "kqnua4rHVVA",
      },
      {
        name: "Core leve (dead bug)",
        description: "Deitado de costas, alterne braço e perna opostos sem perder o contato lombar.",
        duration: "2× 10 reps",
      },
    ],
  },
  punho: {
    area: "punho",
    label: "Punho",
    emoji: "✋",
    warning: "Evite supino pesado e flexões diretas até a mobilidade voltar sem dor.",
    items: [
      {
        name: "Mobilidade de punho (círculos)",
        description: "Mãos entrelaçadas, faça círculos lentos pra ambos os lados.",
        duration: "2× 10 cada direção",
      },
      {
        name: "Alongamento de flexores",
        description: "Braço estendido, palma pra cima, puxe os dedos pra baixo com a outra mão.",
        duration: "2× 30s cada lado",
      },
    ],
  },
  tornozelo: {
    area: "tornozelo",
    label: "Tornozelo",
    emoji: "🦶",
    warning: "Evite saltos e mudanças bruscas de direção até estabilizar.",
    items: [
      {
        name: "Mobilidade de tornozelo (círculos)",
        description: "Sentado, faça círculos lentos com o pé, em amplitude confortável.",
        duration: "2× 10 cada direção",
      },
      {
        name: "Alongamento de panturrilha na parede",
        description: "Pé atrás esticado, calcanhar no chão, projete o quadril à frente.",
        duration: "2× 30s cada lado",
      },
    ],
  },
  cotovelo: {
    area: "cotovelo",
    label: "Cotovelo",
    emoji: "💢",
    warning: "Evite pegada pronada com carga e movimentos repetitivos enquanto doer.",
    items: [
      {
        name: "Alongamento de extensores (epicôndilo)",
        description: "Braço estendido, palma pra baixo, puxe os dedos pra trás suavemente.",
        duration: "2× 30s cada lado",
      },
      {
        name: "Mobilidade leve de cotovelo",
        description: "Flexione e estenda o cotovelo lentamente em amplitude livre de dor.",
        duration: "2× 12 reps",
      },
    ],
  },
  quadril: {
    area: "quadril",
    label: "Quadril",
    emoji: "🕺",
    warning: "Evite agachamentos e levantamentos pesados até liberar mobilidade.",
    items: [
      {
        name: "Alongamento 90/90",
        description: "Sentado com pernas em ângulo reto, alterne lados focando na rotação do quadril.",
        duration: "2× 30s cada lado",
      },
      {
        name: "Mobilidade de quadril (world's greatest stretch)",
        description: "Avanço, mão dentro do pé da frente, gire o tronco para o teto.",
        duration: "2× 5 reps cada lado",
      },
    ],
  },
};

export function getRecoveryProtocols(injuries: InjuryArea[] | undefined): RecoveryProtocol[] {
  if (!injuries || injuries.length === 0) return [];
  return injuries.map((i) => PROTOCOLS[i]).filter(Boolean);
}

export interface NutritionPlan {
  objetivo: Objetivo;
  title: string;
  emoji: string;
  principles: string[];
  examples: string[];
  postWorkoutTip: string;
  hydration: string;
}

const NUTRITION: Record<Objetivo, NutritionPlan> = {
  hipertrofia: {
    objetivo: "hipertrofia",
    title: "Foco em construção muscular",
    emoji: "🍗",
    principles: [
      "Priorize uma fonte de proteína em todas as refeições.",
      "Distribua refeições a cada 3–4 horas.",
      "Inclua carboidratos antes e depois do treino.",
    ],
    examples: ["Ovos", "Frango", "Arroz", "Banana", "Iogurte natural", "Aveia"],
    postWorkoutTip: "Priorize proteínas hoje para recuperação muscular.",
    hydration: "Cerca de 35 ml por kg de peso corporal ao longo do dia.",
  },
  emagrecimento: {
    objetivo: "emagrecimento",
    title: "Leve déficit calórico sustentável",
    emoji: "🥗",
    principles: [
      "Monte pratos com bastante volume vegetal.",
      "Evite ultraprocessados e bebidas açucaradas.",
      "Inclua proteína em toda refeição pra manter saciedade.",
    ],
    examples: ["Salada colorida", "Proteína magra", "Frutas", "Legumes", "Grão-de-bico"],
    postWorkoutTip: "Hoje uma refeição leve, com proteína e vegetais, cai bem.",
    hydration: "Hidratação consistente ajuda a controlar fome e desempenho.",
  },
  forca: {
    objetivo: "forca",
    title: "Energia para puxar mais peso",
    emoji: "🥩",
    principles: [
      "Boa ingestão de proteína (carnes, ovos, laticínios).",
      "Carboidratos suficientes para sustentar treinos pesados.",
      "Não treine em jejum prolongado quando for puxar carga máxima.",
    ],
    examples: ["Carne vermelha magra", "Batata-doce", "Arroz", "Whey", "Castanhas"],
    postWorkoutTip: "Reponha carboidrato + proteína na refeição pós-treino.",
    hydration: "Beba água ao longo do dia, especialmente entre séries pesadas.",
  },
  condicionamento: {
    objetivo: "condicionamento",
    title: "Equilíbrio para resistência",
    emoji: "🍌",
    principles: [
      "Equilibre carboidratos e proteínas em cada refeição.",
      "Inclua frutas e cereais integrais para energia constante.",
      "Mantenha boa hidratação durante o treino.",
    ],
    examples: ["Aveia", "Frutas", "Arroz integral", "Frango", "Tapioca", "Ovos"],
    postWorkoutTip: "Reponha líquidos e inclua carboidrato + proteína.",
    hydration: "Beba antes, durante e após o treino — especialmente em sessões longas.",
  },
};

export function getNutritionPlan(objetivo: Objetivo | undefined): NutritionPlan | null {
  if (!objetivo) return null;
  return NUTRITION[objetivo] ?? null;
}

export function getPostWorkoutTips(
  objetivo: Objetivo | undefined,
  injuries: InjuryArea[] | undefined,
): string[] {
  const tips: string[] = [];
  const plan = getNutritionPlan(objetivo);
  if (plan) tips.push(plan.postWorkoutTip);
  tips.push("Mantenha boa hidratação nas próximas horas.");
  if (injuries && injuries.length > 0) {
    tips.push(
      `Evite sobrecarga na região afetada (${injuries.join(", ")}). Faça mobilidade leve.`,
    );
  } else {
    tips.push("Inclua 5–10 min de alongamento leve para acelerar a recuperação.");
  }
  return tips;
}

export const ALL_INJURIES: InjuryArea[] = [
  "joelho",
  "ombro",
  "coluna",
  "punho",
  "tornozelo",
  "cotovelo",
  "quadril",
];
