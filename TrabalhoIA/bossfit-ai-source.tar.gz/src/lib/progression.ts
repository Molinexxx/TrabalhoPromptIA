// Wave 2: adaptive progression + fatigue/deload engine
import type { ExerciseFeedback, Profile } from "./types";

export interface PerformanceRow {
  recorded_at: string | null;
  difficulty: number | null;
  completion_rate: number | null;
  time_spent: number | null;
  sets_completed_total: number | null;
  overall_rating: number | null;
  exercise_feedback: Array<{ name: string; section?: string; feedback: ExerciseFeedback }> | null;
}

/**
 * Suggested load multiplier for an exercise (relative to baseline).
 * Combines profile.loadFactor with the exercise's recent feedback history.
 */
export function suggestedLoadForExercise(
  exerciseName: string,
  baseLoad: number,
  history: PerformanceRow[],
): { load: number; trend: "up" | "down" | "flat"; samples: number } {
  const fbs: ExerciseFeedback[] = [];
  for (const row of history) {
    const arr = row.exercise_feedback ?? [];
    for (const ef of arr) {
      if (ef?.name === exerciseName && ef.feedback) fbs.push(ef.feedback);
    }
  }
  if (fbs.length === 0) return { load: baseLoad, trend: "flat", samples: 0 };
  const recent = fbs.slice(0, 4); // most recent first
  const leves = recent.filter((f) => f === "leve").length;
  const pesados = recent.filter((f) => f === "pesado").length;
  const score = (leves - pesados) / recent.length; // -1..1
  const delta = score * 0.05; // up to ±5%
  const load = Math.max(0.7, Math.min(1.6, baseLoad + delta));
  const trend = delta > 0.01 ? "up" : delta < -0.01 ? "down" : "flat";
  return { load, trend, samples: recent.length };
}

/**
 * Detect overtraining / fatigue based on the last N sessions.
 * Triggers a deload suggestion when:
 *  - 3+ consecutive sessions with difficulty>=4 OR overall_rating<=2
 *  - OR average completion < 0.65 over last 3
 */
export interface FatigueState {
  level: "ok" | "watch" | "deload";
  reason: string;
  recommendation: string;
}

export function evaluateFatigue(history: PerformanceRow[]): FatigueState {
  const last = history.slice(0, 5);
  if (last.length < 3) {
    return {
      level: "ok",
      reason: "Sem histórico suficiente",
      recommendation: "Continue treinando consistente — ainda vou aprender seu padrão.",
    };
  }
  const last3 = last.slice(0, 3);
  const hardCount = last3.filter(
    (r) => (r.difficulty ?? 0) >= 4 || ((r.overall_rating ?? 0) > 0 && (r.overall_rating ?? 0) <= 2),
  ).length;
  const avgComp = last3.reduce((s, r) => s + (r.completion_rate ?? 0), 0) / last3.length;

  if (hardCount >= 3) {
    return {
      level: "deload",
      reason: "3 treinos seguidos pesados ou com baixa energia",
      recommendation:
        "Semana de deload: reduza cargas em 20% e priorize técnica. Volta com tudo na próxima.",
    };
  }
  if (avgComp < 0.65) {
    return {
      level: "deload",
      reason: `Conclusão média baixa (${Math.round(avgComp * 100)}%)`,
      recommendation: "Reduza volume em 1 série por exercício até voltar a fechar 80%+.",
    };
  }
  if (hardCount >= 2 || avgComp < 0.78) {
    return {
      level: "watch",
      reason: "Sinais de cansaço acumulado",
      recommendation: "Capriche no sono e na proteína. Se não melhorar, segura a carga.",
    };
  }
  return {
    level: "ok",
    reason: "Performance consistente",
    recommendation: "Pode subir carga gradualmente. Tá no ritmo certo.",
  };
}

/**
 * Aggregate weekly stats for the dashboard.
 */
export interface WeeklyStat {
  weekLabel: string; // e.g. "Sem 12"
  weekStart: string;
  sessions: number;
  avgCompletion: number;
  avgDifficulty: number;
  totalMinutes: number;
}

function startOfWeek(d: Date): Date {
  const x = new Date(d);
  const day = x.getDay(); // 0 sun..6 sat
  const diff = (day + 6) % 7; // make monday = 0
  x.setDate(x.getDate() - diff);
  x.setHours(0, 0, 0, 0);
  return x;
}

function isoWeek(d: Date): number {
  const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const dayNum = date.getUTCDay() || 7;
  date.setUTCDate(date.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  return Math.ceil(((date.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
}

export function aggregateWeekly(history: PerformanceRow[], weeks = 8): WeeklyStat[] {
  const now = new Date();
  const buckets = new Map<string, PerformanceRow[]>();
  for (let i = 0; i < weeks; i++) {
    const d = new Date(now);
    d.setDate(d.getDate() - i * 7);
    const ws = startOfWeek(d);
    buckets.set(ws.toISOString().slice(0, 10), []);
  }
  for (const row of history) {
    if (!row.recorded_at) continue;
    const ws = startOfWeek(new Date(row.recorded_at)).toISOString().slice(0, 10);
    if (buckets.has(ws)) buckets.get(ws)!.push(row);
  }
  const stats: WeeklyStat[] = [];
  for (const [weekStart, rows] of buckets) {
    const sessions = rows.length;
    const avgCompletion = sessions
      ? rows.reduce((s, r) => s + (r.completion_rate ?? 0), 0) / sessions
      : 0;
    const avgDifficulty = sessions
      ? rows.reduce((s, r) => s + (r.difficulty ?? 0), 0) / sessions
      : 0;
    const totalMinutes = rows.reduce((s, r) => s + Math.round((r.time_spent ?? 0) / 60), 0);
    const w = isoWeek(new Date(weekStart));
    stats.push({
      weekLabel: `S${w}`,
      weekStart,
      sessions,
      avgCompletion,
      avgDifficulty,
      totalMinutes,
    });
  }
  return stats.sort((a, b) => a.weekStart.localeCompare(b.weekStart));
}

export function loadFactorTrend(history: PerformanceRow[]): Array<{ idx: number; load: number; date: string }> {
  // Reconstruct an approximate load progression from completion + difficulty deltas
  const ordered = [...history].reverse(); // oldest first
  let load = 1.0;
  const points: Array<{ idx: number; load: number; date: string }> = [];
  ordered.forEach((r, i) => {
    const comp = r.completion_rate ?? 0;
    const diff = r.difficulty ?? 0;
    let delta = 0;
    if (comp >= 0.9 && diff <= 3) delta = 0.03;
    else if (comp < 0.6 || diff >= 5) delta = -0.025;
    else if (comp >= 0.8) delta = 0.015;
    load = Math.max(0.7, Math.min(1.6, load + delta));
    points.push({
      idx: i + 1,
      load: Math.round(load * 100) / 100,
      date: (r.recorded_at ?? "").slice(0, 10),
    });
  });
  return points;
}

export function profileLoadFactor(profile: Pick<Profile, "progression"> | null | undefined): number {
  return profile?.progression?.loadFactor ?? 1.0;
}
