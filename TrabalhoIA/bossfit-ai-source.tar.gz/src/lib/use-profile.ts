import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Profile } from "./types";
import { useAuth } from "./auth";

export function useProfile() {
  const { user } = useAuth();
  return useQuery({
    queryKey: ["profile", user?.id],
    enabled: !!user?.id,
    queryFn: async (): Promise<Profile | null> => {
      if (!user?.id) return null;
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .maybeSingle();
      if (error) throw error;
      return data as unknown as Profile | null;
    },
  });
}

export function useUpdateProfile() {
  const { user } = useAuth();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (patch: Partial<Profile>) => {
      if (!user?.id) throw new Error("Sem usuário autenticado");
      const { error, data } = await supabase
        .from("profiles")
        .update(patch as never)
        .eq("id", user.id)
        .select("*")
        .single();
      if (error) throw error;
      return data as unknown as Profile;
    },
    onSuccess: (data) => {
      qc.setQueryData(["profile", user?.id], data);
    },
  });
}
