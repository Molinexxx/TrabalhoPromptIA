import { useState } from "react";
import { EXERCISE_PLACEHOLDER, getExerciseImage } from "@/lib/exercise-images";
import type { Exercise } from "@/lib/types";

interface Props {
  exercise: Pick<Exercise, "id" | "muscle" | "name">;
  className?: string;
  aspect?: "video" | "square" | "wide";
  eager?: boolean;
}

/**
 * Imagem do exercício com fallback automático para placeholder.
 * Usa lazy loading e async decoding para não travar a UI.
 */
export function ExerciseImage({ exercise, className = "", aspect = "video", eager }: Props) {
  const [src, setSrc] = useState(() => getExerciseImage(exercise));
  const aspectClass =
    aspect === "square" ? "aspect-square" : aspect === "wide" ? "aspect-[16/7]" : "aspect-video";

  return (
    <div
      className={`relative overflow-hidden rounded-xl bg-muted ${aspectClass} ${className}`}
    >
      <img
        src={src}
        alt={exercise.name}
        loading={eager ? "eager" : "lazy"}
        decoding="async"
        onError={() => setSrc(EXERCISE_PLACEHOLDER)}
        className="absolute inset-0 h-full w-full object-cover transition-opacity duration-300"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-background/70 via-transparent to-transparent pointer-events-none" />
    </div>
  );
}
