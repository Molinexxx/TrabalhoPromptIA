import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface VideoModalProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  videoId: string | null;
  title: string;
}

export function VideoModal({ open, onOpenChange, videoId, title }: VideoModalProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl p-0 overflow-hidden bg-background border-border">
        <DialogHeader className="px-5 pt-4 pb-3">
          <DialogTitle className="text-base">{title}</DialogTitle>
        </DialogHeader>
        <div className="aspect-video w-full bg-black">
          {videoId ? (
            <iframe
              key={videoId}
              src={`https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0&modestbranding=1`}
              title={title}
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          ) : (
            <div className="h-full flex items-center justify-center text-sm text-muted-foreground">
              Vídeo indisponível
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
