import { useMemo } from "react";

interface Day {
  date: string;
  count: number;
}

interface Props {
  data: Day[];
  weeks?: number;
}

/**
 * Heatmap estilo GitHub: 12 semanas × 7 dias.
 * data deve estar em ordem cronológica (mais antigo → mais recente).
 */
export function WorkoutHeatmap({ data, weeks = 12 }: Props) {
  const grid = useMemo(() => {
    // Organiza por colunas (semanas) e linhas (dia da semana, seg=0..dom=6)
    const cols: Day[][] = [];
    let current: Day[] = [];
    for (const d of data) {
      const dow = (new Date(d.date).getDay() + 6) % 7; // monday-first
      if (current.length === 0 && dow !== 0) {
        // padding inicial
        for (let i = 0; i < dow; i++) current.push({ date: "", count: -1 });
      }
      current.push(d);
      if (current.length === 7) {
        cols.push(current);
        current = [];
      }
    }
    if (current.length) cols.push(current);
    return cols.slice(-weeks);
  }, [data, weeks]);

  const totalTrained = data.filter((d) => d.count > 0).length;

  const cellClass = (count: number) => {
    if (count < 0) return "bg-transparent";
    if (count === 0) return "bg-muted/40";
    if (count === 1) return "bg-primary/40";
    if (count === 2) return "bg-primary/70";
    return "bg-primary shadow-glow";
  };

  return (
    <div>
      <div className="flex gap-1 overflow-x-auto pb-1">
        {grid.map((col, ci) => (
          <div key={ci} className="flex flex-col gap-1">
            {col.map((cell, ri) => (
              <div
                key={ri}
                title={
                  cell.date
                    ? `${cell.date}: ${cell.count} treino${cell.count !== 1 ? "s" : ""}`
                    : ""
                }
                className={`h-3 w-3 rounded-sm transition ${cellClass(cell.count)}`}
              />
            ))}
          </div>
        ))}
      </div>
      <div className="flex items-center justify-between mt-3 text-xs text-muted-foreground">
        <span>{totalTrained} dias treinados</span>
        <div className="flex items-center gap-1">
          <span>Menos</span>
          <div className="h-2.5 w-2.5 rounded-sm bg-muted/40" />
          <div className="h-2.5 w-2.5 rounded-sm bg-primary/40" />
          <div className="h-2.5 w-2.5 rounded-sm bg-primary/70" />
          <div className="h-2.5 w-2.5 rounded-sm bg-primary" />
          <span>Mais</span>
        </div>
      </div>
    </div>
  );
}
